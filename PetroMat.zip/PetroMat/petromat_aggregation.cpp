
#include "petromat_types.h"
#include <string>
#include <vector>
#include <queue>
#include <random>
#include <algorithm>
#include <random>
#include <numeric>
#include <stdio.h>

void aggregation_rnd(std::vector<long>& partition, long& coarseSize,
                          int * iaR, int * jaR,
                          double * valsR,
                          const long& nVertexR,
                          double theta, double maxEntry) {
    
    if (nVertexR < coarseSize) coarseSize = nVertexR; // Segurança básica
    
    partition.assign(nVertexR, -1);

    // 1. Criar uma lista de todos os índices e embaralhar
    std::vector<long> indices(nVertexR);
    std::iota(indices.begin(), indices.end(), 0);
    
    std::random_device rd;
    std::mt19937 gen(rd());
    std::shuffle(indices.begin(), indices.end(), gen);

    // 2. Garantir que cada agregado tenha pelo menos um elemento (os "seeds")
    for (long i = 0; i < coarseSize; ++i) {
        partition[indices[i]] = i;
    }

    // 3. Distribuir o restante dos nós aleatoriamente entre os agregados existentes
    std::uniform_int_distribution<long> dis(0, coarseSize - 1);
    for (long i = coarseSize; i < nVertexR; ++i) {
        partition[indices[i]] = dis(gen);
    }
}

void aggregation_clpj3_rr(std::vector<long>& partition, long& coarseSize,
                     int * iaR, int * jaR,
                     double * valsR,
                     const long& nVertexR,
                     double theta, double maxEntry ) {

    
    if( coarseSize <= 1 ) {
        fprintf(stderr, "TOTAL ERROR ON COARSE: COARSE SIZE TOO LOW: %ld\n", coarseSize );
    }


    if( nVertexR <= 10 ) {
        fprintf(stderr, "TOTAL ERROR ON COARSE: NVERTEX TOO LOW: %ld\n", coarseSize );
    }

    if( coarseSize >= nVertexR ) {
        fprintf(stderr, "TOTAL ERROR ON COARSE: COARSE BIGGER OR EQ THAN NVERTEX. COARSE SIZE %ld NVERTEX %ld\n", coarseSize, nVertexR );
    }



    const long n = nVertexR;
    partition.assign(n, -1);
    std::vector<bool> assigned(n, false);
    std::vector<std::vector<long>> strong_neighbors(n);
    static long countCall = 0;
    std::mt19937_64 rng( 0x892631  );
    std::uniform_int_distribution<long> dist(0, coarseSize - 1);
    long countStrongConnected = 0;


    long conected = 0;
    long conectedNeib = 0;
    long conectedDef = 0;
    

    for (long i = 0; i < n; ++i) 
    {
        //printf("1\n");
        double max_val = 0.0;
        for (long k = iaR[i]; k < iaR[i + 1]; ++k)
        {
            if (jaR[k] != i) 
            {   
                max_val = std::max(max_val, std::abs(valsR[k]));
            }
        }
        for (long k = iaR[i]; k < iaR[i + 1]; ++k) {
            long j = jaR[k];
            if (j != i && std::abs(valsR[k]) >= theta * max_val) {
                strong_neighbors[i].push_back(j);
                countStrongConnected++;
            }
        }
    }
    long step = std::max<long>(1, n / coarseSize);
    std::vector<long> seeds;
    long current_id = 0;
    
    for (long i = 0; i < coarseSize && i * step < n; ++i) 
    {
        //printf("2\n");
        seeds.push_back(i * step);
        assigned[ i * step ] = true;
        partition[i * step  ] = current_id;
        current_id++;
    }

    
    current_id = 0;
    //std::shuffle(seeds.begin(), seeds.end(), rng);

    std::vector< std::queue<long> > q( coarseSize );
    for (int i = 0; i < coarseSize; i++ ) {
        
        long seed = seeds[i];
        q[i].push(seed);
    }
    bool haveQueues = true;
    while( haveQueues ) {
        //printf("HAVE\n");
        haveQueues = false;
        for (int i = 0; i < coarseSize; i++ ) {
            //printf("3\n");
            //if (assigned[seed]) continue;
            //partition[seed] = current_id;
            //assigned[seed] = true;
            
            if ( !q[i].empty() ) {
                haveQueues = true;
                long u = q[i].front(); q[i].pop();
                for (long v : strong_neighbors[u]) {
                    if (!assigned[v]) {
                        partition[v] = partition[ i * step  ];
                        assigned[v] = true;
                        q[i].push(v);
                        conected++;
                        //break;
                    }
                }
            } 
        }
    }

    std::vector<long> indices(n);
    for (long i = 0; i < n; ++i) indices[i] = i;

    //std::shuffle(indices.begin(), indices.end(), rng);

    long default_best_group = dist( rng );

    for (long i : indices ) {
        //printf("4\n");
        if (partition[i] != -1) continue;
        double best_val = -1.0;
        long best_group = default_best_group; 
        bool flag = false;
        for (long k = iaR[i]; k < iaR[i + 1]; ++k) {
            long j = jaR[k];
            if (partition[j] != -1 && std::abs(valsR[k]) > best_val) {
                best_val = std::abs(valsR[k]);
                best_group = partition[j];
                flag = true;
            }
        }
        
        if( flag ) {
            partition[i] = best_group;
            conectedNeib++;
        } else {
            conectedDef++;
            partition[i] = best_group;
        }
        
    }
    //coarseSize++;
    //printf("FINISH\n");
    // coarseSize = current_id;
    double total = coarseSize + conected + conectedDef + conectedNeib;
    // coarseSize = current_id;
    #pragma omp master 
    {
        fprintf(stderr, "CONNECTIONS: %ld+%ld %ld %ld [%lf+%lf %lf %lf]\n", coarseSize, conected, conectedNeib, conectedDef, coarseSize/total, conected/total, conectedNeib/total, conectedDef/total );
    }
}


void saveAggregation( std::string filename, std::vector<long> partition, int coarseSize, ReservoirModel r ) {


    FILE * f = fopen( filename.c_str(), "w" );


    fprintf( f, "%d %d %d %d\n", r.grid.nx, r.grid.ny, r.grid.nz, coarseSize );

    for( int i = 0; i < partition.size(); i++ ) {
        fprintf(f, "%d %ld\n", i, partition[i] );
    }
    fclose( f );
}


