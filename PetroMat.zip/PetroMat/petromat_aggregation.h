#pragma once
#include "petromat_types.h"
#include <vector>
#include <string>

// Apenas a assinatura (termine com ;)
void aggregation_rnd(std::vector<long>& partition, long& coarseSize, 
                     int * iaR, int * jaR, double * valsR, 
                     const long& nVertexR, double theta, double maxEntry);

void saveAggregation(std::string filename, std::vector<long> partition, 
                     int coarseSize, ReservoirModel r);