#include <iostream>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <ctime>

#include "petromat_types.h"
#include "petromat_utils.h"
#include "petromat_fft.h"

#define IDXK(i,j,n) ((i)*(n)+(j))


void covariance_matrix3D(
    double Lx, double Ly, double Lz,
    int nx, int ny, int nz,
    double R[3][3], double sigma[3],
    double var, double a, double v,
    double *MatCov
) {
    int N = nx * ny * nz;

    double dx, dy, dz;

    for (int i = 0; i < N; i++) {
        int ix = i % nx;
        int iy = (i / nx) % ny;
        int iz = i / (nx * ny);

        double xi = (ix + 1) * Lx / nx;
        double yi = (iy + 1) * Ly / ny;
        double zi = (iz + 1) * Lz / nz;

        for (int j = 0; j < N; j++) {
            int jx = j % nx;
            int jy = (j / nx) % ny;
            int jz = j / (nx * ny);

            double xj = (jx + 1) * Lx / nx;
            double yj = (jy + 1) * Ly / ny;
            double zj = (jz + 1) * Lz / nz;

            dx = xi - xj;
            dy = yi - yj;
            dz = zi - zj;

            double hx =
                (R[0][0]*dx + R[1][0]*dy + R[2][0]*dz) / sigma[0];
            double hy =
                (R[0][1]*dx + R[1][1]*dy + R[2][1]*dz) / sigma[1];
            double hz =
                (R[0][2]*dx + R[1][2]*dy + R[2][2]*dz) / sigma[2];

            double h = sqrt(hx*hx + hy*hy + hz*hz);
            MatCov[IDXK(i,j,N)] = covariance(h, var, a, v);
        }
    }
}

// Função de covariância simplificada para 2D (seguindo o MATLAB)
void covariance_matrix2D(
    double Lx, double Ly,
    int nx, int ny,
    double R[3][3], double sigma[3],
    double var, double a, double v,
    double *MatCov
) {
    int N2D = nx * ny;
    for (int i = 0; i < N2D; i++) {
        int ix = i % nx;
        int iy = i / nx;
        double xi = (ix + 0.5) * Lx / nx; // Centro da célula
        double yi = (iy + 0.5) * Ly / ny;

        for (int j = 0; j < N2D; j++) {
            int jx = j % nx;
            int jy = j / nx;
            double xj = (jx + 0.5) * Lx / nx;
            double yj = (jy + 0.5) * Ly / ny;

            double dx = xi - xj;
            double dy = yi - yj;

            // Rotação/Escalonamento apenas em X e Y
            double hx = (R[0][0]*dx + R[1][0]*dy) / sigma[0];
            double hy = (R[0][1]*dx + R[1][1]*dy) / sigma[1];
            double h = sqrt(hx*hx + hy*hy);

            MatCov[i * N2D + j] = covariance(h, var, a, v);
        }
    }
}



StatisticPermeabilityParams create_cholesky_params(double sigma[3], double diagR[3], double a, double v) {
    StatisticPermeabilityParams p;



    p.a = a;         
    p.v = v;          // Parâmetro de suavidade
    
    for (int i = 0; i < 3; i++) {
        p.sigma[i] = sigma[i];
        for (int j = 0; j < 3; j++) {
            p.R[i][j] = (i == j) ? diagR[i] : 0.0;
        }
    }

    return p;
}


/**
 * @brief Gera o campo de permeabilidade heterogêneo usando decomposição de Cholesky.
 * Nota: O campo gerado é 2D (plano XY) para seguir a lógica de replicação em Z.
 */
int generate_permeability_cholesky(ReservoirModel *res, StatisticPermeabilityParams params, std::vector<double>& out_k_map) {
    // 1. Definir o tamanho do problema 2D
    int N2D = res->grid.nx * res->grid.ny;

    // 2. Parâmetros estatísticos para o Log-Normal
    // logmed é a média dos logaritmos, var é a variância baseada na regra de 4 sigma
    double logmed = (std::log(res->permeability.kmin) + std::log(res->permeability.kmax)) / 2.0;
    double var = std::pow((std::log(res->permeability.kmax) - std::log(res->permeability.kmin)) / 4.0, 2);

    // 3. Alocação de memória para matrizes densas (apenas para o plano 2D)
    // Usando calloc para garantir inicialização em zero
    double *MatCov = (double *)std::calloc(N2D * N2D, sizeof(double));
    double *L = (double *)std::calloc(N2D * N2D, sizeof(double));
    double *y = (double *)std::calloc(N2D, sizeof(double));
    
    if (!MatCov || !L || !y) {
        fprintf(stderr, "Erro: Falha na alocação de memória para Cholesky.\n");
        return -1;
    }

    std::srand(std::time(nullptr));

    // 4. Construir Matriz de Covariância 2D
    covariance_matrix2D(res->domain.lx, res->domain.ly,res->grid.nx, res->grid.ny, 
                       params.R, params.sigma, var, params.a, params.v, MatCov);

    // 5. Decomposição de Cholesky: MatCov = L * L^T
    // A função cholesky deve ser a sua implementação que trabalha com matrizes densas
    if (cholesky(MatCov, L, N2D) != 0) {
        fprintf(stderr, "Erro: Matriz de covariância não é definida positiva.\n");
        std::free(MatCov); std::free(L); std::free(y);
        return -1;
    }

    // 6. Gerar ruído branco gaussiano e realizar o produto L * y
    for (int i = 0; i < N2D; i++) {
        y[i] = randn(); // Sua função de geração de números normais (Z ~ N(0,1))
    }

    out_k_map.resize(N2D);
    for (int i = 0; i < N2D; i++) {
        double sum = 0.0;
        // L é triangular inferior, então multiplicamos apenas até j <= i
        for (int j = 0; j <= i; j++) {
            sum += L[i * N2D + j] * y[j];
        }
        // Transformação Log-Normal: K = exp(media + L*y)
        out_k_map[i] = std::exp(logmed + sum);
    }


    // 8. Limpeza
    std::free(MatCov);
    std::free(L);
    std::free(y);

    return 0;
}


int generate_permeability_fft(ReservoirModel *res, StatisticPermeabilityParams params, std::vector<double>& out_k_map) {
    // 1. Forçar dimensões para potência de 2 (Ex: 64x64, 128x128)
    // E usar o dobro do tamanho (Padding) para evitar periodicidade circular
    int nx_ext = std::pow(2, std::ceil(std::log2(res->grid.nx * 2)));
    int ny_ext = std::pow(2, std::ceil(std::log2(res->grid.ny * 2)));
    int total_ext = nx_ext * ny_ext;

    std::vector<Complex> cov_field(total_ext);
    
    
    // 1. Extrair os componentes 2D da matriz R 3x3 para o plano XY
    // Geralmente, para 2D, usamos R[0][0], R[0][1], R[1][0], R[1][1]
    double r11 = params.R[0][0];
    double r12 = params.R[0][1];
    double r21 = params.R[1][0];
    double r22 = params.R[1][1];

    // 2. Calcular o determinante da submatriz 2D para inversão
    double det = r11 * r22 - r12 * r21;

    if (std::abs(det) < 1e-12) {
        fprintf(stderr, "Erro: Matriz R singular ou mal condicionada.\n");
        return -1;
    }

    // 3. Componentes da matriz inversa (R^-1) para o cálculo da distância elíptica
    double inv11 =  r22 / det;
    double inv12 = -r12 / det;
    double inv21 = -r21 / det;
    double inv22 =  r11 / det;

    double dx_spacing = res->domain.lx / res->grid.nx;
    double dy_spacing = res->domain.ly / res->grid.ny;

    double var = pow((log(res->permeability.kmax)-log(res->permeability.kmin))/4, 2);

    // 4. Loop de preenchimento
    for (int i = 0; i < nx_ext; i++) {
        // Menor distância em X (propriedade circulante)
        int dist_i = (i <= nx_ext / 2) ? i : (nx_ext - i);
        double dx = dist_i * dx_spacing;

        for (int j = 0; j < ny_ext; j++) {
            // Menor distância em Y
            int dist_j = (j <= ny_ext / 2) ? j : (ny_ext - j);
            double dy = dist_j * dy_spacing;

            // 5. Cálculo da distância elíptica: h = sqrt( [dx dy] * R^-1 * [dx dy]^T )
            // h2 = dx*(inv11*dx + inv12*dy) + dy*(inv21*dx + inv22*dy)
            double h2 = dx * (inv11 * dx + inv12 * dy) + dy * (inv21 * dx + inv22 * dy);
            double h = std::sqrt(std::abs(h2));

            // 6. Modelo de Covariância Exponencial
            // var já deve ter sido calculado: var = pow((log(kmax)-log(kmin))/4, 2)
            double cov_val = var * std::exp(-h);

            cov_field[i * ny_ext + j] = Complex(cov_val, 0.0);
        }
    }

    // 3. FFT da Covariância -> Autovalores (Espectro de Potência)
    fft2d(cov_field, nx_ext, ny_ext, false);

    // 4. Gerar Ruído Branco e multiplicar no domínio da frequência
    std::vector<Complex> synth_field(total_ext);
    for (int i = 0; i < total_ext; i++) {
        double eigenvalue = std::max(0.0, cov_field[i].real()); // Garante que é positivo
        double z_re = randn();
        double z_im = randn();
        
        synth_field[i] = Complex(z_re, z_im) * std::sqrt(eigenvalue);
    }

    // 5. IFFT para voltar ao espaço real
    fft2d(synth_field, nx_ext, ny_ext, true);

    // 6. Recortar para o tamanho original e aplicar Log-Normal
    out_k_map.resize(res->grid.nx * res->grid.ny);
    double logmed = (std::log(res->permeability.kmin) + std::log(res->permeability.kmax)) / 2.0;

    for (int i = 0; i < res->grid.nx; i++) {
        for (int j = 0; j < res->grid.ny; j++) {
            double val = synth_field[i * ny_ext + j].real();
            out_k_map[i * res->grid.ny + j] = std::exp(logmed + val);
        }
    }

    return 0;
}

// Função auxiliar para inverter matriz 3x3 (Cramer's rule)
bool invert3x3(const double m[3][3], double inv[3][3]) {
    double det = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) -
                 m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) +
                 m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);

    if (std::abs(det) < 1e-12) return false;

    double inv_det = 1.0 / det;
    inv[0][0] = (m[1][1] * m[2][2] - m[1][2] * m[2][1]) * inv_det;
    inv[0][1] = (m[0][2] * m[2][1] - m[0][1] * m[2][2]) * inv_det;
    inv[0][2] = (m[0][1] * m[1][2] - m[0][2] * m[1][1]) * inv_det;
    inv[1][0] = (m[1][2] * m[2][0] - m[1][0] * m[2][2]) * inv_det;
    inv[1][1] = (m[0][0] * m[2][2] - m[0][2] * m[2][0]) * inv_det;
    inv[1][2] = (m[1][0] * m[0][2] - m[0][0] * m[1][2]) * inv_det;
    inv[2][0] = (m[1][0] * m[2][1] - m[1][1] * m[2][0]) * inv_det;
    inv[2][1] = (m[2][0] * m[0][1] - m[0][0] * m[2][1]) * inv_det;
    inv[2][2] = (m[0][0] * m[1][1] - m[1][0] * m[0][1]) * inv_det;
    return true;
}

int generate_permeability_fft_3d_working(ReservoirModel *res, Permeability params, std::vector<double>& out_k_map) {
    
    // ================================
    // 1. Grid estendido (evitar aliasing)
    // ================================
    int nx_ext = std::pow(2, std::ceil(std::log2(res->grid.nx * 2)));
    int ny_ext = std::pow(2, std::ceil(std::log2(res->grid.ny * 2)));
    int nz_ext = (res->grid.nz > 1) ? std::pow(2, std::ceil(std::log2(res->grid.nz * 2))) : 1;

    long long total_ext = (long long)nx_ext * ny_ext * nz_ext;
    std::vector<Complex> field(total_ext);

    // ================================
    // 2. Ruído branco (ESSENCIAL)
    // ================================
    for (long long i = 0; i < total_ext; i++) {
        field[i] = Complex(randn(), randn());
    }

    // ================================
    // 3. FFT → domínio de frequência
    // ================================
    fft3d(field, nx_ext, ny_ext, nz_ext, false);

    // ================================
    // 4. Aplicar espectro de Matérn
    // ================================
    for (int k = 0; k < nz_ext; k++) {
        for (int j = 0; j < ny_ext; j++) {
            for (int i = 0; i < nx_ext; i++) {

                int idx = (k * ny_ext + j) * nx_ext + i;

                // Frequências centradas
                double fk = (k > nz_ext/2) ? k - nz_ext : k;
                double fj = (j > ny_ext/2) ? j - ny_ext : j;
                double fi = (i > nx_ext/2) ? i - nx_ext : i;

                double fi_n = fi / nx_ext;
                double fj_n = fj / ny_ext;
                double fk_n = (nz_ext > 1) ? fk / nz_ext : 0.0;

                // Escala física + anisotropia
                double hx = fi_n * (res->domain.lx * params.range);
                double hy = fj_n * (res->domain.ly * (params.range * params.sigma[1]));
                double hz = fk_n * (res->domain.lz * (params.range * params.sigma[2]));

                double h_norm = std::sqrt(hx*hx + hy*hy + hz*hz);

                // Espectro de Matérn
                double s = params.smoothness;
                double psd = std::pow(1.0 + std::pow(h_norm, 2), -(s + 1.5));

                // Aplicar raiz da PSD
                field[idx] *= std::sqrt(psd);
            }
        }
    }

    // ================================
    // 5. IFFT → espaço real
    // ================================
    fft3d(field, nx_ext, ny_ext, nz_ext, true);

    // ================================
    // 6. Normalizar campo (importante!)
    // ================================
    double mean = 0.0;
    for (long long i = 0; i < total_ext; i++) {
        mean += field[i].real();
    }
    mean /= total_ext;

    double var = 0.0;
    for (long long i = 0; i < total_ext; i++) {
        double v = field[i].real() - mean;
        var += v * v;
    }
    var /= total_ext;
    double stddev = std::sqrt(var);

    // ================================
    // 7. Log-normal scaling
    // ================================
    double logmin = std::log(params.kmin);
    double logmax = std::log(params.kmax);
    double logmed = (logmin + logmax) / 2.0;

    double sigma = (logmax - logmin) / 4.0;

    out_k_map.assign(res->grid.nx * res->grid.ny * res->grid.nz, 0.0);

    for (int k = 0; k < res->grid.nz; k++) {
        for (int j = 0; j < res->grid.ny; j++) {
            for (int i = 0; i < res->grid.nx; i++) {

                int idx_ext = (k * ny_ext + j) * nx_ext + i;

                // Normaliza (z-score)
                double val = (field[idx_ext].real() - mean) / (stddev + 1e-12);

                double log_k = logmed + sigma * val;

                int idx = i + j * res->grid.nx + k * (res->grid.nx * res->grid.ny);
                out_k_map[idx] = std::exp(log_k);
            }
        }
    }

    return 0;
}


int generate_permeability_fft_3d(ReservoirModel *res, Permeability params, std::vector<double>& out_k_map) {

    // ================================
    // 1. Grid estendido
    // ================================
    int nx_ext = std::pow(2, std::ceil(std::log2(res->grid.nx * 2)));
    int ny_ext = std::pow(2, std::ceil(std::log2(res->grid.ny * 2)));
    int nz_ext = (res->grid.nz > 1) ? std::pow(2, std::ceil(std::log2(res->grid.nz * 2))) : 1;

    long long total_ext = (long long)nx_ext * ny_ext * nz_ext;
    std::vector<Complex> field(total_ext);

    // ================================
    // 2. Ruído branco
    // ================================
    for (long long i = 0; i < total_ext; i++) {
        field[i] = Complex(randn(), randn());
    }

    // ================================
    // 3. FFT
    // ================================
    fft3d(field, nx_ext, ny_ext, nz_ext, false);

    // Frequência física (ESSENCIAL)
    double dfx = 1.0 / res->domain.lx;
    double dfy = 1.0 / res->domain.ly;
    double dfz = (nz_ext > 1) ? 1.0 / res->domain.lz : 0.0;

    // ================================
    // 4. Aplicar espectro Matérn
    // ================================
    for (int k = 0; k < nz_ext; k++) {
        for (int j = 0; j < ny_ext; j++) {
            for (int i = 0; i < nx_ext; i++) {

                int idx = (k * ny_ext + j) * nx_ext + i;

                // Frequência centrada
                double fk = (k > nz_ext/2) ? k - nz_ext : k;
                double fj = (j > ny_ext/2) ? j - ny_ext : j;
                double fi = (i > nx_ext/2) ? i - nx_ext : i;

                // Frequência física
                double fx = fi * dfx;
                double fy = fj * dfy;
                double fz = fk * dfz;

                // ================================
                // Aplicar rotação (R)
                // ================================
                double rx = params.R[0][0]*fx + params.R[0][1]*fy + params.R[0][2]*fz;
                double ry = params.R[1][0]*fx + params.R[1][1]*fy + params.R[1][2]*fz;
                double rz = params.R[2][0]*fx + params.R[2][1]*fy + params.R[2][2]*fz;

                // ================================
                // Aplicar range + anisotropia
                // ================================
                double hx = rx * (params.range * params.sigma[0]);
                double hy = ry * (params.range * params.sigma[1]);
                double hz = rz * (params.range * params.sigma[2]);

                double h_norm = std::sqrt(hx*hx + hy*hy + hz*hz);

                // ================================
                // Espectro Matérn
                // ================================
                double s = params.smoothness;
                double psd = std::pow(1.0 + h_norm*h_norm, -(s + 1.5));

                // Aplicar filtro
                field[idx] *= std::sqrt(psd);
            }
        }
    }

    // ================================
    // 5. IFFT
    // ================================
    fft3d(field, nx_ext, ny_ext, nz_ext, true);

    // ================================
    // 6. Normalização
    // ================================
    double mean = 0.0;
    for (long long i = 0; i < total_ext; i++) {
        mean += field[i].real();
    }
    mean /= total_ext;

    double var = 0.0;
    for (long long i = 0; i < total_ext; i++) {
        double v = field[i].real() - mean;
        var += v * v;
    }
    var /= total_ext;
    double stddev = std::sqrt(var);

    // ================================
    // 7. Log-normal
    // ================================
    double logmin = std::log(params.kmin);
    double logmax = std::log(params.kmax);
    double logmed = (logmin + logmax) / 2.0;
    double sigma = (logmax - logmin) / 4.0;

    out_k_map.assign(res->grid.nx * res->grid.ny * res->grid.nz, 0.0);

    for (int k = 0; k < res->grid.nz; k++) {
        for (int j = 0; j < res->grid.ny; j++) {
            for (int i = 0; i < res->grid.nx; i++) {

                int idx_ext = (k * ny_ext + j) * nx_ext + i;

                double val = (field[idx_ext].real() - mean) / (stddev + 1e-12);
                double log_k = logmed + sigma * val;

                int idx = i + j * res->grid.nx + k * (res->grid.nx * res->grid.ny);
                out_k_map[idx] = std::exp(log_k);
            }
        }
    }

    return 0;
}