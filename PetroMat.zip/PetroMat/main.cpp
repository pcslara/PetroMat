
#include <fstream>
#include <memory>
#include <stdio.h>
#include <stdlib.h>
#include <argp.h>
#include <atomic>
#include <thread>
#include <chrono>
#include <omp.h>

#include "petromat_types.h"
#include "petromat_assembly.h"
#include "petromat_geology.h"
#include "petromat_utils.h"
#include "petromat_cg.h"
#include "petromat_parser_model.h"
#include "petromat_aggregation.h"
#include "petromat_ic.h"
#include "petromat_coarse.h"
#include "petromat_composite.h"
#include "petromat_hypre.h"
#include "petromat_amgcl.h"
#include "petromat_parser.h"
#include "petromat_config.h"


#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>




#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

//extern int _nx, _ny, _nz;

// Estrutura para diagnóstico
typedef struct {
    double min_diag;
    double max_diag;
    int negative_diag_count;
    int zero_diag_count;
    double norm_L;
    double norm_LtL_minus_A;
    int singular_rows;
} IC0_Diagnostic;

// Função para imprimir matriz CSR (para debug)
void print_csr_matrix(const CSRMatrix *A, const double *vals, const char *name) {
    printf("\n=== %s ===\n", name);
    for (int i = 0; i < A->n; i++) {
        printf("Linha %d: ", i);
        for (int k = A->ia[i]; k < A->ia[i + 1]; k++) {
            printf("(%d, %f) ", A->ja[k], vals[k]);
        }
        printf("\n");
    }
}

// Verifica se a matriz é simétrica
int check_symmetry(const CSRMatrix *A) {
    printf("\n=== Verificando Simetria ===\n");
    int symmetric = 1;
    
    for (int i = 0; i < A->n; i++) {
        for (int k = A->ia[i]; k < A->ia[i + 1]; k++) {
            int j = A->ja[k];
            double val_ij = A->vals[k];
            
            // Procurar A[j][i]
            int found = 0;
            for (int m = A->ia[j]; m < A->ia[j + 1]; m++) {
                if (A->ja[m] == i) {
                    double val_ji = A->vals[m];
                    if (fabs(val_ij - val_ji) > 1e-10) {
                        printf("Assimetria em (%d,%d): %f vs %f\n", i, j, val_ij, val_ji);
                        symmetric = 0;
                    }
                    found = 1;
                    break;
                }
            }
            if (!found && val_ij != 0) {
                printf("Elemento (%d,%d) existe mas (%d,%d) não\n", i, j, j, i);
                symmetric = 0;
            }
        }
    }
    
    if (symmetric) {
        printf("Matriz é simétrica\n");
    } else {
        printf("Matriz NÃO é simétrica!\n");
        exit( 0 );
    }
    return symmetric;
}

void check_diagonal_sum(const CSRMatrix *A) {
    //printf("\n=== Verificando Dominância Diagonal ===\n");
    double epsilon = 1e-16;

    for (int i = 0; i < A->n; i++) {
        double diag = 0.0;
        double sum_off = 0.0;
        
        for (int k = A->ia[i]; k < A->ia[i + 1]; k++) {
            int j = A->ja[k];
            if (j == i) {
                diag = (A->vals[k]);
            } else {
                sum_off += (A->vals[k]);
            }
        }
        
        if ( fabs( diag + sum_off ) < epsilon ) {
            printf( "%.4g\n", fabs( diag + sum_off ) );
        } else {
            //printf("ERROR in line %d %.4g\n", i,fabs( diag - sum_off )   );
        }
    }
    
}

double T() {
    auto agora = std::chrono::high_resolution_clock::now();
    auto duracao = std::chrono::duration<double, std::milli>(agora.time_since_epoch());
    return duracao.count();
}

// Verifica diagonal dominância
void check_diagonal_dominance(const CSRMatrix *A) {
    printf("\n=== Verificando Dominância Diagonal ===\n");
    int strictly_diag_dominant = 1;
    //itn diag_dominant = 1;
    
    for (int i = 0; i < A->n; i++) {
        double diag = 0.0;
        double sum_off = 0.0;
        
        for (int k = A->ia[i]; k < A->ia[i + 1]; k++) {
            int j = A->ja[k];
            if (j == i) {
                diag = fabs(A->vals[k]);
            } else {
                sum_off += fabs(A->vals[k]);
            }
        }
        
        if (diag <= sum_off) {
            //diag_dominant = 0;
            //printf("Linha %d: |diag|=%f <= soma_off=%f\n", i, diag, sum_off);
            if ( fabs( diag - sum_off ) < 1e-14 ) {
                strictly_diag_dominant = 0;
            }
        }
    }
    
    if (strictly_diag_dominant) {
        printf("Matriz é estritamente diagonal dominante\n");
    } else {
        printf("Matriz NÃO é diagonal dominante\n");
        // exit( 0 );
    }
}


#define mmin(a, b) (a < b ? (a) : (b))

double testSolution( const CSRMatrix * A, const double * b, const double * x ) {
    double *y = (double*) malloc(A->n * sizeof(double));
    spmv_csr(A, x, y);

    double max_diff = 0;
    double max_y = 0;

    for( int i = 0; i < A->n; i++ ) 
    {
        max_y = fmax( y[i], max_y  );
        if( fabs( b[i] - y[i] ) > max_diff )
        {
            max_diff = fabs( b[i] - y[i] ) ;
        }
    }

    printf("Error: %.6g\n", max_diff/max_y );
    return max_diff/max_y;
}



// Auxiliar: Média Harmônica
inline double harmonic(double k1, double k2) {
    if (k1 + k2 == 0) return 0.0;
    return 2.0 * k1 * k2 / (k1 + k2);
}

// Sua nova função (conforme implementada acima)
// [Inserir aqui a função sparse_laplacian_with_K que discutimos anteriormente]

void print_matrix_dense(const CSRMatrix& A) {
    std::cout << "Matriz " << A.n << "x" << A.n << ":" << std::endl;
    for (int i = 0; i < A.n; i++) {
        std::vector<double> row(A.n, 0.0);
        for (int k = A.ia[i]; k < A.ia[i + 1]; k++) {
            row[A.ja[k]] = A.vals[k];
        }
        for (double val : row) {
            std::cout << std::setw(6) << val << " ";
        }
        std::cout << std::endl;
    }
}

#include <cmath>
#include <numeric>
#include <vector>
#include <iostream>

/**
 * Calcula o erro de representação do near-nullspace (vetor constante).
 * Retorna um valor entre 0 e 1. 
 * Próximo de 0: Excelente. Próximo de 1: Agregação falha em capturar o erro suave.
 */
double calculate_interpolation_error(int n, int num_aggregates, const std::vector<long>& partition) {
    // 1. Criar o "Vetor Constante" (nosso erro de baixa frequência ideal)
    std::vector<double> e(n, 1.0);
    
    // 2. Operador de Restrição (R): Média do erro em cada agregado
    // Em agregação simples, isso é o valor "grosso"
    std::vector<double> e_coarse(num_aggregates, 0.0);
    std::vector<int> counts(num_aggregates, 0);
    
    for (int i = 0; i < n; ++i) {
        long agg = partition[i];
        if (agg >= 0 && agg < num_aggregates) {
            e_coarse[agg] += e[i];
            counts[agg]++;
        }
    }
    
    for (int j = 0; j < num_aggregates; ++j) {
        if (counts[j] > 0) e_coarse[j] /= counts[j];
    }

    // 3. Operador de Prolongamento (P): Interpolação constante por partes
    // Reconstruímos o vetor fino a partir do grosso
    std::vector<double> e_hat(n, 0.0);
    for (int i = 0; i < n; ++i) {
        long agg = partition[i];
        if (agg >= 0) e_hat[i] = e_coarse[agg];
    }

    // 4. Calcular Norma L2 do Erro: ||e - e_hat|| / ||e||
    double diff_norm = 0.0;
    double original_norm = 0.0;
    
    for (int i = 0; i < n; ++i) {
        diff_norm += std::pow(e[i] - e_hat[i], 2);
        original_norm += std::pow(e[i], 2);
    }

    return std::sqrt(diff_norm) / std::sqrt(original_norm);
}

double evaluate_aggregation_physical_quality(const CSRMatrix &A, int num_aggregates, const std::vector<long>& partition) {
    int n = A.n;
    
    // 1. Iniciar com um erro aleatório ou constante
    std::vector<double> e(n, 1.0);
    std::vector<double> e_new(n, 0.0);

    // 2. Relaxação de Jacobi (5 iterações são suficientes para "moldar" o erro)
    // Isso faz o erro carregar a assinatura das heterogeneidades de K
    for (int iter = 0; iter < 20; iter++) {
        for (int i = 0; i < n; i++) {
            double diag = 0;
            double sum = 0;
            for (int k = A.ia[i]; k < A.ia[i+1]; k++) {
                int j = A.ja[k];
                if (i == j) {
                    diag = A.vals[k];
                } else {
                    sum += A.vals[k] * e[j];
                }
            }
            if (std::abs(diag) > 1e-16) {
                // b=0 pois queremos o erro no espaço nulo aproximado
                e_new[i] = (0.0 - sum) / diag;
            }
        }
        e = e_new;
    }

    // 3. Restrição (R): Média do erro relaxado dentro de cada agregado
    std::vector<double> e_coarse(num_aggregates, 0.0);
    std::vector<int> counts(num_aggregates, 0);
    
    for (int i = 0; i < n; i++) {
        long agg = partition[i];
        if (agg >= 0 && agg < num_aggregates) {
            e_coarse[agg] += e[i];
            counts[agg]++;
        }
    }
    
    for (int j = 0; j < num_aggregates; j++) {
        if (counts[j] > 0) e_coarse[j] /= counts[j];
    }

    // 4. Prolongamento (P): Reconstrução do erro fino
    std::vector<double> e_hat(n, 0.0);
    for (int i = 0; i < n; i++) {
        long agg = partition[i];
        if (agg >= 0) e_hat[i] = e_coarse[agg];
    }

    // 5. Cálculo da Norma L2 Relativa
    double diff_norm = 0.0;
    double original_norm = 0.0;
    for (int i = 0; i < n; i++) {
        diff_norm += std::pow(e[i] - e_hat[i], 2);
        original_norm += std::pow(e[i], 2);
    }

    // Calcule a norma do gradiente do erro reconstruído (e_hat)
    double gradient_norm = 0;
    for (int i = 0; i < n; i++) {
        for (int k = A.ia[i]; k < A.ia[i+1]; k++) {
            int j = A.ja[k];
            gradient_norm += std::pow(e_hat[i] - e_hat[j], 2);
        }
    }

    //printf("Energia do Gradiente: %.6f\n", gradient_norm);
    // 1. Calcular o erro que SOBRA após a correção da malha grossa
    std::vector<double> e_post(n);
    for(int i = 0; i < n; i++) e_post[i] = e[i] - e_hat[i];

    // 2. Tentar "suavizar" esse erro restante com 2 iterações de Jacobi
    // Se a partição for boa, o Jacobi mata o que sobrou. 
    // Se for aleatória, o Jacobi vai PATINAR.
    std::vector<double> e_smooth(n, 0.0);
    for (int iter = 0; iter < 2; iter++) {
        for (int i = 0; i < n; i++) {
            double diag = 0, sum = 0;
            for (int k = A.ia[i]; k < A.ia[i+1]; k++) {
                if (A.ja[k] == i) diag = A.vals[k];
                else sum += A.vals[k] * e_post[A.ja[k]];
            }
            e_smooth[i] = -sum / diag;
        }
        e_post = e_smooth;
    }
    double norm_pre = 0, norm_post = 0, norm_e = 0;
    for(int i=0; i<n; i++) {
        norm_pre  += std::pow(e[i] - e_hat[i], 2); // Erro antes de suavizar
        norm_post += std::pow(e_post[i], 2);       // Erro depois de suavizar
        norm_e    += std::pow(e[i], 2);            // Erro original
    }

    double eta = std::sqrt(norm_pre) / std::sqrt(norm_e);
    double zeta = 1.0 - (std::sqrt(norm_post) / std::sqrt(norm_pre));

    printf("\n--- Métricas Relativizadas --- \n");
    printf("Fidelidade da Malha Grossa (eta): %.4f\n", eta);
    printf("Eficiência de Suavização (zeta):  %.4f\n", zeta);

    // 3. Métrica de Eficiência: Quão "limpável" é o erro que sobrou?
    double final_norm = 0;
    for(double val : e_post) final_norm += val * val;
    //printf("Resíduo de Alta Frequência Pós-Suavização: %.6f\n", std::sqrt(final_norm));
    return (original_norm > 0) ? std::sqrt(diff_norm) / std::sqrt(original_norm) : 1.0;
}


CSRMatrix* filter_strong_rs(const CSRMatrix *A, double theta) {
    CSRMatrix *S = (CSRMatrix*)malloc(sizeof(CSRMatrix));
    S->n = A->n;
    S->ia = (int*)malloc((A->n + 1) * sizeof(int));
    
    // Alocação inicial conservadora (no máximo nnz elementos)
    int *tmp_ja = (int*)malloc(A->nnz * sizeof(int));
    double *tmp_vals = (double*)malloc(A->nnz * sizeof(double));
    
    int current_nnz = 0;
    S->ia[0] = 0;

    for (int i = 0; i < A->n; i++) {
        double max_off_diag = 0.0;

        // Passo 1: Localizar a maior magnitude fora da diagonal na linha i
        for (int idx = A->ia[i]; idx < A->ia[i+1]; idx++) {
            int j = A->ja[idx];
            if (i != j) {
                double abs_val = fabs(A->vals[idx]);
                if (abs_val > max_off_diag) {
                    max_off_diag = abs_val;
                }
            }
        }

        // Passo 2: Filtrar baseando-se no critério theta
        for (int idx = A->ia[i]; idx < A->ia[i+1]; idx++) {
            int j = A->ja[idx];
            double val = A->vals[idx];

            if (i == j) {
                // Mantemos a diagonal principal (importante para solvers)
                tmp_ja[current_nnz] = j;
                tmp_vals[current_nnz] = val;
                current_nnz++;
            } else {
                // Critério de Ruge-Stüben: Conexão Forte
                if (fabs(val) >= theta * max_off_diag) {
                    tmp_ja[current_nnz] = j;
                    tmp_vals[current_nnz] = val;
                    current_nnz++;
                }
            }
        }
        S->ia[i+1] = current_nnz;
    }

    // Ajustar o tamanho real ocupado na memória
    S->nnz = current_nnz;
    S->ja = (int*)realloc(tmp_ja, current_nnz * sizeof(int));
    S->vals = (double*)realloc(tmp_vals, current_nnz * sizeof(double));

    return S;
}
#include <iostream>
#include <vector>
#include <iomanip>
#include <cmath>

#include "petromat_parser_model.h"
#include "petromat_ic.h"
/**
 * Calcula o Gap de Resíduo (Psi).
 * Mede a consistência entre o operador fino (A) e a reconstrução grosseira (P*R).
 * Valor Próximo de 0: A malha grossa entende a física da malha fina.
 * Valor Alto (> 1.0): A partição introduz ruído e o solver vai sofrer.
 */
double evaluate_residual_consistency(const CSRMatrix &A, int num_aggregates, const std::vector<long>& partition) {
    int n = A.n;

    // 1. Obter o erro relaxado 'e' (o mesmo do teste anterior)
    // Reutilizamos a lógica de 10 iterações de Jacobi
    std::vector<double> e(n, 1.0);
    std::vector<double> e_new(n, 0.0);
    for (int iter = 0; iter < 10; iter++) {
        for (int i = 0; i < n; i++) {
            double diag = 0, sum = 0;
            for (int k = A.ia[i]; k < A.ia[i+1]; k++) {
                if (A.ja[k] == i) diag = A.vals[k];
                else sum += A.vals[k] * e[A.ja[k]];
            }
            if (std::abs(diag) > 1e-16) e_new[i] = -sum / diag;
        }
        e = e_new;
    }

    // 2. Calcular Resíduo Fino: r_fino = A * e
    std::vector<double> r_fino(n, 0.0);
    for (int i = 0; i < n; i++) {
        for (int k = A.ia[i]; k < A.ia[i+1]; k++) {
            r_fino[i] += A.vals[k] * e[A.ja[k]];
        }
    }

    // 3. Gerar a reconstrução grosseira e_hat (P * R * e)
    std::vector<double> e_coarse(num_aggregates, 0.0);
    std::vector<int> counts(num_aggregates, 0);
    for (int i = 0; i < n; i++) {
        e_coarse[partition[i]] += e[i];
        counts[partition[i]]++;
    }
    for (int j = 0; j < num_aggregates; j++) if (counts[j] > 0) e_coarse[j] /= counts[j];

    std::vector<double> e_hat(n, 0.0);
    for (int i = 0; i < n; i++) e_hat[i] = e_coarse[partition[i]];

    // 4. Calcular Resíduo da Reconstrução: r_hat = A * e_hat
    std::vector<double> r_hat(n, 0.0);
    for (int i = 0; i < n; i++) {
        for (int k = A.ia[i]; k < A.ia[i+1]; k++) {
            r_hat[i] += A.vals[k] * e_hat[A.ja[k]];
        }
    }

    // 5. O GAP: ||r_fino - r_hat|| / ||r_fino||
    double diff_norm = 0.0;
    double original_norm = 0.0;
    for (int i = 0; i < n; i++) {
        diff_norm += std::pow(r_fino[i] - r_hat[i], 2);
        original_norm += std::pow(r_fino[i], 2);
    }

    return std::sqrt(diff_norm) / std::sqrt(original_norm);
}


SPDCheckResult check_if_spd(const CSRMatrix& A) {
    SPDCheckResult result;
    result.is_spd = false;
    result.is_symmetric = true;
    result.has_positive_diagonal = true;
    result.is_positive_definite = true;
    result.min_diagonal = 1e300;
    result.max_diagonal = -1e300;
    result.min_eigenvalue_estimate = 0.0;
    
    int n = A.n;
    
    
    // 2. Verificar simetria e diagonal positiva
    std::cout << "\n=== Verificando simetria e diagonal ===\n";
    
    for (int i = 0; i < n; i++) {
        // Verifica diagonal
        bool found_diag = false;
        double diag_val = 0.0;
        
        for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
            int j = A.ja[idx];
            if (j == i) {
                found_diag = true;
                diag_val = A.vals[idx];
                result.min_diagonal = std::min(result.min_diagonal, diag_val);
                result.max_diagonal = std::max(result.max_diagonal, diag_val);
                
                if (diag_val <= 0) {
                    result.has_positive_diagonal = false;
                    result.issues.push_back("Diagonal[" + std::to_string(i) + 
                                           "] = " + std::to_string(diag_val) + " (não positiva)");
                }
                break;
            }
        }
        
        if (!found_diag) {
            result.has_positive_diagonal = false;
            result.issues.push_back("Diagonal[" + std::to_string(i) + "] não encontrada (zero implícito)");
        }
        
        // Verifica simetria: para cada elemento A[i][j], deve existir A[j][i] com mesmo valor
        for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
            int j = A.ja[idx];
            if (j == i) continue;
            
            // Procura A[j][i]
            bool found_sym = false;
            for (int idx2 = A.ia[j]; idx2 < A.ia[j+1]; idx2++) {
                if (A.ja[idx2] == i) {
                    found_sym = true;
                    double diff = std::abs(A.vals[idx] - A.vals[idx2]);
                    double tol = 1e-10 * (std::abs(A.vals[idx]) + std::abs(A.vals[idx2]));
                    if (diff > tol) {
                        result.is_symmetric = false;
                        result.issues.push_back("Assimetria: A[" + std::to_string(i) + "][" + 
                                               std::to_string(j) + "] = " + std::to_string(A.vals[idx]) +
                                               ", A[" + std::to_string(j) + "][" + std::to_string(i) + 
                                               "] = " + std::to_string(A.vals[idx2]));
                    }
                    break;
                }
            }
            
            if (!found_sym) {
                result.is_symmetric = false;
                result.issues.push_back("Assimetria: A[" + std::to_string(i) + "][" + 
                                       std::to_string(j) + "] existe, mas A[" + std::to_string(j) + 
                                       "][" + std::to_string(i) + "] não");
            }
        }
    }
    
    // 3. Teste de positividade definida usando fatoração de Cholesky (incompleta)
    std::cout << "\n=== Testando positividade definida (Cholesky simbólico) ===\n";
    
    // Copiar apenas a parte inferior para teste
    std::vector<std::map<int, double>> L_test(n);
    for (int i = 0; i < n; i++) {
        for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
            int j = A.ja[idx];
            if (j <= i) {
                L_test[i][j] = A.vals[idx];
            }
        }
    }
    
    // Tentar fatoração de Cholesky completa (sem incomplete)
    bool cholesky_succeeded = true;
    int first_negative_pivot = -1;
    double min_pivot = 1e300;
    
    for (int i = 0; i < n; i++) {
        // Atualiza diagonal
        double diag = L_test[i][i];
        
        for (auto& [j, Lij] : L_test[i]) {
            if (j >= i) continue;
            
            double Ljj = L_test[j][j];
            if (std::abs(Ljj) < 1e-14) {
                cholesky_succeeded = false;
                first_negative_pivot = j;
                break;
            }
            
            Lij = Lij / Ljj;
            
            // Atualiza elementos restantes
            for (auto& [k, Ljk] : L_test[j]) {
                if (k >= j) continue;
                
                auto it = L_test[i].find(k);
                if (it != L_test[i].end()) {
                    it->second -= Lij * Ljk;
                }
            }
        }
        
        if (!cholesky_succeeded) break;
        
        // Corrige diagonal
        diag = L_test[i][i];
        for (auto& [j, Lij] : L_test[i]) {
            if (j < i) {
                diag -= Lij * Lij;
            }
        }
        
        min_pivot = std::min(min_pivot, diag);
        
        if (diag <= 1e-14) {
            cholesky_succeeded = false;
            first_negative_pivot = i;
            break;
        }
        
        L_test[i][i] = std::sqrt(diag);
    }
    
    result.is_positive_definite = cholesky_succeeded;
    result.min_eigenvalue_estimate = min_pivot;
    
    if (!cholesky_succeeded) {
        result.issues.push_back("Cholesky falhou no pivô " + std::to_string(first_negative_pivot) +
                               " (valor = " + std::to_string(min_pivot) + ")");
    }
    
    // 4. Diagnóstico final
    result.is_spd = result.is_symmetric && result.has_positive_diagonal && result.is_positive_definite;
    
    // 5. Imprime relatório
    std::cout << "\n=== RELATÓRIO SPD ===\n";
    std::cout << "Simetria: " << (result.is_symmetric ? "OK" : "FALHA") << "\n";
    std::cout << "Diagonal positiva: " << (result.has_positive_diagonal ? "OK" : "FALHA") << "\n";
    std::cout << "Positividade definida: " << (result.is_positive_definite ? "OK" : "FALHA") << "\n";
    std::cout << "É SPD: " << (result.is_spd ? "SIM" : "NÃO") << "\n";
    std::cout << "Diagonal: min = " << result.min_diagonal << ", max = " << result.max_diagonal << "\n";
    std::cout << "Estimativa do menor autovalor: " << result.min_eigenvalue_estimate << "\n";
    
    if (!result.issues.empty()) {
        std::cout << "\nProblemas encontrados (" << result.issues.size() << "):\n";
        for (size_t i = 0; i < std::min(size_t(10), result.issues.size()); i++) {
            std::cout << "  - " << result.issues[i] << "\n";
        }
        if (result.issues.size() > 10) {
            std::cout << "  ... e mais " << (result.issues.size() - 10) << " problemas\n";
        }
    }
    
    return result;
}

// Versão simplificada para uso rápido
bool is_spd(const CSRMatrix& A, std::string& reason) {
    auto result = check_if_spd(A);
    if (!result.is_spd && !result.issues.empty()) {
        reason = result.issues[0];
    }
    return result.is_spd;
}

// Função para tentar "consertar" a matriz (apenas diagnóstico)
void fix_spd_issues(CSRMatrix& A) {
    std::cout << "\n=== Tentando corrigir problemas SPD ===\n";
    
    int n = A.n;
    int fixes = 0;
    
    // 1. Corrigir diagonal negativa ou zero
    for (int i = 0; i < n; i++) {
        bool found_diag = false;
        for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
            if (A.ja[idx] == i) {
                found_diag = true;
                if (A.vals[idx] <= 1e-12) {
                    double old = A.vals[idx];
                    A.vals[idx] = 1e-6;
                    std::cout << "  Corrigido A[" << i << "][" << i << "] = " << old << " -> " << A.vals[idx] << "\n";
                    fixes++;
                }
                break;
            }
        }
        if (!found_diag) {
            std::cout << "  Adicionado diagonal A[" << i << "][" << i << "] = 1e-6\n";
            // Aqui precisaria inserir na estrutura CSR - complicado
            fixes++;
        }
    }
    
    // 2. Forçar simetria (média dos valores)
    for (int i = 0; i < n; i++) {
        for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
            int j = A.ja[idx];
            if (j > i) {
                // Encontrar A[j][i]
                for (int idx2 = A.ia[j]; idx2 < A.ia[j+1]; idx2++) {
                    if (A.ja[idx2] == i) {
                        double avg = (A.vals[idx] + A.vals[idx2]) * 0.5;
                        if (std::abs(A.vals[idx] - A.vals[idx2]) > 1e-12) {
                            A.vals[idx] = avg;
                            A.vals[idx2] = avg;
                            fixes++;
                        }
                        break;
                    }
                }
            }
        }
    }
    
    std::cout << "Total de correções: " << fixes << "\n";
}


int main(int argc, char **argv) {
    MPI_Init(&argc, &argv);

    std::string filenameyaml = "config.yaml";
    //printf("\n",filenameyaml.c_str() );
    
    if( argc == 2 ) {
        filenameyaml =  argv[1];
        printf(">>>>> %s\n",filenameyaml.c_str() );
    }

    ReservoirModel reservoir;
    try {
        reservoir = load_reservoir_config( filenameyaml.c_str() );
        print_reservoir( reservoir );
    } catch (const std::exception& e) {
        std::cerr << "Erro no arquivo de configuração: " << e.what() << std::endl;
        MPI_Abort(MPI_COMM_WORLD, 1);
    }
    _nx = reservoir.grid.nx;
    _ny = reservoir.grid.ny;
    _nz = reservoir.grid.nz;
    
    // Opcional: imprimir sumário do modelo
    // print_reservoir(reservoir); 

    // 2. Preparação dos Dados Físicos (Matriz de Pressão)
    int nCells = reservoir.grid.num_cells();
    std::vector<double> K(nCells);
    std::vector<double> b(nCells, 1.0);
    std::vector<double> x(nCells, 1.0);
    std::vector<double> x_ref(nCells, 1.0);

    if( reservoir.permeability.perm_field == "" ) {
        
        
        generate_permeability_fft_3d(&reservoir, reservoir.permeability, K);
    } else {
        if (!load_perm_csv(reservoir.permeability.perm_field.c_str(), K, reservoir.grid.nx, reservoir.grid.ny, reservoir.grid.nz) ) {
            return -1;
        }
    }



    std::shared_ptr<CSRMatrix > A;
    if( reservoir.input_matrix == "" ) {
        A = std::make_shared<CSRMatrix>(
            sparse_laplacian_with_K3D(
                K.data(),
                reservoir.grid.nx, reservoir.grid.ny, reservoir.grid.nz,
                reservoir.domain.dx(reservoir.grid), 
                reservoir.domain.dy(reservoir.grid), 
                reservoir.domain.dz(reservoir.grid),
                reservoir.permeability.kx, reservoir.permeability.ky, reservoir.permeability.kz,
                reservoir.boundary_conditions,
                b.data()
            )
        );
    } else {
        A = read_matrix_market( reservoir.input_matrix  );
        if (A != nullptr) {
            // Redimensiona e aloca 'b' com valor 1.0 cobrindo todas as linhas da matriz lida
            b.assign(A->n, 0.0);
            x.assign(A->n, 0.0);
            x_ref.assign(A->n, 0.0);
            nCells = A->n;
        }
    }

    if( reservoir.input_rhs != "" ) {
        read_vector(b, A->n, reservoir.input_rhs );
    }
    //export_k_map("K.dat", K.data(), reservoir.grid.nx, reservoir.grid.ny, reservoir.grid.nz);
    std::map<std::string, SolverStats> benchmark_results;


    if( reservoir.reference_solver ) {
        printf("Solução de Referência\n");
        printf("\n=> Configuração: %s [%s]\n", reservoir.reference_solver->id.c_str(), reservoir.reference_solver->type.c_str());
        auto solver = reservoir.reference_solver->build( A->clone() );
        std::fill(x_ref.begin(), x_ref.end(), 0.0);
        solver->setup();
        std::vector<double> b_local = b;
        solver->solveCrono(b_local, x_ref);
    }



    for (const auto& sconf : reservoir.solvers) {
        printf("\n=> Configuração: %s [%s]\n", sconf->id.c_str(), sconf->type.c_str());
        try {
            auto solver = sconf->build( A->clone() );
            if( reservoir.reference_solver ) {
                std::cout << "REF SOL\n";
                solver->setReferenceSolution( std::make_shared< std::vector<double>>( x_ref ) );
            }

            std::vector<double> b_local = b;
            std::fill(x.begin(), x.end(), 0.0);
            double t0, t1;
          
            double setupTime = solver->setupChrono();
            double solverTime = solver->solveCrono(b_local, x);
            
            if( !solver->stats.iterations.empty() ) {
                std::string filename = sconf->id;
                save_stats( filename, solver->stats, *sconf, reservoir.grid);
            }
            auto errr = testSolution(A.get(), b.data(), x.data());

            fprintf(stderr, "%s %s %.8g %.8g %.8g %d\n", filenameyaml.c_str(), sconf->id.c_str(), setupTime, solverTime, errr,  solver->stats.final_iter  );
        } catch (const std::exception& e) {
            printf("Erro ao executar solver %s: %s\n", sconf->id.c_str(), e.what());
        }
    }



    printf("\n--- Finalizando e Gerando Relatórios ---\n");

    std::string report = generateLatexReport(reservoir, *A);
    //outReport << report;
    //outReport.close();

   

    if (A->ia) { free(A->ia); free(A->ja); free(A->vals); }

    MPI_Finalize();
    return 0;
}
