#pragma once
#include <memory>
#include <vector>
#include <tuple>
#include <iostream>

// Inclua o adapter do AMGCL para ler ponteiros brutos C-style como matrizes CRS
#include <amgcl/util.hpp>
#include <amgcl/adapter/crs_tuple.hpp>
// Inclua o seu arquivo do skyline_lu
#include "amgcl/solver/skyline_lu.hpp" // Ajuste o caminho conforme necessário

#include "petromat_solver.h"


class SkylineLUSolver : public Solver {
private:
    std::unique_ptr<amgcl::solver::skyline_lu<double>> lu_solver;

public:
    SkylineLUSolver() : Solver() {
        this->maxiter = 1;  
        this->tol = 0.0;    
    }

    SkylineLUSolver(std::shared_ptr<const CSRMatrix> A) 
        : Solver(A, 0.0, 1) 
    {
        // setup();
    }

    ~SkylineLUSolver() override = default;

    void setup() override {
        if (!this->A) {
            return;
        }

        // Utilizando amgcl::make_iterator_range para criar iteradores válidos
        // a partir dos ponteiros brutos (usando A->nnz ou A->ia[A->n] para o tamanho)
        auto ptr_range = amgcl::make_iterator_range(this->A->ia, this->A->ia + this->A->n + 1);
        auto col_range = amgcl::make_iterator_range(this->A->ja, this->A->ja + this->A->nnz);
        auto val_range = amgcl::make_iterator_range(this->A->vals, this->A->vals + this->A->nnz);

        // Agora a tupla contém ranges válidas em vez de ponteiros brutos
        auto amgcl_matrix_view = std::tie(this->A->n, ptr_range, col_range, val_range);

        // Instancia a fatoração LU
        lu_solver = std::make_unique<amgcl::solver::skyline_lu<double>>(amgcl_matrix_view);
    }

    void solve(const std::vector<double>& b, std::vector<double>& x) override {
        if (!lu_solver) {
            // std::cerr << "Aviso: setup() não foi chamado. Chamando agora..." << std::endl;
            setup();
        }

        if (lu_solver) {
            // O AMGCL sobrescreve a sintaxe do operator() para realizar o solve (L^-1 * U^-1 * b)
            (*lu_solver)(b, x);
            
            // Opcional: Atualizar os stats
            this->stats.add(1, 0.0); // 1 iteração (direto), 0 de erro residual
        } else {
            std::cerr << "Aviso: solver SKYLINE ERROR" << std::endl;
        }
    }
};