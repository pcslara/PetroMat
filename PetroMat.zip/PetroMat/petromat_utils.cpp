#include <cstdlib>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string>
#include <time.h>

#include "petromat_utils.h"
#include "petromat_types.h"
#include "petromat_config.h"
/**
 * Saves a CSRMatrix to a file in the Matrix Market Coordinate format.
 * @param filename Name of the output file (usually .mtx)
 * @param A Pointer to the CSRMatrix
 * @return 0 on success, 1 on file error
 */
int save_csrmatrix(const std::string& filename, const CSRMatrix *A, ReservoirModel r ) {
    FILE *f = fopen((filename + ".stat").c_str(), "w");
    if (f == NULL) {
        fprintf(stderr, "[ERROR] Could not open file %s for writing.\n", filename.c_str());
        return 1;
    }
     fprintf(f, "%d %d %d\n", r.grid.nx, r.grid.ny, r.grid.nz );
    // 1. Write the Header
    // 'coordinate' means we list (row, col, val)
    // 'real' means double precision
    // 'general' means the matrix is not necessarily symmetric
    fprintf(f, "%%%%MatrixMarket matrix coordinate real general\n");

    // 2. Write the metadata (Rows, Columns, Non-zeros)
    // For a square Laplacian, Rows = Cols = A->n
    fprintf(f, "%d %d %d\n", A->n, A->n, A->nnz);

    // 3. Write the entries
    // We iterate through the CSR rows using the row pointer (ia)
    for (int i = 0; i < A->n; i++) {
        //ia[i] to ia[i+1] gives the range of columns/values for row i
        for (int k = A->ia[i]; k < A->ia[i + 1]; k++) {
            // Matrix Market is 1-indexed: i+1 and ja[k]+1
            fprintf(f, "%d %d %.12e\n", i + 1, A->ja[k] + 1, A->vals[k]);
        }
    }

    fclose(f);
    return 0;
}



int printm(const CSRMatrix *A) {
      for (int i = 0; i < A->n; i++) {
        //ia[i] to ia[i+1] gives the range of columns/values for row i
        for (int k = A->ia[i]; k < A->ia[i + 1]; k++) {
            // Matrix Market is 1-indexed: i+1 and ja[k]+1
            printf("%d %d %.2f\n", i , A->ja[k] , A->vals[k]);
        }
    }

    return 0;
}


double randn( double min, double max ) {
    return ((double)rand() / RAND_MAX) * (max - min) + min; 
}


void export_k_map(const char * filename, const double * K, int nx, int ny, int nz) {
    FILE* f = fopen(filename, "w");
    if (!f) return;
    fprintf(f, "%d,%d,%d\n", nx, ny, nz ); 
    // Cabeçalho para o Pandas
    fprintf(f, "k,j,i,perm\n"); 
    
    for (int k = 0; k < nz; k++) {
        for (int j = 0; j < ny; j++) {
            for (int i = 0; i < nx; i++) {
                // Mesma indexação que usamos na matriz A
                int idx = i + j * nx + k * (nx * ny);
                fprintf(f, "%d,%d,%d,%.8e\n", k, j, i, K[idx]);
            }
        }
    }
    fclose(f);
    printf(">> Campo de permeabilidade exportado para: %s\n", filename );
}


double randn() {
    static int haveSpare = 0;
    static double spare;

    if (haveSpare) {
        haveSpare = 0;
        return spare;
    }

    haveSpare = 1;
    double u, v, s;
    do {
        u = (double)rand() / RAND_MAX * 2.0 - 1.0;
        v = (double)rand() / RAND_MAX * 2.0 - 1.0;
        s = u*u + v*v;
    } while (s >= 1.0 || s == 0.0);

    s = sqrt(-2.0 * log(s) / s);
    spare = v * s;
    return u * s;
}


double covariance(double h, double var, double a, double v) {
    return var * exp(-3.0 * pow(fabs(h) / a, v));
}

int cholesky(double *A, double *L, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j <= i; j++) {
            double sum = A[IDXK(i,j,n)];
            for (int k = 0; k < j; k++)
                sum -= L[IDXK(i,k,n)] * L[IDXK(j,k,n)];

            if (i == j) {
                if (sum <= 0.0) return -1;
                L[IDXK(i,j,n)] = sqrt(sum);
            } else {
                L[IDXK(i,j,n)] = sum / L[IDXK(j,j,n)];
            }
        }
        for (int j = i+1; j < n; j++)
            L[IDXK(i,j,n)] = 0.0;
    }
    return 0;
}

std::shared_ptr<CSRMatrix> read_matrix_market(std::string input_matrix) {
    std::ifstream file(input_matrix);
    if (!file.is_open()) {
        std::cerr << "Erro ao abrir o arquivo: " << input_matrix << std::endl;
        return nullptr;
    }

    std::string line;
    bool is_symmetric = false;

    // 1. Processa a primeira linha (cabeçalho)
    if (std::getline(file, line)) {
        // Verifica se a matriz informa ser simétrica
        if (line.find("symmetric") != std::string::npos) {
            is_symmetric = true;
        }
    }

    // 2. Ignora os comentários (linhas que começam com '%')
    while (std::getline(file, line) && line.length() > 0 && line[0] == '%') {
        // Apenas consumindo as linhas
    }

    // 3. Lê as dimensões (Linhas M, Colunas N, Não-zeros L) da primeira linha sem '%'
    int M, N, L;
    std::stringstream ss(line);
    ss >> M >> N >> L;

    // Estrutura temporária para armazenar em formato Coordinate (COO)
    struct Element { int row, col; double val; };
    std::vector<Element> elements;
    
    // Se for simétrica, precisaremos do dobro do espaço para espelhar os valores
    elements.reserve(is_symmetric ? 2 * L : L);

    // 4. Lê os dados
    for (int i = 0; i < L; ++i) {
        int r, c;
        double v;
        file >> r >> c >> v;
        
        r--; c--; // Converte de 1-based para 0-based (C/C++)
        
        elements.push_back({r, c, v});
        
        // Espelha o valor se for simétrica e não pertencer à diagonal principal
        if (is_symmetric && r != c) {
            elements.push_back({c, r, v});
        }
    }
    file.close();

    // 5. Ordena os elementos em Row-Major (linha primária, coluna secundária)
    std::sort(elements.begin(), elements.end(), [](const Element& a, const Element& b) {
        if (a.row != b.row) return a.row < b.row;
        return a.col < b.col;
    });

    int actual_nnz = elements.size();

    // 6. Aloca a estrutura CSR mantendo a coerência com o uso de malloc do seu struct
    auto csr = std::make_shared<CSRMatrix>();
    csr->n = M;
    csr->nnz = actual_nnz;
    csr->ia = (int*)malloc((M + 1) * sizeof(int));
    csr->ja = (int*)malloc(actual_nnz * sizeof(int));
    csr->vals = (double*)malloc(actual_nnz * sizeof(double));

    // Inicializa o vetor IA com zeros
    std::fill(csr->ia, csr->ia + M + 1, 0);

    // Conta o número de elementos por linha
    for (const auto& e : elements) {
        csr->ia[e.row + 1]++;
    }

    // Transforma contagens em ponteiros de linha (Prefix sum)
    for (int i = 0; i < M; i++) {
        csr->ia[i + 1] += csr->ia[i];
    }

    // 7. Preenche JA e VALS usando o vetor IA como índice base momentâneo
    std::vector<int> current_row_tail(csr->ia, csr->ia + M);
    for (const auto& e : elements) {
        int dest = current_row_tail[e.row]++;
        csr->ja[dest] = e.col;
        csr->vals[dest] = e.val;
    }

    return csr;
}

void read_vector(std::vector<double>& v, int expected_size, std::string filename) {
    // Garante que o vetor comece vazio
    v.clear();
    
    // Aloca memória previamente para evitar realocações custosas
    if (expected_size > 0) {
        v.reserve(expected_size);
    }

    std::ifstream file(filename);
    
    // Verifica se o arquivo foi aberto corretamente
    if (!file.is_open()) {
        throw std::runtime_error("Erro: Não foi possível abrir o arquivo '" + filename + "'.");
    }

    double value;
    // Lê o arquivo linha a linha (o operador >> pula espaços e quebras de linha automaticamente)
    while (file >> value) {
        v.push_back(value);
    }

    // Verifica se houve algum erro de leitura que não seja o fim do arquivo (EOF)
    if (!file.eof() && file.fail()) {
        throw std::runtime_error("Erro: Falha de formatação ao ler os dados do arquivo '" + filename + "'.");
    }

    file.close();

    // Valida o tamanho do vetor final
    if (v.size() != static_cast<size_t>(expected_size)) {
        throw std::runtime_error("Erro: O tamanho do vetor lido (" + std::to_string(v.size()) + 
                                 ") nao corresponde ao esperado (" + std::to_string(expected_size) + ").");
    }
}

void save_stats( const std::string filename, const SolverStats & stats, const SolverConfig& config, Grid grid ) {
    FILE *f = fopen((filename + ".stat").c_str(), "w");
    if (f == NULL) {
        fprintf(stderr, "[ERROR] Could not open file %s for writing.\n", filename.c_str());
        return;
    }
    if (!f) return;
    fprintf(f, "# %s (%.2lf)\n",config.id.c_str(), stats.solve_time ); 
    for( int i = 0; i < stats.iterations.size(); i++ ) {
        fprintf(f, "%d %.6g\n", stats.iterations[i], stats.residuals[i] );
    }
    fclose(f);


    if (stats.iter_error.empty()) return;

    std::string err_filename = filename + "_iter_error.dat";
    f = fopen(err_filename.c_str(), "w");
    if (f == NULL) {
        fprintf(stderr, "[ERROR] Could not open file %s for writing.\n", err_filename.c_str());
        return;
    }

    fprintf(f, "# %s - Iteration Errors (Iter, Err_0, Err_1, ..., Err_N)\n", config.id.c_str()); 

    fprintf(f, "%d %d %d\n", grid.nx, grid.ny, grid.nz ); 
    
    // Itera sobre o std::map (que já é ordenado pelas chaves/iterações)
    for (const auto& pair : stats.iter_error) {
        int iter = pair.first;
        const std::vector<double>& error_vec = pair.second;

        fprintf(f, "%d", iter);
        for (double err_val : error_vec) {
            fprintf(f, " %.6g", err_val);
        }
        fprintf(f, "\n");
    }
    
    fclose(f);
}

double norm_inf( const std::vector< double >& v ) {
    double max_value = -1;
    for( long i = 0; i < v.size(); i++ ) {
        max_value = std::max( max_value, std::abs( v[i]) );
    }
    return max_value;
}


bool load_perm_csv(const std::string& filename, std::vector<double>& K, int expected_nx, int expected_ny, int expected_nz) {
    FILE* file = fopen(filename.c_str(), "r");
    if (!file) {
        std::cerr << "Erro: Não foi possível abrir o arquivo " << filename << std::endl;
        return false;
    }

    int nx, ny, nz;
    // 1. Lê o cabeçalho de dimensões: "nx,ny,nz"
    if (fscanf(file, "%d,%d,%d\n", &nx, &ny, &nz) != 3) {
        std::cerr << "Erro ao ler o cabeçalho de dimensões." << std::endl;
        fclose(file);
        return false;
    }

    // Validação de segurança
    if (nx != expected_nx || ny != expected_ny || nz != expected_nz) {
        std::cerr << "Erro: Dimensões do arquivo (" << nx << "x" << ny << "x" << nz 
                  << ") não coincidem com o grid (" << expected_nx << "x" << expected_ny 
                  << "x" << expected_nz << ")." << std::endl;
        fclose(file);
        return false;
    }

    // 2. Pula a linha do cabeçalho das colunas: "k,j,i,perm"
    char dummy[256];
    if (!fgets(dummy, sizeof(dummy), file)) {
        fclose(file);
        return false;
    }

    int k, j, i;
    double val;
    long long count = 0;
    int nxy = nx * ny;

    // 3. Lê cada linha: "k,j,i,perm"
    // Usamos fscanf que é significativamente mais rápido que iostream para 1M+ de linhas
    while (fscanf(file, "%d,%d,%d,%lf\n", &k, &j, &i, &val) == 4) {
        // Mapeamento linear i + j*nx + k*nxy
        int row_global = i + (j * nx) + (k * nxy);
        
        if (row_global < K.size()) {
            K[row_global] = val;
            count++;
        }
    }

    fclose(file);
    std::cout << "Sucesso: " << count << " valores de permeabilidade carregados." << std::endl;
    return (count == (long long)nx * ny * nz);
}