#ifndef PETROMAT_GEOLOGY_H
#define PETROMAT_GEOLOGY_H

#include "petromat_types.h"

void covariance_matrix3D(
                            double Lx, double Ly, double Lz,
                            int nx, int ny, int nz,
                            double R[3][3], double sigma[3],
                            double var, double a, double v,
                            double *MatCov
);


int permeability_matrix( double * K, // OUTPUT PREAllocated with nx * ny * nz elements
                         double Lx, double Ly, double Lz,
                         int nx, int ny, int nz,
                         double R[3][3], double sigma[3],
                         double kmin, double kmax, double a, double v
); 



int generate_permeability_cholesky(ReservoirModel *res, StatisticPermeabilityParams params, std::vector<double>& out_k_map);
StatisticPermeabilityParams create_cholesky_params(double sigma[3], double diagR[3],double a, double v);
int generate_permeability_fft(ReservoirModel *res, StatisticPermeabilityParams params, std::vector<double>& out_k_map);
int generate_permeability_fft_3d(ReservoirModel *res, Permeability params, std::vector<double>& out_k_map);
#endif