#ifndef PETROMAT_ASSEMBLY_H
#define PETROMAT_ASSEMBLY_H

#include "petromat_types.h"



CSRMatrix sparse_laplacian_with_K(
    double *K, int nx, int ny, int nz,
    double dx, double dy, double dz,
    double cx, double cy, double cz,
    const BoundaryConditions& bc, double *b
);

CSRMatrix sparse_laplacian_with_K3D(
    double *K3D, int nx, int ny, int nz,
    double dx, double dy, double dz,
    double cx, double cy, double cz,
    const BoundaryConditions& bc, double *b
);
#endif