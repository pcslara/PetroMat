#ifndef PETROMAT_UTILS_H
#define PETROMAT_UTILS_H
#include <iostream>
#include <vector>
#include <string>
#include <cstdio> // Para FILE, fopen, fscanf
#include "petromat_solver.h"
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <memory>
#define IDXK(i,j,n) ((i)*(n)+(j))

#include "petromat_types.h"

double norm_inf( const std::vector< double >& v );

double randn();
double covariance(double h, double var, double a, double v);
int cholesky(double *A, double *L, int n);
int save_csrmatrix(const char *filename, const CSRMatrix *A, ReservoirModel r);
int printm(const CSRMatrix *A);
void export_k_map(const char * filename, const double * K, int nx, int ny, int nz) ;
void save_stats( const std::string filename, const SolverStats & stats, const SolverConfig& config, Grid grid );
std::shared_ptr<CSRMatrix> read_matrix_market(std::string input_matrix);
void read_vector( std::vector<double > & v, int expected_size, std::string filename );



bool load_perm_csv(const std::string& filename, std::vector<double>& K, int expected_nx, int expected_ny, int expected_nz);
#endif