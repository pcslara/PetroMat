#pragma once

#include "petromat_types.h"
#include <vector>
#include <memory>
#include <chrono>
#include <map>


enum StatusSolver { INITIALIZED = 0, CONVERGED = 1, DIVERGED = 2, MAXITERREACH = 3};

struct SolverStats {
    std::vector<int>    iterations;
    std::vector<double> residuals;
    double              solve_time; // Tempo em segundos
    double              setup_time; // Tempo em segundos
    int                 final_iter = 0;
    StatusSolver        status = INITIALIZED;
    
    std::map< int, std::vector<double>> iter_error;
    int                 inter_error_freq = 10;

    void clear() {
        iterations.clear();
        residuals.clear();
        solve_time = 0.0;
    }
    void add(int iter, double res) {
        iterations.push_back(iter);
        residuals.push_back(res);
    }

    void addIterError( const std::vector< double >& x, const std::vector< double >& x_ref, int iter ) {
        
        //if( x_ref ) {
            std::vector< double > error( x.size() );
            for( int i = 0; i < x.size(); i++ ) {
                error[i] = std::abs( x[i] - x_ref[i] );
            }
            iter_error[ iter ] = error;
        //}
    }


};



class Preconditioner {
public:
    virtual ~Preconditioner() = default;

    virtual void setup( const CSRMatrix& A) = 0;

    virtual void apply(const std::vector<double>& y,
                       std::vector<double>& z) const = 0;
    virtual std::shared_ptr<Preconditioner> clone() const = 0;
};

class Solver {
public:
    int maxiter;
    double tol;

    // Mudança de referência para shared_ptr
    std::shared_ptr<const CSRMatrix> A; 
    std::shared_ptr<Preconditioner>  C;

    SolverStats stats;

    bool verbose = true;

    std::shared_ptr<std::vector< double> > x_ref = nullptr;

    // Construtor agora aceita o shared_ptr
    Solver(std::shared_ptr<const CSRMatrix> A, double tol, int maxiter)
        : A(A), tol(tol), maxiter(maxiter) {}

    Solver() {}

    virtual ~Solver() = default;

    void setPreconditioner(std::shared_ptr<Preconditioner> precond) {
        C = precond;
    }

    void setOperator(std::shared_ptr<const CSRMatrix> newA) {
        this->A = newA;
     
    }

    virtual void setup() = 0;
    virtual void solve(const std::vector<double>& b, std::vector<double>& x) = 0;

    double solveCrono(const std::vector<double>& b, std::vector<double>& x) {
        stats.clear();
        
        auto start = std::chrono::high_resolution_clock::now();
        
        // Chama a implementação específica do solver (CG, GMRES, etc)
        solve(b, x);
        
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> diff = end - start;
        stats.solve_time = diff.count();
        
        //if (verbose) {
            printf("Solver TIME: %.4f s\n", stats.solve_time);
        //}
        return stats.solve_time;
    }

    double setupChrono() {
        stats.clear();
        
        auto start = std::chrono::high_resolution_clock::now();
        
        setup();
        
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> diff = end - start;
        stats.setup_time = diff.count();
        
        //if (verbose) {
            printf("Setup TIME: %.4f s\n", stats.setup_time);
        //}
        return stats.setup_time;
    }
    
    void setTolerance(double tol) { this->tol = tol; }
    void setMaxIter(int maxiter) { this->maxiter = maxiter; }
    void setReferenceSolution( const std::shared_ptr<std::vector<double>>& x_ref ) { this->x_ref = x_ref; }
};