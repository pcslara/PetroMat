#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <iomanip>
#include <algorithm>

#include "petromat_types.h"

using namespace std;

string trim(const string &s) {
    auto start = s.find_first_not_of(" \t");
    auto end   = s.find_last_not_of(" \t");
    if(start == string::npos) return "";
    return s.substr(start, end - start + 1);
}

string value_after_colon(const string& line) {
    auto pos = line.find(":");
    if(pos == string::npos) return "";
    return trim(line.substr(pos+1));
}

bool starts_with(const string& s, const string& p) {
    return s.rfind(p,0)==0;
}

BoundaryType parse_bc_type(const string& s){
    if(s=="dirichlet") return BoundaryType::Dirichlet;
    if(s=="neumann") return BoundaryType::Neumann;
    throw runtime_error("Unknown BC type");
}

WellType parse_well_type(const string& s){
    if(s=="injector") return WellType::Injector;
    if(s=="producer") return WellType::Producer;
    throw runtime_error("Unknown well type");
}
ReservoirModel parse_yaml(const std::string& filename)
{
    ReservoirModel m;

    std::ifstream in(filename);
    if(!in) throw std::runtime_error("cannot open file");

    std::string line;
    std::string section;
    std::string bc_face;

    WellModel current_well;
    bool reading_well = false;

    while(std::getline(in,line))
    {
        line = trim(line);
        if(line.empty()) continue;

        // top level sections
        if(line=="grid:") { section="grid"; continue; }
        if(line=="domain:") { section="domain"; continue; }
        if(line=="permeability:") { section="perm"; continue; }
        if(line=="boundary_conditions:") { section="bc"; continue; }
        if(line=="wells:") { section="wells"; continue; }
        if(line=="solver:") { section="solver"; continue; }

        // ---------------- GRID ----------------
        if(section=="grid")
        {
            if(starts_with(line,"nx:")) m.grid.nx = stoi(value_after_colon(line));
            else if(starts_with(line,"ny:")) m.grid.ny = stoi(value_after_colon(line));
            else if(starts_with(line,"nz:")) m.grid.nz = stoi(value_after_colon(line));
        }

        // ---------------- DOMAIN ----------------
        else if(section=="domain")
        {
            if(starts_with(line,"lx:")) m.domain.lx = stod(value_after_colon(line));
            else if(starts_with(line,"ly:")) m.domain.ly = stod(value_after_colon(line));
            else if(starts_with(line,"lz:")) m.domain.lz = stod(value_after_colon(line));
        }

        // ---------------- PERMEABILITY ----------------
        else if(section=="perm")
        {
            if(starts_with(line,"kx:"))      m.permeability.kx = stod(value_after_colon(line));
            else if(starts_with(line,"ky:")) m.permeability.ky = stod(value_after_colon(line));
            else if(starts_with(line,"kz:")) m.permeability.kz = stod(value_after_colon(line));
            else if(starts_with(line,"kz:")) m.permeability.kz = stod(value_after_colon(line));
            else if(starts_with(line,"kmin:")) m.permeability.kmin = stod(value_after_colon(line));
            else if(starts_with(line,"kmax:")) m.permeability.kmax = stod(value_after_colon(line));
            else if(starts_with(line,"range:")) m.permeability.range = stod(value_after_colon(line));
            else if(starts_with(line,"smoothness:")) m.permeability.smoothness = stod(value_after_colon(line));
            else if(starts_with(line, "R:")) {
                std::stringstream ss(value_after_colon(line));
                ss >> m.permeability.R[0][0] >> m.permeability.R[1][1] >> m.permeability.R[2][2];
            }
            else if(starts_with(line, "sigma:")) {
                std::stringstream ss(value_after_colon(line));
                ss >> m.permeability.sigma[0] >> m.permeability.sigma[1] >> m.permeability.sigma[2];
            }
        }

        // ---------------- BC FACE DETECTION ----------------
        else if(section=="bc")
        {
            if(starts_with(line,"xmin:")) { bc_face="xmin"; continue; }
            if(starts_with(line,"xmax:")) { bc_face="xmax"; continue; }
            if(starts_with(line,"ymin:")) { bc_face="ymin"; continue; }
            if(starts_with(line,"ymax:")) { bc_face="ymax"; continue; }
            if(starts_with(line,"zmin:")) { bc_face="zmin"; continue; }
            if(starts_with(line,"zmax:")) { bc_face="zmax"; continue; }

            BoundaryCondition* bc = nullptr;

            if(bc_face=="xmin") bc=&m.boundary_conditions.xmin;
            else if(bc_face=="xmax") bc=&m.boundary_conditions.xmax;
            else if(bc_face=="ymin") bc=&m.boundary_conditions.ymin;
            else if(bc_face=="ymax") bc=&m.boundary_conditions.ymax;
            else if(bc_face=="zmin") bc=&m.boundary_conditions.zmin;
            else if(bc_face=="zmax") bc=&m.boundary_conditions.zmax;

            if(!bc) continue;

            if(starts_with(line,"type:"))
                bc->type = parse_bc_type(value_after_colon(line));

            else if(starts_with(line,"value:"))
                bc->value = stod(value_after_colon(line));
        }

        // ---------------- WELLS ----------------
        else if(section=="wells")
        {
            if(starts_with(line,"-"))
            {
                if(reading_well)
                    m.wells.push_back(current_well);

                current_well = WellModel();
                reading_well = true;

                line = trim(line.substr(1));
                if(line.empty()) continue;
            }

            if(starts_with(line,"type:"))
                current_well.type = parse_well_type(value_after_colon(line));

            else if(starts_with(line,"i:"))
                current_well.i = stoi(value_after_colon(line));

            else if(starts_with(line,"j:"))
                current_well.j = stoi(value_after_colon(line));

            else if(starts_with(line,"k:"))
                current_well.k = stoi(value_after_colon(line));

            else if(starts_with(line,"rate:"))
                current_well.rate = stod(value_after_colon(line));

            else if(starts_with(line,"bhp:"))
                current_well.bhp = stod(value_after_colon(line));
        }
        else if(section=="solver") {
          /*  if(starts_with(line,"name:")) {
                if( value_after_colon(line) == "CG" ) {
                    m.solver_type = SolverType::CG;
                } else if( value_after_colon(line) == "PCG" ) {
                    m.solver_type = SolverType::PCG_IC0;
                } else if( value_after_colon(line) == "AMG" ) {
                    m.solver_type = SolverType::AMG;
                } else {
                    cerr << "Error on solver name" << endl;
                }
            } else if(starts_with(line,"tol:")) {
                m.tol = stod( value_after_colon(line) );
            } else if(starts_with(line,"maxiter:")) {
                m.max_iter = stod( value_after_colon(line) );
            }*/
        }
            
    }

    if(reading_well)
        m.wells.push_back(current_well);

    return m;
}

void print_reservoir(const ReservoirModel& r)
{
    std::cout << "\n===== Reservoir Model =====\n";

    std::cout << "\nGrid:\n";
    std::cout << "  nx: " << r.grid.nx << "\n";
    std::cout << "  ny: " << r.grid.ny << "\n";
    std::cout << "  nz: " << r.grid.nz << "\n";

    std::cout << "\nDomain:\n";
    std::cout << "  lx: " << r.domain.lx << "\n";
    std::cout << "  ly: " << r.domain.ly << "\n";
    std::cout << "  lz: " << r.domain.lz << "\n";

    std::cout << "\nPermeability:\n";
    std::cout << "  kx: " << r.permeability.kx << "\n";
    std::cout << "  ky: " << r.permeability.ky << "\n";
    std::cout << "  kz: " << r.permeability.kz << "\n";
    std::cout << "  kmin: " << r.permeability.kmin << "\n";
    std::cout << "  kmax: " << r.permeability.kmax << "\n";
    std::cout << "  range: " << r.permeability.range << "\n";
    std::cout << "  smoothness: " << r.permeability.smoothness << "\n";
    std::cout << "  sigma: " << r.permeability.sigma[0] << " " << r.permeability.sigma[1] << " " << r.permeability.sigma[2] << "\n";
    std::cout << "  R: " << r.permeability.R[0][0] << " " << r.permeability.R[1][1] << " " << r.permeability.R[2][2] << "\n";
    
    
    std::cout << "\nBoundary Conditions:\n";

    auto print_bc = [](const char* name, const BoundaryCondition& bc)
    {
        std::cout << "  " << name << " -> ";

        if(bc.type == BoundaryType::Dirichlet)
            std::cout << "Dirichlet";
        else
            std::cout << "Neumann";

        std::cout << " (value=" << bc.value << ")\n";
    };

    print_bc("xmin", r.boundary_conditions.xmin);
    print_bc("xmax", r.boundary_conditions.xmax);
    print_bc("ymin", r.boundary_conditions.ymin);
    print_bc("ymax", r.boundary_conditions.ymax);
    print_bc("zmin", r.boundary_conditions.zmin);
    print_bc("zmax", r.boundary_conditions.zmax);

    std::cout << "\nWells:\n";

    for(const auto& w : r.wells)
    {
        std::cout << "  well:\n";

        std::cout << "    type: ";
        if(w.type == WellType::Injector)
            std::cout << "injector\n";
        else
            std::cout << "producer\n";

        std::cout << "    cell: (" 
                  << w.i << ", "
                  << w.j << ", "
                  << w.k << ")\n";

        std::cout << "    rate: " << w.rate << "\n";
        std::cout << "    bhp: " << w.bhp << "\n";
    }

    std::cout << "\n===========================\n";
}





std::string boundaryTypeToString(BoundaryType t) {
    if (t == BoundaryType::Dirichlet) return "Dirichlet";
    return "Neumann";
}
/*
std::string solverTypeToString(SolverType t) {
    switch (t) {
        //case SolverType::CG: return "CG";
        //case SolverType::PCG_IC0: return "PCG (IC(0))";
        //case SolverType::AMG: return "AMG";
        default: return "Not defined";
    }
}*/

std::string generateLatexReport( ReservoirModel& model, const CSRMatrix& A) {

    std::ostringstream oss;
    oss << std::fixed << std::setprecision(2);

    oss << "\\begin{frame}{Simulation Parameters}\n";

    // ---------------- GRID ----------------
    oss << "\\textbf{Grid}\n";
    oss << "\\begin{itemize}\n";
    oss << "\\item Dimensions: $" 
        << model.grid.nx << " \\times "
        << model.grid.ny << " \\times "
        << model.grid.nz << "$\n";
    oss << "\\item Total cells: $" << model.grid.num_cells() << "$\n";
    oss << "\\end{itemize}\n";

    // ---------------- DOMAIN ----------------
    oss << "\\textbf{Domain}\n";
    oss << "\\begin{itemize}\n";
    oss << "\\item Size: $("
        << model.domain.lx << ", "
        << model.domain.ly << ", "
        << model.domain.lz << ")$\n";

    oss << "\\item Cell size: $("
        << model.domain.dx(model.grid) << ", "
        << model.domain.dy(model.grid) << ", "
        << model.domain.dz(model.grid) << ")$\n";
    oss << "\\end{itemize}\n";

    // ---------------- PERMEABILITY ----------------
    oss << "\\textbf{Permeability}\n";
    oss << "\\begin{itemize}\n";
    oss << "\\item Principal values: $k_x=" << model.permeability.kx
        << ",\\; k_y=" << model.permeability.ky
        << ",\\; k_z=" << model.permeability.kz << "$\n";

    oss << "\\item Range: $[" << model.permeability.kmin
        << ", " << model.permeability.kmax << "]$\n";

    oss << "\\item Correlation range ($a$): " << model.permeability.range << "\n";
    oss << "\\item Smoothness ($\\nu$): " << model.permeability.smoothness << "\n";

    oss << "\\item $\\sigma$: $("
        << model.permeability.sigma[0] << ", "
        << model.permeability.sigma[1] << ", "
        << model.permeability.sigma[2] << ")$\n";

    oss << "\\end{itemize}\n";

    // ---------------- BOUNDARY CONDITIONS ----------------
    oss << "\\subsection{Boundary Conditions}\n";
    oss << "\\begin{itemize}\n";

    oss << "\\item $x_{min}$: " << boundaryTypeToString(model.boundary_conditions.xmin.type)
        << ", value = " << model.boundary_conditions.xmin.value << "\n";

    oss << "\\item $x_{max}$: " << boundaryTypeToString(model.boundary_conditions.xmax.type)
        << ", value = " << model.boundary_conditions.xmax.value << "\n";

    oss << "\\item $y_{min}$: " << boundaryTypeToString(model.boundary_conditions.ymin.type)
        << ", value = " << model.boundary_conditions.ymin.value << "\n";

    oss << "\\item $y_{max}$: " << boundaryTypeToString(model.boundary_conditions.ymax.type)
        << ", value = " << model.boundary_conditions.ymax.value << "\n";

    oss << "\\item $z_{min}$: " << boundaryTypeToString(model.boundary_conditions.zmin.type)
        << ", value = " << model.boundary_conditions.zmin.value << "\n";

    oss << "\\item $z_{max}$: " << boundaryTypeToString(model.boundary_conditions.zmax.type)
        << ", value = " << model.boundary_conditions.zmax.value << "\n";

    oss << "\\end{itemize}\n";

    // ---------------- WELLS ----------------
    if (!model.wells.empty()) {
        oss << "\\subsection{Wells}\n";
        oss << "\\begin{itemize}\n";
        for (size_t i = 0; i < model.wells.size(); ++i) {
            const auto& w = model.wells[i];
            oss << "\\item Well " << i << ": ("
                << w.i << ", " << w.j << ", " << w.k << "), ";

            oss << (w.type == WellType::Injector ? "Injector" : "Producer");

            oss << ", rate=" << w.rate << ", bhp=" << w.bhp << "\n";
        }
        oss << "\\end{itemize}\n";
    }

    // ---------------- MATRIX ----------------
    oss << "\\subsection{Linear System}\n";
    oss << "\\begin{itemize}\n";
    oss << "\\item Size: $" << A.n << " \\times " << A.n << "$\n";
    oss << "\\item Non-zeros: $" << A.nnz << "$\n";

    double sparsity = 1.0 - (double)A.nnz / (double(A.n) * double(A.n));
    oss << "\\item Sparsity: " << sparsity * 100.0 << "\\% \n";
    oss << "\\end{itemize}\n";

    // ---------------- SOLVER ----------------
    oss << "\\subsection{Solver}\n";
    oss << "\\begin{itemize}\n";
    //oss << "\\item Method: " << solverTypeToString(model.solver_type) << "\n";
    //oss << "\\item Tolerance: $" << model.tol << "$\n";
    //oss << "\\item Max iterations: $" << model.max_iter << "$\n";
    //oss << "\\end{itemize}\n";

    return oss.str();
}