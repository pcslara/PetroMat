#pragma once

#include "petromat_solver.h"
#include <algorithm>
#include <iostream>
#include <memory>
#include <cmath>

class JacobiPreconditioner2 : public Preconditioner {

public:
    std::vector<double> inv_diag; // Armazena 1/A[i][i] para performance
    double omega;                 // Fator de amortecimento (weight)

    // Para suavização (Relaxed Jacobi), usa-se valores < 1.0.
    JacobiPreconditioner2(double w = 1.0) : omega(w) {}

    void setup(const CSRMatrix& A) override {
        int n = A.n;
        inv_diag.assign(n, 0.0);

        for (int i = 0; i < n; i++) {
            double diag_val = 0.0;
            bool found = false;

            // Busca o elemento diagonal na linha i da matriz CSR
            for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
                if (A.ja[idx] == i) {
                    diag_val = A.vals[idx];
                    found = true;
                    break;
                }
            }

            // Tratamento para evitar divisão por zero
            if (!found || std::abs(diag_val) < 1e-15) {
                inv_diag[i] = 1.0; 
            } else {
                // Já armazenamos o valor invertido e multiplicado pelo peso
                // para que o 'apply' seja apenas uma multiplicação vetorial.
                inv_diag[i] = omega / diag_val;
            }
        }
    }

    void apply(const std::vector<double>& r,
               std::vector<double>& z) const override {
        int n = r.size();
        // A operação de Jacobi é simplesmente: z = omega * D⁻¹ * r
        for (int i = 0; i < n; i++) {
            z[i] = r[i] * inv_diag[i];
        }
    }
    std::shared_ptr<Preconditioner> clone() const override {
        return std::make_shared<JacobiPreconditioner2>(omega);
    }
    
};


class JacobiPreconditioner : public Preconditioner {
public:
    std::vector<double> inv_diag; // Armazena (omega / A[i][i]) para performance máxima
    double omega;                 // Fator de amortecimento (weight)

    // Se omega = 0.0 for passado, a classe aciona o cálculo do ótimo dinâmico
    JacobiPreconditioner(double w = 0.0) : omega(w) {}

    void setup(const CSRMatrix& A) override {
        int n = A.n;
        inv_diag.assign(n, 0.0);

        double max_eig = 0.0;

        // Passagem única para extrair a diagonal e aplicar Gershgorin
        for (int i = 0; i < n; i++) {
            double diag_val = 0.0;
            double row_sum_abs = 0.0;
            bool found = false;

            for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
                if (A.ja[idx] == i) {
                    diag_val = A.vals[idx];
                    found = true;
                } else {
                    row_sum_abs += std::abs(A.vals[idx]); // Acumula extra-diagonais
                }
            }

            // Tratamento para evitar divisão por zero
            if (!found || std::abs(diag_val) < 1e-15) {
                diag_val = 1.0; 
            }

            // Teorema de Gershgorin: Raio máximo do círculo
            double eig_estimate = (std::abs(diag_val) + row_sum_abs) / std::abs(diag_val);
            if (eig_estimate > max_eig) max_eig = eig_estimate;

            // Armazena 1/D provisoriamente
            inv_diag[i] = 1.0 / diag_val;
        }

        // Se o usuário passou 0.0, calibra o omega ideal para Multigrid
        if (omega <= 0.0) {
            if (max_eig > 0.0) {
                omega = 4.0 / (3.0 * max_eig);
            } 
        }
        // Embute o omega na diagonal. Assim o apply vira um simples z = vetor * vetor
        for (int i = 0; i < n; i++) {

            inv_diag[i] *= omega;
        }
    }

    // Assinatura mantida intacta e 'const' respeitado
    void apply(const std::vector<double>& r, std::vector<double>& z) const override {
        int n = r.size();
        for (int i = 0; i < n; i++) {
            z[i] = r[i] * inv_diag[i];
        }
    }

    std::shared_ptr<Preconditioner> clone() const override {
        return std::make_shared<JacobiPreconditioner>(omega);
    }
};
class ChebyshevSmoother : public Preconditioner {
public:
    std::vector<double> inv_diag; // Armazena 1.0 / A[i][i]
    std::vector<double> tau;      // Passos dinâmicos baseados nas raízes de Chebyshev
    const CSRMatrix* A_ptr;       // Ponteiro para a matriz (necessário no apply)
    
    int degree;                   // Grau do polinômio (número de iterações por apply)
    double eig_ratio;             // Razão lambda_max / lambda_min do espectro alvo

    // degree = 3 costuma ser o melhor compromisso para AMG.
    // eig_ratio = 10.0 para 2D, 12.0 para 3D (foca nas altas frequências).
    ChebyshevSmoother(int deg = 6, double ratio = 5.0) 
        : degree(deg), eig_ratio(ratio), A_ptr(nullptr) {}

    void setup(const CSRMatrix& A) override {
        A_ptr = &A;
        int n = A.n;
        inv_diag.assign(n, 0.0);

        double max_eig_estimate = 0.0;

        // Passo 1: Extrair a diagonal e estimar lambda_max de D^{-1}A
        // Para uma matriz M, os autovalores de D^{-1}A estão centrados em 1
        // com raio determinado pelos elementos fora da diagonal
        for (int i = 0; i < n; i++) {
            double diag_val = 0.0;
            double off_diag_sum = 0.0;
            
            for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
                if (A.ja[idx] == i) {
                    diag_val = A.vals[idx];
                } else {
                    off_diag_sum += std::abs(A.vals[idx]);
                }
            }
            
            if (std::abs(diag_val) < 1e-15) {
                diag_val = 1.0; 
            }
            
            inv_diag[i] = 1.0 / diag_val;
            
            // Para D^{-1}A: círculo de Gershgorin centrado em 1 com raio off_diag_sum/|diag|
            double radius = off_diag_sum / std::abs(diag_val);
            double local_max = 1.0 + radius;
            
            max_eig_estimate = std::max(max_eig_estimate, local_max);
        }

        // Passo 2: Definir os limites do espectro de altas frequências
        // lambda_max é o maior autovalor de D^{-1}A (geralmente próximo de 2 para Laplaciano)
        double l_max = max_eig_estimate;
        
        // lambda_min define onde começa o espectro de alta frequência
        // Queremos amortecer fortemente o intervalo [l_min, l_max]
        // l_min = l_max / eig_ratio (frequências acima de l_min são "altas")
        double l_min = l_max / eig_ratio;
        
        // Segurança: garantir que l_min seja positivo e menor que l_max
        if (l_min <= 0.0 || l_min >= l_max) {
            l_min = l_max * 0.1; // fallback para 10% do máximo
        }

        // Passo 3: Calcular os coeficientes tau usando polinômio de Chebyshev
        // O polinômio é otimizado para amortecer no intervalo [l_min, l_max]
        tau.resize(degree);
        
        // Parâmetros do mapeamento do intervalo [-1, 1] para [l_min, l_max]
        double center = (l_max + l_min) / 2.0;  // c2
        double radius = (l_max - l_min) / 2.0;  // c1
        
        const double pi = 3.14159265358979323846;
        
        for (int k = 0; k < degree; k++) {
            // Raízes do polinômio de Chebyshev T_degree no intervalo [-1, 1]
            // Essas raízes são onde o polinômio se anula
            double chebyshev_root = std::cos(pi * (2.0 * k + 1.0) / (2.0 * degree));
            
            // Mapeamento linear para [l_min, l_max]
            double root = center + radius * chebyshev_root;
            
            // O passo do método de Richardson/Jacobi ponderado é o inverso da raiz
            tau[k] = 1.0 / root;
        }
        
        // Opcional: imprimir informações de diagnóstico
        // std::cout << "Chebyshev smoother: l_max=" << l_max << ", l_min=" << l_min 
        //           << ", ratio=" << l_max/l_min << std::endl;
    }

    void apply(const std::vector<double>& r, std::vector<double>& z) const override {
        if (!A_ptr) return;
        
        int n = r.size();
        
        // z começa como zero (chute inicial padrão para suavizador em AMG)
        std::fill(z.begin(), z.end(), 0.0);
        
        // Vetor auxiliar para o resíduo
        std::vector<double> res = r;
        
        for (int k = 0; k < degree; k++) {
            // Se não for a primeira iteração, recalcula o resíduo: res = r - A*z
            if (k > 0) {
                // Calcula A*z e armazena em res como r - A*z
                for (int i = 0; i < n; i++) {
                    double ax = 0.0;
                    for (int idx = A_ptr->ia[i]; idx < A_ptr->ia[i+1]; idx++) {
                        ax += A_ptr->vals[idx] * z[A_ptr->ja[idx]];
                    }
                    res[i] = r[i] - ax;
                }
            }
            
            // Aplica o passo de Jacobi ponderado: z = z + tau[k] * D^{-1} * res
            for (int i = 0; i < n; i++) {
                z[i] += tau[k] * inv_diag[i] * res[i];
            }
        }
    }

    std::shared_ptr<Preconditioner> clone() const override {
        return std::make_shared<ChebyshevSmoother>(degree, eig_ratio);
    }
};

class L1JacobiPreconditioner : public Preconditioner {
public:
    std::vector<double> inv_diag; // Armazena 1.0 / D_L1
    double omega;                 // Opcional: para L1-Jacobi costuma-se fixar em 1.0

    L1JacobiPreconditioner(double w = 1.0) : omega(w) {}

    void setup(const CSRMatrix& A) override {
        int n = A.n;
        inv_diag.assign(n, 0.0);

        for (int i = 0; i < n; i++) {
            double l1_norm = 0.0;

            // Varre a linha para somar os valores absolutos (Norma L1)
            for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
                l1_norm += std::abs(A.vals[idx]);
            }

            // Tratamento contra matrizes corrompidas ou linhas vazias
            if (l1_norm < 1e-15) {
                inv_diag[i] = 1.0; 
            } else {
                // A grande mágica: em vez de 1/A_ii, guardamos 1/Norma_L1.
                // Isso cria um Damping local perfeito para cada variável.
                inv_diag[i] = omega / l1_norm;
            }
        }
    }

    void apply(const std::vector<double>& r, std::vector<double>& z) const override {
        int n = r.size();
        
        // A aplicação é idêntica ao Jacobi rápido. Nenhuma penalidade de performance!
        for (int i = 0; i < n; i++) {
            z[i] = r[i] * inv_diag[i];
        }
    }

    std::shared_ptr<Preconditioner> clone() const override {
        return std::make_shared<L1JacobiPreconditioner>(omega);
    }
};
class SPAI0Preconditioner : public Preconditioner {
public:
    std::vector<double> m_diag; // Armazena os valores da matriz diagonal M
    double omega;               // Fator de amortecimento (Damping factor)

    // Construtor agora aceita o omega. 
    // Valor padrão = 1.0 (SPAI-0 clássico sem amortecimento).
    // Para problemas difíceis, 0.66 ou 0.7 costuma ser o ponto doce.
    SPAI0Preconditioner(double w = 1.0) : omega(w) {}

    void setup(const CSRMatrix& A) override {
        int n = A.n;
        m_diag.assign(n, 0.0);
        
        #pragma omp parallel for
        for (int i = 0; i < n; i++) {
            double diag_val = 0.0;
            double row_norm_sq = 0.0;

            for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
                double val = A.vals[idx];
                
                if (A.ja[idx] == i) {
                    diag_val = val;
                }
                row_norm_sq += val * val;
            }

            if (row_norm_sq < 1e-15) {
                // Embutindo o omega aqui
                m_diag[i] = omega * 1.0; 
            } else {
                // A MÁGICA: O omega já é multiplicado e salvo direto na memória.
                // M_ii = omega * (A_ii / ||A_i||_2^2)
                m_diag[i] = omega * (diag_val / row_norm_sq);
            }
        }
    }

    void apply(const std::vector<double>& r,
               std::vector<double>& z) const override {
        int n = r.size();
        
        // A operação continua idêntica e ultrarrápida: z = (omega * M) * r
        #pragma omp parallel for
        for (int i = 0; i < n; i++) {
            z[i] = r[i] * m_diag[i];
        }
    }

    std::shared_ptr<Preconditioner> clone() const override {
        // Garante que o clone carregue o mesmo omega
        return std::make_shared<SPAI0Preconditioner>(omega); 
    }
};

class GaussSeidelSmoother : public Preconditioner {
private:
    const CSRMatrix* A_ptr = nullptr;
    std::vector<double> inv_diag;
    double omega;
    bool symmetric;

public:
    GaussSeidelSmoother(double w = 1.0, bool sym = true)
        : omega(w), symmetric(sym) {}

    void setup(const CSRMatrix& A) override {
        A_ptr = &A;
        int n = A.n;
        inv_diag.assign(n, 0.0);

        for (int i = 0; i < n; i++) {
            double diag_val = 1.0; // Default para evitar divisão por zero
            for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
                if (A.ja[idx] == i) {
                    diag_val = A.vals[idx];
                    break;
                }
            }
            inv_diag[i] = (std::abs(diag_val) < 1e-15) ? 1.0 : (1.0 / diag_val);
        }
        
    }
    std::shared_ptr<Preconditioner> clone() const override {
        return std::make_shared<GaussSeidelSmoother>(omega, symmetric );
    }
    void apply(const std::vector<double>& r, std::vector<double>& z) const override {
        if (!A_ptr) return;
        const CSRMatrix& A = *A_ptr;
        int n = A.n;
        z.assign(n, 0.0);

        // --- FORWARD SWEEP ---
        for (int i = 0; i < n; i++) {
            double sigma = r[i];
            for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
                int j = A.ja[idx];
                if (j < i) sigma -= A.vals[idx] * z[j];
            }
            z[i] = omega * sigma * inv_diag[i];
        }

        if (!symmetric) return;

        // --- BACKWARD SWEEP ---
        // Resolve (D + U) * z_new = D * z_old
        // A lógica correta aqui é reduzir a parte superior:
        for (int i = n - 1; i >= 0; i--) {
            double sigma = 0.0;
            for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
                int j = A.ja[idx];
                if (j > i) sigma += A.vals[idx] * z[j];
            }
            // Ajuste fino do relaxamento:
            z[i] -= omega * inv_diag[i] * sigma;
        }
    }
};


class SPAI1Preconditioner : public Preconditioner {
public:
    std::vector<int> m_ia;
    std::vector<int> m_ja;
    std::vector<double> m_vals;

    SPAI1Preconditioner() {}

    void setup(const CSRMatrix& A) override {
        int n = A.n;
        
        // O padrão de esparsidade de M é idêntico ao de A no SPAI-1 padrão
        m_ia = std::vector<int>(A.ia, A.ia + n + 1);
        m_ja = std::vector<int>(A.ja, A.ja + A.ia[n]);
        m_vals.assign(A.ia[n], 0.0);

        #pragma omp parallel for
        for (int i = 0; i < n; i++) {
            int row_start = A.ia[i];
            int row_end = A.ia[i+1];
            int S = row_end - row_start; // Número de não-nulos na linha i

            if (S == 0) continue; // Linha vazia de segurança

            // Aloca sistema denso local para a thread
            std::vector<double> B(S * S, 0.0);
            std::vector<double> c(S, 0.0);

            // 1. Montagem do sistema B x = c
            for (int p = 0; p < S; ++p) {
                int j_p = A.ja[row_start + p];

                // RHS: c_p = A(j_p, i). Buscamos na linha j_p pela coluna i
                for (int k = A.ia[j_p]; k < A.ia[j_p+1]; ++k) {
                    if (A.ja[k] == i) {
                        c[p] = A.vals[k];
                        break;
                    }
                }

                // Matriz B: B_pq = produto escalar da linha j_p com a linha j_q
                for (int q = p; q < S; ++q) {
                    int j_q = A.ja[row_start + q];
                    
                    double dot_product = 0.0;
                    int kp = A.ia[j_p], kp_end = A.ia[j_p+1];
                    int kq = A.ia[j_q], kq_end = A.ia[j_q+1];
                    
                    // Como as colunas no CSR são ordenadas, usamos two-pointers (O(nnz))
                    while (kp < kp_end && kq < kq_end) {
                        if (A.ja[kp] == A.ja[kq]) {
                            dot_product += A.vals[kp] * A.vals[kq];
                            kp++; kq++;
                        } else if (A.ja[kp] < A.ja[kq]) {
                            kp++;
                        } else {
                            kq++;
                        }
                    }
                    
                    B[p * S + q] = dot_product;
                    B[q * S + p] = dot_product; // B é simétrica
                }
            }

            // 2. Resolve o microssistema denso B x = c usando Eliminação de Gauss
            bool success = solve_dense(B, c, S);

            // 3. Salva a solução ou aplica o fallback para SPAI-0
            if (success) {
                for (int p = 0; p < S; ++p) {
                    m_vals[row_start + p] = c[p]; // 'c' guarda a solução 'x'
                }
            } else {
                // Fallback de segurança para SPAI-0 se a submatriz for singular
                double diag_val = 0.0;
                double row_norm_sq = 0.0;
                int diag_idx = -1;

                for (int p = 0; p < S; ++p) {
                    double val = A.vals[row_start + p];
                    row_norm_sq += val * val;
                    if (A.ja[row_start + p] == i) {
                        diag_val = val;
                        diag_idx = row_start + p;
                    }
                }

                if (diag_idx != -1 && row_norm_sq > 1e-15) {
                    m_vals[diag_idx] = diag_val / row_norm_sq;
                }
            }
        }
    }

    void apply(const std::vector<double>& r, std::vector<double>& z) const override {
        int n = r.size();
        
        // Multiplicação Esparsa Matriz-Vetor (SpMV): z = M * r
        #pragma omp parallel for
        for (int i = 0; i < n; i++) {
            double sum = 0.0;
            for (int idx = m_ia[i]; idx < m_ia[i+1]; idx++) {
                sum += m_vals[idx] * r[m_ja[idx]];
            }
            z[i] = sum;
        }
    }

    std::shared_ptr<Preconditioner> clone() const override {
        return std::make_shared<SPAI1Preconditioner>();
    }

private:
    // Helper para resolver B * x = c in-place. O vetor 'x' entra e sai no parâmetro 'c'.
    bool solve_dense(std::vector<double>& B, std::vector<double>& x, int S) {
        for (int k = 0; k < S; ++k) {
            // Pivoteamento Parcial
            int pivot = k;
            double max_val = std::abs(B[k * S + k]);
            for (int i = k + 1; i < S; ++i) {
                if (std::abs(B[i * S + k]) > max_val) {
                    max_val = std::abs(B[i * S + k]);
                    pivot = i;
                }
            }
            
            if (max_val < 1e-14) return false; // Matriz singular/mal condicionada

            if (pivot != k) {
                for (int j = k; j < S; ++j) std::swap(B[k * S + j], B[pivot * S + j]);
                std::swap(x[k], x[pivot]);
            }

            // Eliminação
            for (int i = k + 1; i < S; ++i) {
                double factor = B[i * S + k] / B[k * S + k];
                for (int j = k; j < S; ++j) {
                    B[i * S + j] -= factor * B[k * S + j];
                }
                x[i] -= factor * x[k];
            }
        }
        
        // Substituição Reversa
        for (int i = S - 1; i >= 0; --i) {
            double sum = 0.0;
            for (int j = i + 1; j < S; ++j) {
                sum += B[i * S + j] * x[j];
            }
            x[i] = (x[i] - sum) / B[i * S + i];
        }
        return true;
    }
};


class FSAIPreconditioner : public Preconditioner {
public:
    std::vector<int> m_ia;
    std::vector<int> m_ja;
    std::vector<double> m_vals;

    FSAIPreconditioner() {}

    void setup(const CSRMatrix& A) override {
        int n = A.n;
        std::cout << "Setup FSAI (G = L^-1)" << std::endl;
        
        m_ia.assign(n + 1, 0);

        // 1. Contagem do Padrão de Esparsidade (Parte Triangular Inferior)
        #pragma omp parallel for
        for (int i = 0; i < n; i++) {
            int count = 0;
            for (int k = A.ia[i]; k < A.ia[i+1]; ++k) {
                if (A.ja[k] <= i) count++; // Apenas vizinhos inferiores e a diagonal
            }
            m_ia[i+1] = count;
        }

        // Prefixo cumulativo
        for (int i = 0; i < n; i++) {
            m_ia[i+1] += m_ia[i];
        }

        m_ja.assign(m_ia[n], 0);
        m_vals.assign(m_ia[n], 0.0);

        // 2. Construção independente das linhas de G
        #pragma omp parallel for
        for (int i = 0; i < n; i++) {
            int row_start = m_ia[i];
            int S = m_ia[i+1] - m_ia[i];

            if (S == 0) continue;

            // Extrai o padrão de esparsidade local S_i
            std::vector<int> S_i(S);
            int idx = 0;
            for (int k = A.ia[i]; k < A.ia[i+1]; ++k) {
                if (A.ja[k] <= i) {
                    S_i[idx++] = A.ja[k];
                    m_ja[row_start + (idx - 1)] = A.ja[k]; // Salva a coluna em G
                }
            }

            // Monta o microssistema denso B da submatriz principal A(S_i, S_i)
            std::vector<double> B(S * S, 0.0);
            for (int p = 0; p < S; ++p) {
                int row_p = S_i[p];
                for (int q = 0; q < S; ++q) {
                    int col_q = S_i[q];
                    // Busca A(row_p, col_q)
                    for (int k = A.ia[row_p]; k < A.ia[row_p+1]; ++k) {
                        if (A.ja[k] == col_q) {
                            B[p * S + q] = A.vals[k];
                            break;
                        }
                    }
                }
            }

            // O vetor do lado direito é o vetor canônico e_last = (0, 0, ..., 1)
            std::vector<double> x(S, 0.0);
            std::vector<double> rhs(S, 0.0);
            rhs[S - 1] = 1.0; 

            // Resolve B * x = rhs (Usando a mesma eliminação de Gauss local)
            bool success = solve_dense(B, rhs, S);

            // A normalização do FSAI exige que G_ii = x[S-1] / sqrt(x[S-1])
            // Portanto a linha inteira de G é escalada por 1.0 / sqrt(x[S-1])
            if (success && rhs[S - 1] > 1e-14) {
                double scale = 1.0 / std::sqrt(rhs[S - 1]);
                for (int p = 0; p < S; ++p) {
                    m_vals[row_start + p] = rhs[p] * scale;
                }
            } else {
                // Fallback de segurança caso a submatriz singularize
                double diag_A = 0.0;
                for (int k = A.ia[i]; k < A.ia[i+1]; ++k) {
                    if (A.ja[k] == i) { diag_A = A.vals[k]; break; }
                }
                if (diag_A > 1e-15) {
                    m_vals[row_start + S - 1] = 1.0 / std::sqrt(diag_A); // G_ii = 1 / sqrt(A_ii)
                }
            }
        }
    }

    void apply(const std::vector<double>& r, std::vector<double>& z) const override {
        int n = r.size();
        std::vector<double> w(n, 0.0);
        
        // PASSO 1: w = G * r (Forward SpMV)
        #pragma omp parallel for
        for (int i = 0; i < n; i++) {
            double sum = 0.0;
            for (int idx = m_ia[i]; idx < m_ia[i+1]; idx++) {
                sum += m_vals[idx] * r[m_ja[idx]];
            }
            w[i] = sum;
        }

        // Inicializa z com zero pois usaremos soma atômica a seguir
        std::fill(z.begin(), z.end(), 0.0);

        // PASSO 2: z = G^T * w (Transposed SpMV)
        // Como G é linha-CSR e queremos multiplicar pela transposta, o loop escreve espalhado.
        #pragma omp parallel for
        for (int i = 0; i < n; i++) {
            double w_i = w[i];
            for (int idx = m_ia[i]; idx < m_ia[i+1]; idx++) {
                int j = m_ja[idx];
                double val = m_vals[idx];
                
                // Operação atômica necessária pois múltiplas linhas podem escrever na mesma coluna 'j'
                #pragma omp atomic
                z[j] += val * w_i;
            }
        }
    }

    std::shared_ptr<Preconditioner> clone() const override {
        return std::make_shared<FSAIPreconditioner>();
    }

private:
    // Helper para microssistemas locais. Substitua pela sua própria função se já tiver uma melhor!
    bool solve_dense(std::vector<double>& B, std::vector<double>& x, int S) {
        for (int k = 0; k < S; ++k) {
            int pivot = k;
            double max_val = std::abs(B[k * S + k]);
            for (int i = k + 1; i < S; ++i) {
                if (std::abs(B[i * S + k]) > max_val) {
                    max_val = std::abs(B[i * S + k]);
                    pivot = i;
                }
            }
            if (max_val < 1e-14) return false;
            if (pivot != k) {
                for (int j = k; j < S; ++j) std::swap(B[k * S + j], B[pivot * S + j]);
                std::swap(x[k], x[pivot]);
            }
            for (int i = k + 1; i < S; ++i) {
                double factor = B[i * S + k] / B[k * S + k];
                for (int j = k; j < S; ++j) B[i * S + j] -= factor * B[k * S + j];
                x[i] -= factor * x[k];
            }
        }
        for (int i = S - 1; i >= 0; --i) {
            double sum = 0.0;
            for (int j = i + 1; j < S; ++j) sum += B[i * S + j] * x[j];
            x[i] = (x[i] - sum) / B[i * S + i];
        }
        return true;
    }
};