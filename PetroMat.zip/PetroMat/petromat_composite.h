#pragma once
#include "petromat_solver.h"
#include "petromat_utils.h"
#include "petromat_cg.h"
#include <stdexcept>
#include <vector>
#include <memory>

class MultiplicativeComposite : public Preconditioner {
private:
    std::shared_ptr<Preconditioner> M1;
    std::shared_ptr<Preconditioner> M2;
    std::shared_ptr<const CSRMatrix> A_ptr; // Guardamos o ponteiro para o SPMV

    // Vetores de rascunho para evitar alocações repetidas no apply
    mutable std::vector<double> Az1;
    mutable std::vector<double> r_new;

public:
    MultiplicativeComposite(std::shared_ptr<Preconditioner> C1, 
                            std::shared_ptr<Preconditioner> C2) 
        : M1(C1), M2(C2) {}

    std::shared_ptr<Preconditioner> clone() const override {
        throw std::runtime_error("not implemented");
    }

    void setup(const CSRMatrix &A) override {
        // Opção 1: Se você quer APENAS o ponteiro (Recomendado)
        // Precisamos de um artifício se o setup não recebe shared_ptr:
        // Se a matriz A externa for destruída, isso aqui quebra. 
        // Em um sistema real, o ideal é passar o shared_ptr via um método setMatrix.
        A_ptr = std::make_shared<const CSRMatrix>(A); 

        // Configura os precondicionadores internos
        M1->setup(A);
        M2->setup(A);

        // Pré-alocação dos vetores auxiliares
        Az1.assign(A.n, 0.0);
        r_new.assign(A.n, 0.0);
    }

    void apply(const std::vector<double> &y, std::vector<double> &z) const override {
        const size_t n = y.size();
        z.assign(n, 0.0);

        // 1. Primeira etapa: Correção da Malha Grossa (z1)
        std::vector<double> z1(n, 0.0);
        M1->apply(y, z1);

        // 2. Cálculo do Resíduo Intermediário: r_new = y - A * z1
        // Esse é o passo fundamental para o método multiplicativo
        spmv_csr( A_ptr.get(), z1.data(), Az1.data());
        
        for (size_t i = 0; i < n; ++i) {
            r_new[i] = y[i] - Az1[i];
        }

        // 3. Segunda etapa: Suavização (z2) sobre o resíduo restante
        std::vector<double> z2(n, 0.0);
        M2->apply(r_new, z2);

        // 4. Resultado final: Combinação das duas correções
        for (size_t i = 0; i < n; ++i) {
            z[i] = z1[i] + z2[i];
        }
    }
};