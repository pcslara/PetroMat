#ifndef __PRETOMAT_IC__
#define __PRETOMAT_IC__

#include "petromat_types.h"
#include <vector>
#include <map>
#include <cmath>
#include <memory>
#include <iostream>
#include <stdexcept>

#include "petromat_solver.h"
#include "petromat_types.h"
#include <cmath>
#include <vector>
#include <iostream>
#include <algorithm>
#include <numeric>

struct SPDCheckResult {
    bool is_spd;
    bool is_symmetric;
    bool has_positive_diagonal;
    bool is_positive_definite;
    double min_diagonal;
    double max_diagonal;
    double min_eigenvalue_estimate;
    std::vector<std::string> issues;
};

void ic0_forward_substitution(const CSRMatrix *A, const double *l_vals, const double *r, double *y);
void ic0_backward_substitution(const CSRMatrix *A, const double *l_vals, const double *y, double *z);

void ic0_decomposition(const CSRMatrix *A, double *l_vals);
#include <vector>
#include <map>
#include <cmath>
#include <algorithm>
#include <stdexcept>

class ICKPreconditioner2 : public Preconditioner {
private:
    int fill_level;
    CSRMatrix L; // fator armazenado em CSR
    mutable std::vector<double> y_tmp;

public:
    ICKPreconditioner2(int k) : fill_level(k) {
        L.ia = nullptr;
        L.ja = nullptr;
        L.vals = nullptr;
    }

    ~ICKPreconditioner2() {
        if (L.ia) free(L.ia);
        if (L.ja) free(L.ja);
        if (L.vals) free(L.vals);
    }
    std::shared_ptr<Preconditioner> clone() const override {
        throw std::runtime_error("not implemented");
    }

    void setup(const CSRMatrix& A)  override {
        int n = A.n;

        // Umap vai armazenar a parte triangular SUPERIOR (U), pois A = U^T * U
        std::vector<std::map<int, double>> Umap(n);
        std::vector<std::map<int, int>> level(n);
        
        // Estrutura para otimização: rastreia quais linhas 'k' possuem elementos na coluna 'i'
        std::vector<std::vector<int>> active_k(n);

        // 1. Inicializa com a parte triangular superior de A
        for (int i = 0; i < n; i++) {
            Umap[i][i] = 0.0; // Garante que a diagonal sempre exista no mapa
            level[i][i] = 0;
            
            for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
                int j = A.ja[idx];
                if (j >= i) { // Apenas j >= i (Superior)
                    Umap[i][j] = A.vals[idx];
                    level[i][j] = 0;
                    if (j > i) {
                        active_k[j].push_back(i); // A linha 'i' vai interagir com a coluna 'j'
                    }
                }
            }
        }

        // 2. Fatoração de Cholesky Incompleta IC(k) usando U
        for (int i = 0; i < n; i++) {
            // Atualiza a linha i APENAS usando as linhas k < i que possuem valor na coluna i
            for (int k : active_k[i]) {
                double U_ki = Umap[k][i];
                int lev_ki = level[k][i];

                // Atualiza os elementos U_{ij} para j >= i
                for (auto it_kj = Umap[k].lower_bound(i); it_kj != Umap[k].end(); ++it_kj) {
                    int j = it_kj->first;
                    double U_kj = it_kj->second;
                    int lev_kj = level[k][j];

                    int new_level = lev_ki + lev_kj + 1;
                    if (new_level > fill_level) continue;

                    double val = U_ki * U_kj;

                    if (Umap[i].count(j) == 0) {
                        Umap[i][j] = -val;
                        level[i][j] = new_level;
                        if (j > i) {
                            active_k[j].push_back(i); // Registra o novo fill-in
                        }
                    } else {
                        Umap[i][j] -= val;
                        level[i][j] = std::min(level[i][j], new_level);
                    }
                }
            }

            // 3. Calcula e aplica a diagonal real
            double diag = Umap[i][i];
            if (diag <= 0.0) diag = 1e-12; // Proteção numérica
            
            double U_ii = std::sqrt(diag);
            Umap[i][i] = U_ii;

            // 4. Escala toda a parte não-diagonal da linha i
            for (auto& [j, val] : Umap[i]) {
                if (j > i) {
                    val /= U_ii;
                }
            }
        }

        // 5. Construção segura da matriz L = U^T
        L.n = n;
        
        if (L.ia) free(L.ia);
        if (L.ja) free(L.ja);
        if (L.vals) free(L.vals);

        L.ia = (int*) malloc((n + 1) * sizeof(int));
        std::vector<int> row_counts(n, 0);

        for (int i = 0; i < n; i++) {
            for (auto& [j, val] : Umap[i]) {
                row_counts[j]++;
            }
        }

        L.ia[0] = 0;
        for (int i = 0; i < n; i++) {
            L.ia[i+1] = L.ia[i] + row_counts[i];
        }

        L.nnz = L.ia[n];
        L.ja = (int*) malloc(L.nnz * sizeof(int));
        L.vals = (double*) malloc(L.nnz * sizeof(double));

        std::vector<int> row_ptr(n);
        for(int i = 0; i < n; i++) row_ptr[i] = L.ia[i];

        // Preenchimento de L (Garante que a diagonal será o último elemento de cada linha)
        for (int i = 0; i < n; i++) {
            for (auto& [j, val] : Umap[i]) {
                int dest_row = j;
                int pos = row_ptr[dest_row]++;
                L.ja[pos] = i;      
                L.vals[pos] = val;
            }
        }

        y_tmp.resize(n);
    }
    void setup2(const CSRMatrix& A)  {
    int n = A.n;

    // Em vez de usar mapas ou vetores soltos, vamos construir U diretamente em 
    // formato CSR achatado (flat arrays) para máxima performance de cache.
    std::vector<int> U_ia(n + 1, 0);
    std::vector<int> U_ja;
    std::vector<double> U_vals;
    std::vector<int> U_levs;

    // Pré-aloca uma estimativa de memória para evitar realocações dinâmicas.
    int estimated_nnz = A.nnz * (fill_level + 1);
    U_ja.reserve(estimated_nnz);
    U_vals.reserve(estimated_nnz);
    U_levs.reserve(estimated_nnz);

    // =====================================================================
    // ESTRUTURAS DE OTIMIZAÇÃO DE ALTA PERFORMANCE
    // =====================================================================
    // active_k[i] = lista de linhas 'k' (k < i) que possuem seu próximo 
    // elemento não-nulo exatamente na coluna 'i'. 
    std::vector<std::vector<int>> active_k(n);
    
    // U_ptr[k] = índice na matriz achatada 'U_ja' do próximo elemento da linha k 
    // que será usado para atualizar as linhas abaixo dela.
    std::vector<int> U_ptr(n, 0);

    // SPARSE ACCUMULATOR (SPA): Workspace densos para computar a linha atual 'i' em O(1)
    std::vector<double> work_val(n, 0.0);
    std::vector<int> work_lev(n, 1000000); // 1000000 = Infinito (nível não alcançado)
    std::vector<int> work_idx(n, -1);      // Marca se a coluna já foi adicionada na linha 'i'
    std::vector<int> current_cols;         // Lista das colunas não-nulas da linha 'i'
    current_cols.reserve(100);

    // =====================================================================
    // CONSTRUÇÃO DE U (Fatoração IC)
    // =====================================================================
    for (int i = 0; i < n; i++) {
        U_ia[i] = U_ja.size(); // Marca onde a linha 'i' começa na estrutura achatada
        current_cols.clear();

        // 1. Carrega a parte triangular superior da linha 'i' da matriz A original no SPA
        for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
            int j = A.ja[idx];
            if (j >= i) { // Apenas j >= i (Superior)
                work_idx[j] = i;
                work_val[j] = A.vals[idx];
                work_lev[j] = 0;
                current_cols.push_back(j);
            }
        }

        // Segurança caso A não tenha o elemento da diagonal explicitamente declarado
        if (work_idx[i] != i) {
            work_idx[i] = i;
            work_val[i] = 0.0;
            work_lev[i] = 0;
            current_cols.push_back(i);
        }

        // 2. Aplica as atualizações das linhas anteriores (k < i)
        for (int k : active_k[i]) {
            int ptr = U_ptr[k]; // Aponta EXATAMENTE para o U_ki (O(1), sem buscas!)
            
            double U_ki = U_vals[ptr];
            int lev_ki  = U_levs[ptr];

            // Itera sobre o resto da linha k (colunas j > i)
            // U_ia[k+1] já está definido pois k < i
            for (int p = ptr + 1; p < U_ia[k+1]; p++) {
                int j = U_ja[p];
                double U_kj = U_vals[p];
                int lev_kj = U_levs[p];

                int new_level = lev_ki + lev_kj + 1;
                if (new_level > fill_level) continue; // Descarta se ultrapassar fill-in

                if (work_idx[j] != i) {
                    // Coluna 'j' é nova (fill-in descoberto)
                    work_idx[j] = i;
                    work_val[j] = 0.0;
                    work_lev[j] = new_level;
                    current_cols.push_back(j);
                } else {
                    work_lev[j] = std::min(work_lev[j], new_level);
                }
                
                // Aplica a eliminação
                work_val[j] -= U_ki * U_kj;
            }

            // Move o ponteiro da linha 'k' para seu próximo elemento não-nulo
            ptr++;
            U_ptr[k] = ptr;
            if (ptr < U_ia[k+1]) {
                int next_j = U_ja[ptr];
                active_k[next_j].push_back(k); // Adiciona 'k' na fila da próxima coluna
            }
        }

        // 3. Organiza, calcula a diagonal real e extrai do SPA
        std::sort(current_cols.begin(), current_cols.end()); // Garante CSR estrito (i será o primeiro)

        double diag = work_val[i];
        if (diag <= 0.0) diag = 1e-12; // Proteção numérica
        double U_ii = std::sqrt(diag);

        // 4. Salva a linha 'i' de U (já escalonando as colunas não-diagonais)
        for (int j : current_cols) {
            if (j == i) {
                U_ja.push_back(i);
                U_vals.push_back(U_ii);
                U_levs.push_back(0);
            } else if (j > i) {
                U_ja.push_back(j);
                U_vals.push_back(work_val[j] / U_ii);
                U_levs.push_back(work_lev[j]);
            }
        }

        // Prepara a linha 'i' recém concluída para atualizar as futuras linhas
        int first_off_diag = U_ia[i] + 1;
        if (first_off_diag < U_ja.size()) { // Se a linha i tiver elementos além da diagonal
            U_ptr[i] = first_off_diag;
            int next_j = U_ja[first_off_diag];
            active_k[next_j].push_back(i); // Agenda a linha i
        }
    }
    
    // Fechamento do array de ponteiros da matriz U
    U_ia[n] = U_ja.size();

    // =====================================================================
    // CONSTRUÇÃO DA MATRIZ L = U^T (Traspõe nativamente o vetor achatado)
    // =====================================================================
    L.n = n;
    
    if (L.ia) free(L.ia);
    if (L.ja) free(L.ja);
    if (L.vals) free(L.vals);

    L.ia = (int*) malloc((n + 1) * sizeof(int));
    
    // Conta os elementos por coluna de U (que serão as linhas de L)
    std::vector<int> row_counts(n, 0);
    for (size_t p = 0; p < U_ja.size(); p++) {
        row_counts[U_ja[p]]++;
    }

    L.ia[0] = 0;
    for (int i = 0; i < n; i++) {
        L.ia[i+1] = L.ia[i] + row_counts[i];
    }

    L.nnz = L.ia[n];
    L.ja = (int*) malloc(L.nnz * sizeof(int));
    L.vals = (double*) malloc(L.nnz * sizeof(double));

    std::vector<int> L_ptr(n);
    for(int i = 0; i < n; i++) L_ptr[i] = L.ia[i];

    // Preenche a matriz L garantindo que a diagonal caia no final
    for (int i = 0; i < n; i++) {
        for (int p = U_ia[i]; p < U_ia[i+1]; p++) {
            int dest_row = U_ja[p];
            int pos = L_ptr[dest_row]++;
            L.ja[pos] = i;      
            L.vals[pos] = U_vals[p];
        }
    }

    y_tmp.resize(n);
}
    void apply(const std::vector<double>& r, std::vector<double>& z) const override {
        int n = L.n;
        
        // ==========================================
        // 1. Forward Substitution: L * y_tmp = r
        // ==========================================
        for (int i = 0; i < n; i++) {
            double sum = 0.0;
            // O loop vai até o PENÚLTIMO elemento (apenas os k onde j < i)
            int diag_idx = L.ia[i + 1] - 1; 
            
            for (int k = L.ia[i]; k < diag_idx; k++) {
                sum += L.vals[k] * y_tmp[L.ja[k]];
            }
            
            // A diagonal é sempre o último elemento da linha
            double diag = L.vals[diag_idx]; 
            y_tmp[i] = (r[i] - sum) / diag;
        }

        // ==========================================
        // 2. Backward Substitution: Lᵀ * z = y_tmp
        // ==========================================
        std::copy(y_tmp.begin(), y_tmp.end(), z.begin());
        
        for (int i = n - 1; i >= 0; i--) {
            int diag_idx = L.ia[i + 1] - 1;
            double diag = L.vals[diag_idx];
            
            z[i] /= diag;
            
            // Subtrai contribuições usando o método PUSH (apenas para k onde j < i)
            for (int k = L.ia[i]; k < diag_idx; k++) {
                z[L.ja[k]] -= L.vals[k] * z[i];
            }
        }
    }
};

class ICKPreconditioner : public Preconditioner {
private:
    int fill_level;

    CSRMatrix L; // fator armazenado em CSR
    mutable std::vector<double> y_tmp;

public:
    ICKPreconditioner(int k) : fill_level(k) {}

   void setup(const CSRMatrix& A) override {
    int n = A.n;

    // Umap vai armazenar a parte triangular SUPERIOR (U), pois A = U^T * U
    std::vector<std::map<int, double>> Umap(n);
    std::vector<std::map<int, int>> level(n);
    
    // Estrutura para otimização: rastreia quais linhas 'k' possuem elementos na coluna 'i'
    // Evita loop O(N^2) varrendo todos os k < i.
    std::vector<std::vector<int>> active_k(n);

    // 1. Inicializa com a parte triangular superior de A
    for (int i = 0; i < n; i++) {
        Umap[i][i] = 0.0; // Garante que a diagonal sempre exista no mapa
        level[i][i] = 0;
        
        for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
            int j = A.ja[idx];
            if (j >= i) { // Apenas j >= i (Superior)
                Umap[i][j] = A.vals[idx];
                level[i][j] = 0;
                if (j > i) {
                    active_k[j].push_back(i); // A linha 'i' vai interagir com a coluna 'j'
                }
            }
        }
    }

    // 2. Fatoração de Cholesky Incompleta IC(k) usando U
    for (int i = 0; i < n; i++) {
        // Atualiza a linha i APENAS usando as linhas k < i que possuem valor na coluna i
        for (int k : active_k[i]) {
            double U_ki = Umap[k][i];
            int lev_ki = level[k][i];

            // Atualiza os elementos U_{ij} para j >= i
            for (auto it_kj = Umap[k].lower_bound(i); it_kj != Umap[k].end(); ++it_kj) {
                int j = it_kj->first;
                double U_kj = it_kj->second;
                int lev_kj = level[k][j];

                int new_level = lev_ki + lev_kj + 1;
                if (new_level > fill_level) continue;

                double val = U_ki * U_kj;

                if (Umap[i].count(j) == 0) {
                    Umap[i][j] = -val;
                    level[i][j] = new_level;
                    if (j > i) {
                        active_k[j].push_back(i); // Registra o novo fill-in para o futuro
                    }
                } else {
                    Umap[i][j] -= val;
                    level[i][j] = std::min(level[i][j], new_level);
                }
            }
        }

        // 3. Calcula e aplica a diagonal real (sem dupla subtração!)
        double diag = Umap[i][i];
        if (diag <= 0.0) diag = 1e-12; // Proteção numérica
        
        double U_ii = std::sqrt(diag);
        Umap[i][i] = U_ii;

        // 4. Escala toda a parte não-diagonal da linha i
        for (auto& [j, val] : Umap[i]) {
            if (j > i) {
                val /= U_ii;
            }
        }
    }

    // 5. Construção segura da matriz L = U^T (Estritamente Triangular Inferior)
    L.n = n;
    
    // Libera a memória anterior se estiver re-iniciando o setup 
    if (L.ia) free(L.ia);
    if (L.ja) free(L.ja);
    if (L.vals) free(L.vals);

    L.ia = (int*) malloc((n + 1) * sizeof(int));
    std::vector<int> row_counts(n, 0);

    for (int i = 0; i < n; i++) {
        for (auto& [j, val] : Umap[i]) {
            row_counts[j]++; // Na transposta, a linha destino é a coluna j de U
        }
    }

    L.ia[0] = 0;
    for (int i = 0; i < n; i++) {
        L.ia[i+1] = L.ia[i] + row_counts[i];
    }

    L.nnz = L.ia[n];
    L.ja = (int*) malloc(L.nnz * sizeof(int));
    L.vals = (double*) malloc(L.nnz * sizeof(double));

    std::vector<int> row_ptr(n);
    for(int i = 0; i < n; i++) row_ptr[i] = L.ia[i];

    // Preenchimento de L
    for (int i = 0; i < n; i++) {
        for (auto& [j, val] : Umap[i]) {
            int dest_row = j;
            int pos = row_ptr[dest_row]++;
            L.ja[pos] = i;      // i <= j garante que é triangular inferior (coluna <= linha)
            L.vals[pos] = val;
        }
    }

    y_tmp.resize(n);
}
std::shared_ptr<Preconditioner> clone() const override {
        return std::make_shared< ICKPreconditioner>(fill_level );
}
void setup2(const CSRMatrix& A)  {
    int n = A.n;

    // Estruturas achatadas para armazenar a matriz U (substitui o Umap e level)
    std::vector<int> U_ia(n + 1, 0);
    std::vector<int> U_ja;
    std::vector<double> U_vals;
    std::vector<int> U_levs;

    // Pré-alocação otimizada
    int estimated_nnz = A.nnz * (fill_level + 1);
    U_ja.reserve(estimated_nnz);
    U_vals.reserve(estimated_nnz);
    U_levs.reserve(estimated_nnz);

    // active_k[i] mantém as linhas 'k' que interagem com a coluna 'i'
    std::vector<std::vector<int>> active_k(n);
    
    // U_ptr[k] guarda a posição exata (índice em U_ja) do próximo elemento útil da linha k
    // Isso substitui completamente o lento "Umap[k].lower_bound(i)"
    std::vector<int> U_ptr(n, 0);

    // SPARSE ACCUMULATOR (SPA): Otimiza a linha atual para O(1)
    std::vector<double> work_val(n, 0.0);
    std::vector<int> work_lev(n, 1000000); // 1000000 atua como infinito
    std::vector<int> work_idx(n, -1);
    std::vector<int> current_cols;
    current_cols.reserve(100);

    // =================================================================
    // 1. e 2. Inicialização e Fatoração IC(k) fundidas para máxima velocidade
    // =================================================================
    for (int i = 0; i < n; i++) {
        U_ia[i] = U_ja.size();
        current_cols.clear();

        // Inicializa o SPA com a parte superior da matriz A
        for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
            int j = A.ja[idx];
            if (j >= i) { 
                work_idx[j] = i;
                work_val[j] = A.vals[idx];
                work_lev[j] = 0;
                current_cols.push_back(j);
            }
        }

        // Garante que a diagonal sempre exista (como no seu Umap[i][i] = 0.0;)
        if (work_idx[i] != i) {
            work_idx[i] = i;
            work_val[i] = 0.0;
            work_lev[i] = 0;
            current_cols.push_back(i);
        }

        // Atualiza a linha i APENAS usando as linhas k < i (idêntico ao seu active_k)
        for (int k : active_k[i]) {
            int ptr = U_ptr[k]; // Equivale ao seu lower_bound(i), mas vai direto no O(1)
            
            double U_ki = U_vals[ptr];
            int lev_ki = U_levs[ptr];

            // Itera sobre os elementos restantes da linha k (Equivale ao seu it_kj)
            for (int p = ptr; p < U_ia[k+1]; p++) {
                int j = U_ja[p];
                double U_kj = U_vals[p];
                int lev_kj = U_levs[p];

                int new_level = lev_ki + lev_kj + 1;
                
                // Exatamente a sua regra de corte
                if (new_level > fill_level) continue;

                double val = U_ki * U_kj;

                // Se o elemento não existe na linha i, insere (Equivale a Umap[i].count(j) == 0)
                if (work_idx[j] != i) {
                    work_idx[j] = i;
                    work_val[j] = -val;
                    work_lev[j] = new_level;
                    current_cols.push_back(j);
                } else {
                    // Já existe, então acumula
                    work_val[j] -= val;
                    work_lev[j] = std::min(work_lev[j], new_level);
                }
            }

            // Move o ponteiro da linha k para o próximo elemento futuro
            ptr++;
            U_ptr[k] = ptr;
            if (ptr < U_ia[k+1]) {
                int next_j = U_ja[ptr];
                active_k[next_j].push_back(k); // Agenda k para o futuro (seu active_k_push_back)
            }
        }

        // Ordena as colunas processadas para manter a matriz estrita (o std::map fazia isso sozinho)
        std::sort(current_cols.begin(), current_cols.end());

        // 3. Calcula e aplica a diagonal real (Idêntico)
        double diag = work_val[i];
        if (diag <= 0.0) diag = 1e-12; 
        
        double U_ii = std::sqrt(diag);

        // 4. Salva a matriz U escalando a parte não-diagonal
        for (int j : current_cols) {
            if (j == i) {
                U_ja.push_back(i);
                U_vals.push_back(U_ii);
                U_levs.push_back(0); // A diagonal nunca sofre fill-in
            } else if (j > i) {
                U_ja.push_back(j);
                U_vals.push_back(work_val[j] / U_ii);
                U_levs.push_back(work_lev[j]);
            }
        }

        // Prepara a própria linha i para atualizar os vizinhos futuros
        int first_off_diag = U_ia[i] + 1;
        if (first_off_diag < U_ja.size()) {
            U_ptr[i] = first_off_diag;
            int next_j = U_ja[first_off_diag];
            active_k[next_j].push_back(i); 
        }
    }
    U_ia[n] = U_ja.size();

    // =================================================================
    // 5. Construção segura da matriz L = U^T
    // =================================================================
    L.n = n;
    
    if (L.ia) free(L.ia);
    if (L.ja) free(L.ja);
    if (L.vals) free(L.vals);

    L.ia = (int*) malloc((n + 1) * sizeof(int));
    std::vector<int> row_counts(n, 0);

    for (size_t p = 0; p < U_ja.size(); p++) {
        row_counts[U_ja[p]]++;
    }

    L.ia[0] = 0;
    for (int i = 0; i < n; i++) {
        L.ia[i+1] = L.ia[i] + row_counts[i];
    }

    L.nnz = L.ia[n];
    L.ja = (int*) malloc(L.nnz * sizeof(int));
    L.vals = (double*) malloc(L.nnz * sizeof(double));

    std::vector<int> row_ptr(n);
    for(int i = 0; i < n; i++) row_ptr[i] = L.ia[i];

    // Preenchimento de L
    // (Como iteramos 'i' em ordem e o U_ja já está ordenado, L terá as colunas ordenadas
    // garantindo magicamente que a diagonal seja sempre o último elemento da linha!)
    for (int i = 0; i < n; i++) {
        for (int p = U_ia[i]; p < U_ia[i+1]; p++) {
            int dest_row = U_ja[p];
            int pos = row_ptr[dest_row]++;
            L.ja[pos] = i;      
            L.vals[pos] = U_vals[p];
        }
    }

    y_tmp.resize(n);
}
    void apply(const std::vector<double>& r,
               std::vector<double>& z) const override {

        // Ly = r
        ic0_forward_substitution(&L, L.vals, r.data(), y_tmp.data() );

        // Lᵀ z = y
        ic0_backward_substitution(&L, L.vals, y_tmp.data(), z.data());
    }
};


class ILUKPreconditioner : public Preconditioner {
private:
    int fill_level;

    struct Entry {
        double val;
        int level;
    };

    std::vector<std::map<int, Entry>> LU;
    mutable std::vector<double> y_tmp;

public:
    ILUKPreconditioner(int k) : fill_level(k) {}
    std::shared_ptr<Preconditioner> clone() const override {
        throw std::runtime_error("not implemented");
    }
    void setup(const CSRMatrix& A) override {
        int n = A.n;
        LU.assign(n, {});

        int small_pivot_count = 0;
        int nan_count = 0;
        int fill_count = 0;

        // --- inicialização
        for (int i = 0; i < n; i++) {
            for (int idx = A.ia[i]; idx < A.ia[i+1]; idx++) {
                int j = A.ja[idx];
                LU[i][j] = {A.vals[idx], 0};
            }
        }

        // --- fatoração
        for (int i = 0; i < n; i++) {

            std::vector<int> ks;
            for (auto& [j, _] : LU[i]) {
                if (j < i) ks.push_back(j);
            }

            for (int k : ks) {

                auto it_ik = LU[i].find(k);
                if (it_ik == LU[i].end()) continue;

                double Akk = LU[k].count(k) ? LU[k][k].val : 0.0;

                double scale = std::abs(Akk);
                double eps = 1e-8 * scale + 1e-12;

                if (std::abs(Akk) < eps) {
                    small_pivot_count++;
                    if (small_pivot_count < 10) {
                        std::cout << "[WARN] Small pivot at k=" << k
                                  << " Akk=" << Akk << "\n";
                    }
                    Akk = (Akk >= 0 ? eps : -eps);
                }

                double Lik = it_ik->second.val / Akk;

                if (!std::isfinite(Lik)) {
                    nan_count++;
                    std::cout << "[ERROR] Lik NaN/Inf at (i,k)=("
                              << i << "," << k << ")\n";
                    Lik = 0.0;
                }

                it_ik->second.val = Lik;

                // atualização
                for (auto& [j, entry_kj] : LU[k]) {

                    if (j <= k) continue;

                    int new_level =
                        it_ik->second.level + entry_kj.level + 1;

                    if (new_level > fill_level) continue;

                    auto it_ij = LU[i].find(j);

                    if (it_ij == LU[i].end()) {
                        LU[i][j] = {
                            -Lik * entry_kj.val,
                            new_level
                        };
                        fill_count++;
                    } else {
                        it_ij->second.val -= Lik * entry_kj.val;
                        it_ij->second.level =
                            std::min(it_ij->second.level, new_level);
                    }

                    if (!std::isfinite(LU[i][j].val)) {
                        nan_count++;
                        std::cout << "[ERROR] NaN created at ("
                                  << i << "," << j << ")\n";
                    }
                }
            }

            // --- pivô diagonal
            if (LU[i].find(i) == LU[i].end()) {
                LU[i][i] = {1e-12, 0};
            }

            double& diag = LU[i][i].val;

            double scale = std::abs(diag);
            double eps = 1e-8 * scale + 1e-12;

            if (std::abs(diag) < eps) {
                small_pivot_count++;
                if (small_pivot_count < 10) {
                    std::cout << "[WARN] Weak diagonal at i=" << i
                              << " diag=" << diag << "\n";
                }
                diag = (diag >= 0 ? eps : -eps);
            }

            if (!std::isfinite(diag)) {
                nan_count++;
                std::cout << "[ERROR] Diagonal NaN at i=" << i << "\n";
                diag = 1e-12;
            }
        }

        std::cout << "\n==== ILU(k) STATS ====\n";
        std::cout << "Fill-ins created: " << fill_count << "\n";
        std::cout << "Small pivots fixed: " << small_pivot_count << "\n";
        std::cout << "NaN/Inf detected: " << nan_count << "\n";
        std::cout << "======================\n\n";

        y_tmp.assign(n, 0.0);
    }

    void apply(const std::vector<double>& r,
               std::vector<double>& z) const override {

        int n = LU.size();
        if (z.size() != n) z.resize(n);

        // --- Forward
        for (int i = 0; i < n; i++) {
            double sum = 0.0;

            for (auto& [j, entry] : LU[i]) {
                if (j < i) sum += entry.val * y_tmp[j];
            }

            y_tmp[i] = r[i] - sum;

            if (!std::isfinite(y_tmp[i])) {
                std::cout << "[ERROR] Forward NaN at i=" << i << "\n";
                y_tmp[i] = 0.0;
            }
        }

        // --- Backward
        for (int i = n - 1; i >= 0; i--) {

            double sum = 0.0;
            double diag = 1.0;

            for (auto& [j, entry] : LU[i]) {
                if (j > i) sum += entry.val * z[j];
                else if (j == i) diag = entry.val;
            }

            if (std::abs(diag) < 1e-14) {
                std::cout << "[ERROR] Zero diag in solve at i=" << i << "\n";
                diag = 1e-12;
            }

            z[i] = (y_tmp[i] - sum) / diag;

            if (!std::isfinite(z[i])) {
                std::cout << "[ERROR] Backward NaN at i=" << i << "\n";
                z[i] = 0.0;
            }
        }
    }
};
#endif