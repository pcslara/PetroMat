#pragma once
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include "petromat_types.h"

// utilidades de parsing
std::string trim(const std::string &s);

std::string value_after_colon(const std::string& line);

bool starts_with(const std::string& s, const std::string& p);

// conversões de string -> enum
BoundaryType parse_bc_type(const std::string& s);

WellType parse_well_type(const std::string& s);

// função principal
ReservoirModel parse_yaml(const std::string& filename);


void print_reservoir(const ReservoirModel& r);

std::string generateLatexReport( ReservoirModel& model, const CSRMatrix& A);

