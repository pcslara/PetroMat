#ifndef PETROMAT_TYPES_H
#define PETROMAT_TYPES_H

#include <memory>
#include <vector>
#include <string>


typedef struct __CSRMatrix{
    int        n;         
    int      nnz;        
    int      *ia = nullptr;   
    int      *ja = nullptr;
    double *vals = nullptr;;   



    std::shared_ptr<struct __CSRMatrix> clone() const {
        auto new_matrix = std::make_shared<struct __CSRMatrix>();
        new_matrix->n = this->n;
        new_matrix->nnz = this->nnz;
        
        // Alocação e cópia dos arrays (IA, JA, VALS)
        new_matrix->ia = (int*)malloc((this->n + 1) * sizeof(int));
        new_matrix->ja = (int*)malloc(this->nnz * sizeof(int));
        new_matrix->vals = (double*)malloc(this->nnz * sizeof(double));

        std::copy(this->ia, this->ia + (this->n + 1), new_matrix->ia);
        std::copy(this->ja, this->ja + this->nnz, new_matrix->ja);
        std::copy(this->vals, this->vals + this->nnz, new_matrix->vals);

        return new_matrix;
    }
} CSRMatrix;


//
// Grid
//
struct Grid {
    int nx = 0;
    int ny = 0;
    int nz = 0;

    int num_cells() const {
        return nx * ny * nz;
    }

    int index(int i, int j, int k) const {
        return i + nx * (j + ny * k);
    }
};


//
// Domain size
//
struct Domain {
    double lx = 0.0;
    double ly = 0.0;
    double lz = 0.0;

    double dx(const Grid& g) const { return lx / g.nx; }
    double dy(const Grid& g) const { return ly / g.ny; }
    double dz(const Grid& g) const { return lz / g.nz; }
};


//
// Permeability
//
struct Permeability {
    double kx = 0.0;
    double ky = 0.0;
    double kz = 0.0;

    double kmax = 0.0;
    double kmin = 0.0;


    double R[3][3] = {{0,0,0}, {0,0,0}, {0,0,0}};          // Only diagonal
    double sigma[3];
    double range  = 1.0;         // a
    double smoothness = 0.0;    // v

    std::string perm_field;
    
};




//
// Boundary conditions
//
enum class BoundaryType {
    Dirichlet,
    Neumann
};

struct BoundaryCondition {
    BoundaryType type = BoundaryType::Dirichlet;
    double value = 0.0;
};

struct BoundaryConditions {

    BoundaryCondition xmin;
    BoundaryCondition xmax;

    BoundaryCondition ymin;
    BoundaryCondition ymax;

    BoundaryCondition zmin;
    BoundaryCondition zmax;
};


//
// Wells
//
enum class WellType {
    Injector,
    Producer
};

struct WellModel {

    WellType type = WellType::Producer;

    int i = 0;
    int j = 0;
    int k = 0;

    double rate = 0.0;
    double bhp = 0.0;
};

typedef struct {
    double R[3][3];
    double sigma[3];
    double a;
    double v;
} StatisticPermeabilityParams;


// Forward declaration para permitir a recursão


class SolverConfig;

struct ReservoirModel {
    Grid grid;
    Domain domain;
    Permeability permeability;
    BoundaryConditions boundary_conditions;
    std::vector<WellModel> wells;
    std::vector<std::shared_ptr<SolverConfig>> solvers;
    std::shared_ptr<SolverConfig> reference_solver = nullptr;
    int nThreads = 1;
    std::string input_matrix = "";
    std::string input_rhs = "";
};

#endif
