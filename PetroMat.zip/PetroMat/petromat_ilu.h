#ifndef PETROMAT_ILU_H
#define PETROMAT_ILU_H

#include "petromat_types.h"

double get_diag_value(const CSRMatrix *A, const double *lu_vals, int row);
double get_value_at(const CSRMatrix *A, const double *lu_vals, int row, int col);
void forward_substitution(const CSRMatrix *A, const double *lu_vals, const double *b, double *y);
void backward_substitution(const CSRMatrix *A, const double *lu_vals, const double *y, double *x);
void ilu0_decomposition(const CSRMatrix *A, double *lu_vals);


#endif