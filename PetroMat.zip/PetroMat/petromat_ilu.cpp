#include "petromat_types.h"

double get_diag_value(const CSRMatrix *A, const double *lu_vals, int row) {
    for (int k = A->ia[row]; k < A->ia[row+1]; k++) {
        if (A->ja[k] == row) return lu_vals[k];
    }
    return 1.0; // Evitar divisão por zero
}

double get_value_at(const CSRMatrix *A, const double *lu_vals, int row, int col) {
    for (int k = A->ia[row]; k < A->ia[row+1]; k++) {
        if (A->ja[k] == col) return lu_vals[k];
    }
    return 0.0;
}


void forward_substitution(const CSRMatrix *A, const double *lu_vals,
                          const double *b, double *y) {
    for (int i = 0; i < A->n; i++) {
        double sum = 0.0;
        for (int k = A->ia[i]; k < A->ia[i+1]; k++) {
            int j = A->ja[k];
            if (j < i)
                sum += lu_vals[k] * y[j];
        }
        y[i] = b[i] - sum;
    }
}

// Resolve Ux = y
void backward_substitution(const CSRMatrix *A, const double *lu_vals, const double *y, double *x) {
    for (int i = A->n - 1; i >= 0; i--) {
        double sum = 0.0;
        int diag_idx = -1;
        for (int k = A->ia[i]; k < A->ia[i+1]; k++) {
            if (A->ja[k] > i) sum += lu_vals[k] * x[A->ja[k]];
            if (A->ja[k] == i) diag_idx = k;
        }
        x[i] = (y[i] - sum) / lu_vals[diag_idx];
    }
}

void ilu0_decomposition(const CSRMatrix *A, double *lu_vals) {
    for (int i = 0; i < A->nnz; i++) lu_vals[i] = A->vals[i];

    for (int i = 0; i < A->n; i++) {
        int diag_idx = -1;
        for (int k = A->ia[i]; k < A->ia[i+1]; k++) {
            if (A->ja[k] == i) {
                diag_idx = k;
                break;
            }
        }

        for (int k = A->ia[i]; k < diag_idx; k++) {
            int j = A->ja[k];
            double pivot = lu_vals[k] / get_diag_value(A, lu_vals, j);
            lu_vals[k] = pivot; 

            for (int m = k + 1; m < A->ia[i+1]; m++) {
                int col_m = A->ja[m];
                double val_j_m = get_value_at(A, lu_vals, j, col_m);
                if (val_j_m != 0.0) {
                    lu_vals[m] -= pivot * val_j_m;
                }
            }
        }
    }
}