#pragma once
#include "petromat_cg.h"
#include "petromat_jacobi.h"
#include "petromat_solver.h"
#include "petromat_types.h"
#include "petromat_utils.h"
#include <algorithm>
#include <amgcl/coarsening/smoothed_aggregation.hpp>
#include <cmath>
#include <limits>
#include <map>
#include <memory>
#include <queue>
#include <random>
#include <stdexcept>
#include <vector>

// Includes mínimos e diretos do AMGCL
#include <amgcl/coarsening/plain_aggregates.hpp>
#include <amgcl/backend/builtin.hpp>


inline int _nx, _ny, _nz;



inline void save_partition(char *filename, std::vector<long int> partition,
                           int coarseSize, int x, int y, int z) {
  FILE *f = fopen(filename, "w");
  fprintf(f, "%d %d %d %d\n", x, y, z, coarseSize);
  for (long i = 0; i < partition.size(); i++) {
    fprintf(f, "%ld %ld\n", i, partition[i]);
  }
  fclose(f);
}





class Prolongator {
public:
  int coarseSize;
  int fineSize;
  std::shared_ptr<CSRMatrix> P_mat = nullptr;


  virtual std::shared_ptr<CSRMatrix> PtAP(const CSRMatrix &A) = 0;

  virtual void applyP(const std::vector<double> &y, std::vector<double> &z) = 0;
  virtual void applyPt(const std::vector<double> &y,
                       std::vector<double> &z) = 0;
  virtual void applyPAdd(const std::vector<double>& coarse, std::vector<double>& fine)  {
        if( P_mat )
        {
          for (int i = 0; i < fineSize; ++i)
              for (int idx = P_mat->ia[i]; idx < P_mat->ia[i+1]; ++idx)
                  fine[i] += P_mat->vals[idx] * coarse[P_mat->ja[idx]];
        } else {
          throw std::runtime_error("Implement applyPAdd in base class.");
        }
  }
};

class RS_InterpolationMatrix : public Prolongator {
public:
RS_InterpolationMatrix(std::shared_ptr<CSRMatrix> A, const std::vector<int>& tags, 
                           const std::vector<double>* x_proto = nullptr,
                           double theta = 0.25, bool use_truncation = true, double trunc_tol = 0.2) {
        this->fineSize = A->n;
        std::vector<int> g2c(fineSize, -1);
        int c_count = 0;
        for (int i = 0; i < fineSize; ++i) {
            if (tags[i] == 1) { g2c[i] = c_count++; }
        }
        this->coarseSize = c_count;

        std::vector<double> max_offdiag(fineSize, 0.0);
        for (int i = 0; i < fineSize; ++i) {
            for (int idx = A->ia[i]; idx < A->ia[i + 1]; ++idx) {
                int j = A->ja[idx];
                if (i != j) max_offdiag[i] = std::max(max_offdiag[i], -A->vals[idx]);
            }
        }

        P_mat = std::make_shared<CSRMatrix>();
        P_mat->n = fineSize;
        
        std::vector<int> P_ia(fineSize + 1, 0);
        std::vector<int> P_ja;
        std::vector<double> P_vals;

        std::vector<int> in_Ci(fineSize, -1);         
        std::vector<double> weights(coarseSize, 0.0); 

        for (int i = 0; i < fineSize; ++i) {
            if (tags[i] == 1) { // NODE_C
                P_ja.push_back(g2c[i]);
                P_vals.push_back(1.0);
            } 
            else if (tags[i] == 0) { // NODE_F
                double a_ii = 0.0;
                double sum_weak = 0.0;
                
                std::vector<int>    C_i_fine;
                std::vector<int>    F_i_fine;
                std::vector<double> F_i_vals; 

                // 1. Passagem na linha de A
                for (int idx = A->ia[i]; idx < A->ia[i + 1]; ++idx) {
                    int j = A->ja[idx];
                    double val = A->vals[idx];
                    
                    if (j == i) {
                        a_ii = val;
                    } else if (-val >= theta * max_offdiag[i]) { 
                        if (tags[j] == 1) {
                            C_i_fine.push_back(j);
                            in_Ci[j] = i; 
                            weights[g2c[j]] = val; 
                        } else if (tags[j] == 0) {
                            F_i_fine.push_back(j);
                            F_i_vals.push_back(val); 
                        }
                    } else {
                        // FIX 1: Escala correta para as conexões fracas no aAMG
                        if (x_proto != nullptr && std::abs((*x_proto)[i]) > 1e-15) {
                            sum_weak += val * ((*x_proto)[j] / (*x_proto)[i]);
                        } else {
                            sum_weak += val;
                        }
                    }
                }

                double D_i = a_ii + sum_weak;

                if (!C_i_fine.empty() && std::abs(D_i) > 1e-14) {
                    
                    // RAMIFICAÇÃO: AMG CLÁSSICO vs aAMG
                    if (x_proto == nullptr) {
                        // ------------------------------------------
                        // AMG Clássico (Ruge-Stüben)
                        // ------------------------------------------
                        for (size_t f_idx = 0; f_idx < F_i_fine.size(); ++f_idx) {
                            int k = F_i_fine[f_idx];
                            double a_ik = F_i_vals[f_idx];

                            double sum_a_km = 0.0;
                            for (int idx = A->ia[k]; idx < A->ia[k + 1]; ++idx) {
                                if (in_Ci[ A->ja[idx] ] == i) { 
                                    sum_a_km += A->vals[idx];
                                }
                            }

                            if (std::abs(sum_a_km) > 1e-14) {
                                for (int idx = A->ia[k]; idx < A->ia[k + 1]; ++idx) {
                                    int j = A->ja[idx];
                                    if (in_Ci[j] == i) {
                                        weights[g2c[j]] += (a_ik * A->vals[idx]) / sum_a_km;
                                    }
                                }
                            } else {
                                D_i += a_ik; 
                            }
                        }
                    } else {
                        // ------------------------------------------
                        // aAMG (Adaptativo)
                        // ------------------------------------------
                        for (size_t f_idx = 0; f_idx < F_i_fine.size(); ++f_idx) {
                            int k = F_i_fine[f_idx];
                            double a_ik = F_i_vals[f_idx];

                            double sum_akm_xproto = 0.0;
                            for (int idx = A->ia[k]; idx < A->ia[k + 1]; ++idx) {
                                int j = A->ja[idx];
                                if (in_Ci[j] == i) { 
                                    sum_akm_xproto += A->vals[idx] * (*x_proto)[j];
                                }
                            }

                            if (std::abs(sum_akm_xproto) > 1e-14) {
                                double x_k = (*x_proto)[k];
                                for (int idx = A->ia[k]; idx < A->ia[k + 1]; ++idx) {
                                    int j = A->ja[idx];
                                    if (in_Ci[j] == i) {
                                        double distributed_weight = (a_ik * A->vals[idx] * x_k) / sum_akm_xproto;
                                        weights[g2c[j]] += distributed_weight;
                                    }
                                }
                            } else {
                                // FIX 2: Escalar o fallback pelo protótipo F/i
                                D_i += a_ik * ((*x_proto)[k] / (*x_proto)[i]); 
                            }
                        }
                    }

                    std::vector<std::pair<int, double>> row_entries;

                    // FIX 3: Desabilitar o truncamento padrão se estivermos usando aAMG
                    if (use_truncation && x_proto == nullptr) {
                        double max_w = 0.0;
                        for (int j : C_i_fine) {
                            double w = std::abs(weights[g2c[j]] / D_i);
                            if (w > max_w) max_w = w;
                        }

                        double sum_dropped = 0.0;
                        double sum_kept = 0.0;

                        for (int j : C_i_fine) {
                            int coarse_j = g2c[j];
                            double w = -weights[coarse_j] / D_i;
                            if (std::abs(w) < trunc_tol * max_w) {
                                sum_dropped += w;
                            } else {
                                row_entries.push_back({coarse_j, w});
                                sum_kept += w;
                            }
                        }

                        if (sum_kept != 0.0 && sum_dropped != 0.0) {
                            double rescale_factor = (sum_kept + sum_dropped) / sum_kept;
                            for (auto& entry : row_entries) {
                                entry.second *= rescale_factor;
                            }
                        }
                    } else {
                        // ---- LÓGICA SEM TRUNCAMENTO ----
                        for (int j : C_i_fine) {
                            int coarse_j = g2c[j];
                            double w = -weights[coarse_j] / D_i;
                            if (std::abs(w) > 1e-14) {
                                row_entries.push_back({coarse_j, w});
                            }
                        }
                    }

                    std::sort(row_entries.begin(), row_entries.end());
                    for (const auto& entry : row_entries) {
                        P_ja.push_back(entry.first);
                        P_vals.push_back(entry.second);
                    }
                    for (int j : C_i_fine) {
                        in_Ci[j]        = -1;
                        weights[g2c[j]] = 0.0;
                    }
                }
            }
            P_ia[i + 1] = P_ja.size();
        }

        P_mat->nnz = P_ja.size();
        P_mat->ia = (int*)malloc((fineSize + 1) * sizeof(int));
        std::copy(P_ia.begin(), P_ia.end(), P_mat->ia);
        P_mat->ja = (int*)malloc(P_mat->nnz * sizeof(int));
        std::copy(P_ja.begin(), P_ja.end(), P_mat->ja);
        P_mat->vals = (double*)malloc(P_mat->nnz * sizeof(double));
        std::copy(P_vals.begin(), P_vals.end(), P_mat->vals);
    }

    void applyP(const std::vector<double> &y, std::vector<double> &z) override {
        z.assign(fineSize, 0.0);
        spmv_csr(P_mat.get(), y.data(), z.data());
    }

    

    void applyPt(const std::vector<double> &y, std::vector<double> &z) override {
        z.assign(coarseSize, 0.0);
        for (int i = 0; i < fineSize; ++i) {
            for (int idx = P_mat->ia[i]; idx < P_mat->ia[i + 1]; ++idx) {
                z[P_mat->ja[idx]] += P_mat->vals[idx] * y[i];
            }
        }
    }
    std::shared_ptr<CSRMatrix> PtAP(const CSRMatrix &Ainput) override {
        auto Ac = std::make_shared<CSRMatrix>();
        Ac->n = coarseSize;

        // 1. Transpor P para Pt (A sua implementação original é ótima, mantida intacta)
        std::vector<int> Pt_ia(coarseSize + 1, 0);
        for (int i = 0; i < fineSize; ++i) {
            for (int idx = P_mat->ia[i]; idx < P_mat->ia[i + 1]; ++idx) {
                Pt_ia[ P_mat->ja[idx] + 1 ]++;
            }
        }
        for (int i = 0; i < coarseSize; ++i) {
            Pt_ia[i + 1] += Pt_ia[i];
        }
        
        std::vector<int> current_row = Pt_ia;
        std::vector<int> Pt_ja(P_mat->nnz);
        std::vector<double> Pt_vals(P_mat->nnz);
        
        for (int i = 0; i < fineSize; ++i) {
            for (int idx = P_mat->ia[i]; idx < P_mat->ia[i + 1]; ++idx) {
                int col = P_mat->ja[idx];
                int dest = current_row[col]++;
                Pt_ja[dest] = i;
                Pt_vals[dest] = P_mat->vals[idx];
            }
        }

        // 2. Multiplicação Tripla Fundida (Ac = Pt * A * P)
        std::vector<int> Ac_ia(coarseSize + 1, 0);
        std::vector<int> Ac_ja;
        std::vector<double> Ac_vals;

        // arrays SPA com tamanho reduzido! Apenas O(coarseSize).
        std::vector<int> marker_Ac(coarseSize, -1);
        std::vector<double> vals_Ac(coarseSize, 0.0);

        for (int I = 0; I < coarseSize; ++I) {
            std::vector<int> cols_Ac;
            
            // a) Percorre os nós finos 'i' pertencentes à linha 'I' de Pt
            for (int pt_idx = Pt_ia[I]; pt_idx < Pt_ia[I + 1]; ++pt_idx) {
                int i = Pt_ja[pt_idx];
                double pt_val = Pt_vals[pt_idx];

                // b) Percorre os vizinhos 'j' do nó fino 'i' na matriz A
                for (int a_idx = Ainput.ia[i]; a_idx < Ainput.ia[i + 1]; ++a_idx) {
                    int j = Ainput.ja[a_idx];
                    double a_val = Ainput.vals[a_idx];
                    double pt_a_val = pt_val * a_val; // Pré-calcula o fator

                    if (std::abs(pt_a_val) < 1e-14) continue; // Poda numérica

                    // c) Distribui para as colunas grossas 'J' via matriz P
                    for (int p_idx = P_mat->ia[j]; p_idx < P_mat->ia[j + 1]; ++p_idx) {
                        int J = P_mat->ja[p_idx];
                        double p_val = P_mat->vals[p_idx];
                        double final_val = pt_a_val * p_val;

                        // Acumulação SPA DIRETA no agregado J
                        if (marker_Ac[J] != I) {
                            marker_Ac[J] = I;
                            vals_Ac[J] = final_val;
                            cols_Ac.push_back(J);
                        } else {
                            vals_Ac[J] += final_val;
                        }
                    }
                }
            }

            // Ordenação e limpeza do SPA para a linha I
            std::sort(cols_Ac.begin(), cols_Ac.end());
            for (int col : cols_Ac) {
                if (std::abs(vals_Ac[col]) > 1e-14) {
                    Ac_ja.push_back(col);
                    Ac_vals.push_back(vals_Ac[col]);
                }
            }
            Ac_ia[I + 1] = Ac_ja.size();
        }

        // 3. Montagem Final (Mantida intacta)
        Ac->nnz = Ac_ja.size();
        Ac->ia = (int*)malloc((coarseSize + 1) * sizeof(int));
        std::copy(Ac_ia.begin(), Ac_ia.end(), Ac->ia);
        
        Ac->ja = (int*)malloc(Ac->nnz * sizeof(int));
        std::copy(Ac_ja.begin(), Ac_ja.end(), Ac->ja);
        
        Ac->vals = (double*)malloc(Ac->nnz * sizeof(double));
        std::copy(Ac_vals.begin(), Ac_vals.end(), Ac->vals);

        return Ac;
    }
};


class Coarsening {
public:
    std::shared_ptr<CSRMatrix> A = nullptr; 
    virtual ~Coarsening() = default; 
    virtual std::shared_ptr<Prolongator> getProlongator() = 0;
    void setMatrix(std::shared_ptr<CSRMatrix> matrix) { A = matrix; }
    virtual std::shared_ptr<Coarsening> clone() = 0;
};

enum NodeTag { NODE_F = 0, NODE_C = 1, NODE_UNDEFINED = -1, NODE_FC = 2};

class CFSplitCoarsening : public Coarsening {
public:
    virtual ~CFSplitCoarsening() = default;
    
    std::vector<int> node_tags; 

    virtual std::shared_ptr<Prolongator> getProlongator() override = 0;
};
class RugeStuben : public CFSplitCoarsening {
public:
    double theta;
    double trunc_tol;
    RugeStuben(double theta = 0.25, double trunc = 0.2 ) : theta(theta), trunc_tol(trunc)  {}
    
    virtual std::shared_ptr<Coarsening> clone() override {
      return std::make_shared<RugeStuben>(theta, trunc_tol);
    }

    std::shared_ptr<Prolongator> getProlongator() override {
        if (!A) throw std::runtime_error("RugeStuben: Matriz A nula.");
        
        int n = A->n;
        node_tags.assign(n, NODE_UNDEFINED);
        
        // ESTRUTURAS DE LISTA LIGADA DENTRO DE VETOR (Substitui std::vector<vector<int>>)
        std::vector<int> S_head(n, -1), ST_head(n, -1);
        std::vector<int> S_next(A->nnz, -1), ST_next(A->nnz, -1);
        std::vector<int> S_ja(A->nnz), ST_ja(A->nnz);
        int s_count = 0, st_count = 0;

        std::vector<int> lambda(n, 0);

        // 1. Identificar conexões fortes usando estruturas planas
        for (int i = 0; i < n; ++i) {
            double max_offdiag = 0.0;
            for (int k = A->ia[i]; k < A->ia[i+1]; ++k) {
                if (A->ja[k] != i) max_offdiag = std::max(max_offdiag, -A->vals[k]);
            }

            for (int k = A->ia[i]; k < A->ia[i+1]; ++k) {
                int j = A->ja[k];
                if (i != j && -A->vals[k] >= theta * max_offdiag) {
                    // Adiciona j a S_i
                    S_ja[s_count] = j;
                    S_next[s_count] = S_head[i];
                    S_head[i] = s_count++;
                    
                    // Adiciona i a ST_j
                    ST_ja[st_count] = i;
                    ST_next[st_count] = ST_head[j];
                    ST_head[j] = st_count++;
                    
                    lambda[j]++; // Medida de influência preliminar
                }
            }
        }

        // 2. Fila de Prioridade em Baldes (Lazy Bucket Queue - Custo O(1))
        int max_lambda = 0;
        for (int i = 0; i < n; i++) max_lambda = std::max(max_lambda, lambda[i]);

        std::vector<std::vector<int>> buckets(max_lambda + 1);
        for (int i = 0; i < n; i++) buckets[lambda[i]].push_back(i);

        int top_bucket = max_lambda;

        while (top_bucket >= 0) {
            while (!buckets[top_bucket].empty()) {
                int i = buckets[top_bucket].back();
                buckets[top_bucket].pop_back();

                // Ignora nós já marcados ou que "subiram" de balde
                if (node_tags[i] != NODE_UNDEFINED) continue;
                if (lambda[i] != top_bucket) continue; 

                node_tags[i] = NODE_C; // Torna ponto Grosso

                // Caminha pela lista ST usando ponteiros planos
                for (int edge = ST_head[i]; edge != -1; edge = ST_next[edge]) {
                    int j = ST_ja[edge];
                    
                    if (node_tags[j] == NODE_UNDEFINED) {
                        node_tags[j] = NODE_F;
                        
                        // Incrementa o lambda dos vizinhos e reposiciona nos baldes
                        for (int s_edge = S_head[j]; s_edge != -1; s_edge = S_next[s_edge]) {
                            int k = S_ja[s_edge];
                            if (node_tags[k] == NODE_UNDEFINED) {
                                lambda[k]++;
                                
                                // Redimensiona os baldes dinamicamente se necessário
                                if (lambda[k] >= buckets.size()) {
                                    buckets.push_back(std::vector<int>());
                                }
                                buckets[lambda[k]].push_back(k);
                                
                                // Eleva o ponteiro de top_bucket para buscar o novo pico
                                if (lambda[k] > top_bucket) {
                                    top_bucket = lambda[k];
                                }
                            }
                        }
                    }
                }
            }
            top_bucket--;
        }

        // Limpeza final
        for (int i = 0; i < n; i++) {
            if (node_tags[i] == NODE_UNDEFINED) node_tags[i] = NODE_F;
        }

        return buildRSInterpolation();
    }

private:
    std::shared_ptr<Prolongator> buildRSInterpolation() {
        return std::make_shared<RS_InterpolationMatrix>(A, node_tags, nullptr, theta, true, trunc_tol );
    }
};



class UnitaryProlongator : public Prolongator {
public:
  std::vector<long> partition; 

  UnitaryProlongator(int nFine, int nCoarse, const std::vector<long> &p) {
    this->fineSize = nFine;
    this->coarseSize = nCoarse;
    this->partition = p;
  }

  // Projeta v_coarse para v_fine: v_fine[i] = v_coarse[partition[i]]
  void applyP(const std::vector<double> &y, std::vector<double> &z) override {
    z.assign(fineSize, 0.0);
    for (int i = 0; i < fineSize; ++i) {
      long c_idx = partition[i];
      // Se o ponto i pertence a um agregado válido, projeta o valor
      if (c_idx >= 0) {
        z[i] = y[c_idx];
      }
    }
  }

  // Restringe v_fine para v_coarse: v_coarse[J] = sum_{i in Agregado J} v_fine[i]
  void applyPt(const std::vector<double> &y, std::vector<double> &z) override {
    z.assign(coarseSize, 0.0);
    for (int i = 0; i < fineSize; ++i) {
      long c_idx = partition[i];
      // Se o ponto i não for negativo, contribui para a soma do agregado
      if (c_idx >= 0) {
        z[c_idx] += y[i];
      }
    }
  }

  void applyPAdd(const std::vector<double> &coarse, std::vector<double> &fine) override {
    for (int i = 0; i < fineSize; ++i) {
      long c_idx = partition[i];
      // Se o ponto i pertence a um agregado válido, soma o valor projetado
      if (c_idx >= 0) {
        fine[i] += coarse[c_idx];
      }
    }
  }

  // Triplo produto de matrizes: Ac = Pt * A * P
  std::shared_ptr<CSRMatrix> PtAP(const CSRMatrix &A) override {
    auto Ac = std::make_shared<CSRMatrix>();
    Ac->n = coarseSize;

    std::vector<std::map<int, double>> sparse_map(coarseSize);

    for (int i = 0; i < A.n; ++i) {
      int coarse_i = partition[i];
      if (coarse_i < 0) continue; // Pula linhas de pontos isolados

      for (int idx = A.ia[i]; idx < A.ia[i + 1]; ++idx) {
        int j = A.ja[idx];
        int coarse_j = partition[j];
        
        // Pula conexões com pontos que não estão em nenhum agregado grosso
        if (coarse_j < 0) continue; 

        double val = A.vals[idx];
        sparse_map[coarse_i][coarse_j] += val;
      }
    }

    // O restante do código de conversão para CSR permanece o mesmo
    Ac->ia = (int *)malloc((coarseSize + 1) * sizeof(int));
    Ac->ia[0] = 0;

    int total_nnz = 0;
    for (int i = 0; i < coarseSize; ++i) {
      total_nnz += sparse_map[i].size();
      Ac->ia[i + 1] = total_nnz;
    }

    Ac->nnz = total_nnz;
    Ac->ja = (int *)malloc(total_nnz * sizeof(int));
    Ac->vals = (double *)malloc(total_nnz * sizeof(double));

    int curr = 0;
    for (int i = 0; i < coarseSize; ++i) {
      for (auto const &[col, val] : sparse_map[i]) {
        Ac->ja[curr] = col;
        Ac->vals[curr] = val;
        curr++;
      }
    }

    return Ac;
  }
};


class SmoothedProlongator2 : public Prolongator {
public:
  std::shared_ptr<Prolongator> P0;
  std::shared_ptr<CSRMatrix> A;
  std::shared_ptr<CSRMatrix> P_explicit; 

  std::vector<double> Dinv;
  double omega;

  SmoothedProlongator2(std::shared_ptr<Prolongator> baseP,
                      std::shared_ptr<CSRMatrix> A_, double omega = 0.7)
      : P0(baseP), A(A_), omega(omega) {
    this->fineSize = baseP->fineSize;
    this->coarseSize = baseP->coarseSize;

    // 1. Extrair a partição do prolongador base
    auto unitary_base = std::dynamic_pointer_cast<UnitaryProlongator>(baseP);
    if (!unitary_base) {
      throw std::runtime_error("SmoothedProlongator exige um UnitaryProlongator base para extrair a particao.");
    }
    const auto& partition = unitary_base->partition;

    // 2. Construir D^{-1}
    Dinv.resize(A->n, 1.0);
    for (int i = 0; i < A->n; i++) {
      double row_sum = 0.0;
      for (int k = A->ia[i]; k < A->ia[i + 1]; k++) {
        row_sum += std::abs(A->vals[k]);
      }
      if (row_sum > 1e-14) Dinv[i] = 1.0 / row_sum;
    }

    // 3. Construir P_explicit = (I - w D^{-1} A) P0 em formato CSR
    P_explicit = std::make_shared<CSRMatrix>();
    P_explicit->n = fineSize;
    
    std::vector<int> P_ia(fineSize + 1, 0);
    std::vector<int> P_ja;
    std::vector<double> P_vals;

    // Padrão Sparse Accumulator (SPA) para construção rápida
    std::vector<int> marker(coarseSize, -1);
    std::vector<double> temp_vals(coarseSize, 0.0);
    std::vector<int> current_cols;

    for (int i = 0; i < fineSize; ++i) {
      current_cols.clear();

      // Contribuição de P0 (identidade mapeada)
      int c_i = partition[i];
      if (c_i >= 0) {
        marker[c_i] = i;
        temp_vals[c_i] = 1.0;
        current_cols.push_back(c_i);
      }

      // Contribuição de -omega * Dinv * A * P0
      double factor = -omega * Dinv[i];
      for (int idx = A->ia[i]; idx < A->ia[i + 1]; ++idx) {
        int k = A->ja[idx];
        int c_k = partition[k];
        if (c_k >= 0) {
          if (marker[c_k] != i) {
            marker[c_k] = i;
            temp_vals[c_k] = 0.0;
            current_cols.push_back(c_k);
          }
          temp_vals[c_k] += factor * A->vals[idx];
        }
      }

      std::sort(current_cols.begin(), current_cols.end()); // Manter CSR estrito
      for (int col : current_cols) {
        if (std::abs(temp_vals[col]) > 1e-14) {
          P_ja.push_back(col);
          P_vals.push_back(temp_vals[col]);
        }
      }
      P_ia[i + 1] = P_ja.size();
    }

    // Alocação nativa (compatível com os mallocs da sua estrutura)
    P_explicit->nnz = P_ja.size();
    P_explicit->ia = (int*)malloc((fineSize + 1) * sizeof(int));
    std::copy(P_ia.begin(), P_ia.end(), P_explicit->ia);
    P_explicit->ja = (int*)malloc(P_explicit->nnz * sizeof(int));
    std::copy(P_ja.begin(), P_ja.end(), P_explicit->ja);
    P_explicit->vals = (double*)malloc(P_explicit->nnz * sizeof(double));
    std::copy(P_vals.begin(), P_vals.end(), P_explicit->vals);
  }

  // Com a matriz explícita, applyP virou um SpMV nativo!
  void applyP(const std::vector<double> &y, std::vector<double> &z) override {
    z.assign(fineSize, 0.0);
    spmv_csr(P_explicit.get(), y.data(), z.data());
  }

  // applyPt virou um SpMV Transposto nativo!
  void applyPt(const std::vector<double> &y, std::vector<double> &z) override {
    z.assign(coarseSize, 0.0);
    for (int i = 0; i < fineSize; ++i) {
      for (int idx = P_explicit->ia[i]; idx < P_explicit->ia[i + 1]; ++idx) {
        z[P_explicit->ja[idx]] += P_explicit->vals[idx] * y[i];
      }
    }
  }
std::shared_ptr<CSRMatrix> PtAP(const CSRMatrix &Ainput) override {
    auto Ac = std::make_shared<CSRMatrix>();
    Ac->n = coarseSize;

    // 1. Calcular a transposta explícita: Pt = P_explicit^T
    // Isso é feito rapidamente contando os elementos por coluna
    std::vector<int> Pt_ia(coarseSize + 1, 0);
    for (int i = 0; i < fineSize; ++i) {
      for (int idx = P_explicit->ia[i]; idx < P_explicit->ia[i + 1]; ++idx) {
        Pt_ia[ P_explicit->ja[idx] + 1 ]++;
      }
    }
    for (int i = 0; i < coarseSize; ++i) {
      Pt_ia[i + 1] += Pt_ia[i];
    }
    
    std::vector<int> current_row = Pt_ia;
    std::vector<int> Pt_ja(P_explicit->nnz);
    std::vector<double> Pt_vals(P_explicit->nnz);
    
    for (int i = 0; i < fineSize; ++i) {
      for (int idx = P_explicit->ia[i]; idx < P_explicit->ia[i + 1]; ++idx) {
        int col = P_explicit->ja[idx];
        int dest = current_row[col]++;
        Pt_ja[dest] = i;
        Pt_vals[dest] = P_explicit->vals[idx];
      }
    }

    // 2. Multiplicação Tripla: Ac = Pt * A * P linha por linha
    std::vector<int> Ac_ia(coarseSize + 1, 0);
    std::vector<int> Ac_ja;
    std::vector<double> Ac_vals;

    // Workspaces (SPA) alocados UMA única vez
    std::vector<int> marker_T(fineSize, -1);
    std::vector<double> vals_T(fineSize, 0.0);

    std::vector<int> marker_Ac(coarseSize, -1);
    std::vector<double> vals_Ac(coarseSize, 0.0);

    for (int i = 0; i < coarseSize; ++i) {
      std::vector<int> cols_T;
      
      // a) Calcular a linha i da matriz intermediária: T_i = (Pt)_i * A
      for (int pt_idx = Pt_ia[i]; pt_idx < Pt_ia[i + 1]; ++pt_idx) {
        int k = Pt_ja[pt_idx];
        double pt_val = Pt_vals[pt_idx];

        for (int a_idx = Ainput.ia[k]; a_idx < Ainput.ia[k + 1]; ++a_idx) {
          int c = Ainput.ja[a_idx];
          double a_val = Ainput.vals[a_idx];

          if (marker_T[c] != i) {
            marker_T[c] = i;
            vals_T[c] = pt_val * a_val;
            cols_T.push_back(c);
          } else {
            vals_T[c] += pt_val * a_val;
          }
        }
      }

      std::vector<int> cols_Ac;
      
      // b) Calcular a linha i da matriz final: (Ac)_i = T_i * P
      for (int k : cols_T) {
        double t_val = vals_T[k];
        if (std::abs(t_val) < 1e-14) continue; // Filtro de zero

        for (int p_idx = P_explicit->ia[k]; p_idx < P_explicit->ia[k + 1]; ++p_idx) {
          int c = P_explicit->ja[p_idx];
          double p_val = P_explicit->vals[p_idx];

          if (marker_Ac[c] != i) {
            marker_Ac[c] = i;
            vals_Ac[c] = t_val * p_val;
            cols_Ac.push_back(c);
          } else {
            vals_Ac[c] += t_val * p_val;
          }
        }
      }

      // c) Coletar os valores acumulados para estruturar o CSR do Ac
      std::sort(cols_Ac.begin(), cols_Ac.end()); // Opcional, mas recomendado para solver Krylov subsequente
      for (int col : cols_Ac) {
        if (std::abs(vals_Ac[col]) > 1e-14) {
          Ac_ja.push_back(col);
          Ac_vals.push_back(vals_Ac[col]);
        }
      }
      Ac_ia[i + 1] = Ac_ja.size();
    }

    // 3. Alocação e transferência final nativa
    Ac->nnz = Ac_ja.size();
    Ac->ia = (int *)malloc((coarseSize + 1) * sizeof(int));
    std::copy(Ac_ia.begin(), Ac_ia.end(), Ac->ia);
    
    Ac->ja = (int *)malloc(Ac->nnz * sizeof(int));
    std::copy(Ac_ja.begin(), Ac_ja.end(), Ac->ja);
    
    Ac->vals = (double *)malloc(Ac->nnz * sizeof(double));
    std::copy(Ac_vals.begin(), Ac_vals.end(), Ac->vals);

    return Ac;
  }
};

struct StrengthOfConnection {
    std::vector<bool> is_strong; // Mapeado para o ja/vals da matriz CSR
    
    StrengthOfConnection(const CSRMatrix &A, double eps) {
        is_strong.assign(A.nnz, false);
        double eps_sq = eps * eps;

        for (int i = 0; i < A.n; ++i) {
            double diag_i = 0;
            // Busca a diagonal de i
            for (int k = A.ia[i]; k < A.ia[i+1]; ++k) {
                if (A.ja[k] == i) { diag_i = std::abs(A.vals[k]); break; }
            }

            for (int k = A.ia[i]; k < A.ia[i+1]; ++k) {
                int j = A.ja[k];
                if (i == j) continue;

                double diag_j = 0;
                // Busca a diagonal de j (em matrizes simétricas isso pode ser otimizado)
                for (int kj = A.ia[j]; kj < A.ia[j+1]; ++kj) {
                    if (A.ja[kj] == j) { diag_j = std::abs(A.vals[kj]); break; }
                }

                if ((A.vals[k] * A.vals[k]) > eps_sq * (diag_i * diag_j)) {
                    is_strong[k] = true;
                }
            }
        }
    }
};




class SmoothedProlongator : public Prolongator {
public:
  std::shared_ptr<Prolongator> P0;
  std::shared_ptr<CSRMatrix> A;
  std::shared_ptr<CSRMatrix> P_explicit; 
  double eps_strong;
  double omega;

  SmoothedProlongator(std::shared_ptr<Prolongator> baseP,
                      std::shared_ptr<CSRMatrix> A_, double omega = 0.66666667, double eps_strong = 0.02 )
      : P0(baseP), A(A_), omega(omega), eps_strong(eps_strong) {
    this->fineSize = baseP->fineSize;
    this->coarseSize = baseP->coarseSize;


    StrengthOfConnection SOC( *A, eps_strong );
    


    // 1. Extrair a partição do prolongador base (Matriz P_tilde)
    auto unitary_base = std::dynamic_pointer_cast<UnitaryProlongator>(baseP);
    if (!unitary_base) {
      throw std::runtime_error("SmoothedProlongator exige um UnitaryProlongator base para extrair a particao.");
    }
    const auto& partition = unitary_base->partition;

    P_explicit = std::make_shared<CSRMatrix>();
    P_explicit->n = fineSize;
    
    std::vector<int> P_ia(fineSize + 1, 0);
    std::vector<int> P_ja;
    std::vector<double> P_vals;

    // Padrão Sparse Accumulator (SPA) para acumulação rápida linha a linha
    std::vector<int> marker(coarseSize, -1);
    std::vector<double> temp_vals(coarseSize, 0.0);
    std::vector<int> current_cols;

    for (int i = 0; i < fineSize; ++i) {
      current_cols.clear();

      // --- Passo A: Calcular D_ii filtrada (Lumping) ---
      double D_ii_filtered = 0.0;
      for (int idx = A->ia[i]; idx < A->ia[i + 1]; ++idx) {
          int j = A->ja[idx];
          // Diagonal original OU conexão fraca: soma no D_ii
          if (j == i || !SOC.is_strong[idx]) {
              D_ii_filtered += A->vals[idx];
          }
      }

      // Fator de escala da suavização
      double invD_omega = (std::abs(D_ii_filtered) > 1e-14) ? (-omega / D_ii_filtered) : 0.0;

      // --- Passo B: Construir a linha i de P = P0 + invD_omega * (Af * P0) ---
      
      // 1. Contribuição da Identidade (P0): Nó i pertence ao seu próprio agregado
      int aggregate_i = partition[i];
      if (aggregate_i >= 0) {
          marker[aggregate_i] = i;
          temp_vals[aggregate_i] = 1.0; // P0 é 1 no agregado do nó
          current_cols.push_back(aggregate_i);
      }

      // 2. Contribuição da Suavização (A_filtrada * P0)
      for (int idx = A->ia[i]; idx < A->ia[i + 1]; ++idx) {
          int j = A->ja[idx];

          if (j == i || !SOC.is_strong[idx]) continue; // Pula diagonal e fracas

          int aggregate_j = partition[j];
          if (aggregate_j >= 0) {
              double val = invD_omega * A->vals[idx];
              
              if (marker[aggregate_j] != i) {
                  marker[aggregate_j] = i;
                  temp_vals[aggregate_j] = val;
                  current_cols.push_back(aggregate_j);
              } else {
                  temp_vals[aggregate_j] += val;
              }
          }
      }
      // Ordena as colunas para manter o padrão CSR estrito
      std::sort(current_cols.begin(), current_cols.end()); 
      
      for (int col : current_cols) {
        if (std::abs(temp_vals[col]) > 1e-14) { // Filtro de Zeros
          P_ja.push_back(col);
          P_vals.push_back(temp_vals[col]);
        }
      }
      P_ia[i + 1] = P_ja.size();
    }

    // 3. Alocação nativa
    P_explicit->nnz = P_ja.size();
    P_explicit->ia = (int*)malloc((fineSize + 1) * sizeof(int));
    std::copy(P_ia.begin(), P_ia.end(), P_explicit->ia);
    
    P_explicit->ja = (int*)malloc(P_explicit->nnz * sizeof(int));
    std::copy(P_ja.begin(), P_ja.end(), P_explicit->ja);
    
    P_explicit->vals = (double*)malloc(P_explicit->nnz * sizeof(double));
    std::copy(P_vals.begin(), P_vals.end(), P_explicit->vals);
  }
  virtual void applyPAdd(const std::vector<double>& coarse, std::vector<double>& fine) override  {
        if( P_explicit )
        {
          for (int i = 0; i < fineSize; ++i)
              for (int idx = P_explicit->ia[i]; idx < P_explicit->ia[i+1]; ++idx)
                  fine[i] += P_explicit->vals[idx] * coarse[P_explicit->ja[idx]];
        } else {
          throw std::runtime_error("set P_explicit.");
        }
  }
    // Com a matriz explícita, applyP virou um SpMV nativo!
  void applyP(const std::vector<double> &y, std::vector<double> &z) override {
    z.assign(fineSize, 0.0);
    spmv_csr(P_explicit.get(), y.data(), z.data());
  }

  // applyPt virou um SpMV Transposto nativo!
  void applyPt(const std::vector<double> &y, std::vector<double> &z) override {
    z.assign(coarseSize, 0.0);
    for (int i = 0; i < fineSize; ++i) {
      for (int idx = P_explicit->ia[i]; idx < P_explicit->ia[i + 1]; ++idx) {
        z[P_explicit->ja[idx]] += P_explicit->vals[idx] * y[i];
      }
    }
  }
std::shared_ptr<CSRMatrix> PtAP(const CSRMatrix &Ainput) override {
    auto Ac = std::make_shared<CSRMatrix>();
    Ac->n = coarseSize;

    // 1. Calcular a transposta explícita: Pt = P_explicit^T
    // Isso é feito rapidamente contando os elementos por coluna
    std::vector<int> Pt_ia(coarseSize + 1, 0);
    for (int i = 0; i < fineSize; ++i) {
      for (int idx = P_explicit->ia[i]; idx < P_explicit->ia[i + 1]; ++idx) {
        Pt_ia[ P_explicit->ja[idx] + 1 ]++;
      }
    }
    for (int i = 0; i < coarseSize; ++i) {
      Pt_ia[i + 1] += Pt_ia[i];
    }
    
    std::vector<int> current_row = Pt_ia;
    std::vector<int> Pt_ja(P_explicit->nnz);
    std::vector<double> Pt_vals(P_explicit->nnz);
    
    for (int i = 0; i < fineSize; ++i) {
      for (int idx = P_explicit->ia[i]; idx < P_explicit->ia[i + 1]; ++idx) {
        int col = P_explicit->ja[idx];
        int dest = current_row[col]++;
        Pt_ja[dest] = i;
        Pt_vals[dest] = P_explicit->vals[idx];
      }
    }

    // 2. Multiplicação Tripla: Ac = Pt * A * P linha por linha
    std::vector<int> Ac_ia(coarseSize + 1, 0);
    std::vector<int> Ac_ja;
    std::vector<double> Ac_vals;

    // Workspaces (SPA) alocados UMA única vez
    std::vector<int> marker_T(fineSize, -1);
    std::vector<double> vals_T(fineSize, 0.0);

    std::vector<int> marker_Ac(coarseSize, -1);
    std::vector<double> vals_Ac(coarseSize, 0.0);

    for (int i = 0; i < coarseSize; ++i) {
      std::vector<int> cols_T;
      
      // a) Calcular a linha i da matriz intermediária: T_i = (Pt)_i * A
      for (int pt_idx = Pt_ia[i]; pt_idx < Pt_ia[i + 1]; ++pt_idx) {
        int k = Pt_ja[pt_idx];
        double pt_val = Pt_vals[pt_idx];

        for (int a_idx = Ainput.ia[k]; a_idx < Ainput.ia[k + 1]; ++a_idx) {
          int c = Ainput.ja[a_idx];
          double a_val = Ainput.vals[a_idx];

          if (marker_T[c] != i) {
            marker_T[c] = i;
            vals_T[c] = pt_val * a_val;
            cols_T.push_back(c);
          } else {
            vals_T[c] += pt_val * a_val;
          }
        }
      }

      std::vector<int> cols_Ac;
      
      // b) Calcular a linha i da matriz final: (Ac)_i = T_i * P
      for (int k : cols_T) {
        double t_val = vals_T[k];
        if (std::abs(t_val) < 1e-14) continue; // Filtro de zero

        for (int p_idx = P_explicit->ia[k]; p_idx < P_explicit->ia[k + 1]; ++p_idx) {
          int c = P_explicit->ja[p_idx];
          double p_val = P_explicit->vals[p_idx];

          if (marker_Ac[c] != i) {
            marker_Ac[c] = i;
            vals_Ac[c] = t_val * p_val;
            cols_Ac.push_back(c);
          } else {
            vals_Ac[c] += t_val * p_val;
          }
        }
      }

      // c) Coletar os valores acumulados para estruturar o CSR do Ac
      std::sort(cols_Ac.begin(), cols_Ac.end()); // Opcional, mas recomendado para solver Krylov subsequente
      for (int col : cols_Ac) {
        if (std::abs(vals_Ac[col]) > 1e-14) {
          Ac_ja.push_back(col);
          Ac_vals.push_back(vals_Ac[col]);
        }
      }
      Ac_ia[i + 1] = Ac_ja.size();
    }

    // 3. Alocação e transferência final nativa
    Ac->nnz = Ac_ja.size();
    Ac->ia = (int *)malloc((coarseSize + 1) * sizeof(int));
    std::copy(Ac_ia.begin(), Ac_ia.end(), Ac->ia);
    
    Ac->ja = (int *)malloc(Ac->nnz * sizeof(int));
    std::copy(Ac_ja.begin(), Ac_ja.end(), Ac->ja);
    
    Ac->vals = (double *)malloc(Ac->nnz * sizeof(double));
    std::copy(Ac_vals.begin(), Ac_vals.end(), Ac->vals);

    return Ac;
  }
};

class OrtonormalProlongator : public Prolongator {
public:
  std::vector<long> partition; // partition[i] = ID do agregado do ponto fino i
  std::vector<long>
      partitionSize; // partition[i] = ID do agregado do ponto fino i

  OrtonormalProlongator(int nFine, int nCoarse, const std::vector<long> &p) {
    this->fineSize = nFine;
    this->coarseSize = nCoarse;
    this->partition = p;
    partitionSize.assign(nCoarse, 0);
    for (long i = 0; i < nFine; i++) {
      partitionSize[partition[i]]++;
    }
  }

  // Projeta v_coarse para v_fine: v_fine[i] = v_coarse[partition[i]]
  void applyP(const std::vector<double> &y, std::vector<double> &z) override {
    z.assign(fineSize, 0.0);
    for (int i = 0; i < fineSize; ++i) {
      z[i] = y[partition[i]] / sqrt(partitionSize[partition[i]]);
    }
  }

  // Restringe v_fine para v_coarse: v_coarse[J] = sum_{i in Agregado J}
  // v_fine[i]
  void applyPt(const std::vector<double> &y, std::vector<double> &z) override {
    z.assign(coarseSize, 0.0);
    for (int i = 0; i < fineSize; ++i) {
      z[partition[i]] += y[i] / sqrt(partitionSize[partition[i]]);
    }
  }

  // Triplo produto de matrizes: Ac = Pt * A * P
  std::shared_ptr<CSRMatrix> PtAP(const CSRMatrix &A) override {
    auto Ac = std::make_shared<CSRMatrix>();
    Ac->n = coarseSize;

    // Mapa temporário para construir as linhas da matriz grossa
    // coarse_row -> {coarse_col -> value}
    std::vector<std::map<int, double>> sparse_map(coarseSize);

    for (int i = 0; i < A.n; ++i) {
      int coarse_i = partition[i];

      for (int idx = A.ia[i]; idx < A.ia[i + 1]; ++idx) {
        int j = A.ja[idx];
        int coarse_j = partition[j];
        double val = A.vals[idx];

        sparse_map[coarse_i][coarse_j] += val *
                                          (1 / sqrt(partitionSize[coarse_i])) *
                                          (1 / sqrt(partitionSize[coarse_j]));
      }
    }

    // Converter o mapa para o formato CSR
    Ac->ia = (int *)malloc((coarseSize + 1) * sizeof(int));
    Ac->ia[0] = 0;

    int total_nnz = 0;
    for (int i = 0; i < coarseSize; ++i) {
      total_nnz += sparse_map[i].size();
      Ac->ia[i + 1] = total_nnz;
    }

    Ac->nnz = total_nnz;
    Ac->ja = (int *)malloc(total_nnz * sizeof(int));
    Ac->vals = (double *)malloc(total_nnz * sizeof(double));

    int curr = 0;
    for (int i = 0; i < coarseSize; ++i) {
      for (auto const &[col, val] : sparse_map[i]) {
        Ac->ja[curr] = col;
        Ac->vals[curr] = val;
        curr++;
      }
    }

    return Ac;
  }
};

class Aggregation : public Coarsening{
public:
  // Pode começar nulo
  bool smooth = false;
  Aggregation() = default;
  virtual ~Aggregation() = default;

  

};

class BFSAggregation : public Aggregation {
public:
  double theta;
  long coarseRatio;
  long coarse_Size = -1;
  void setCoarseSize( long coarseSize ) {
    this->coarse_Size = coarseSize;
  }

  virtual std::shared_ptr<Coarsening> clone() override {
    return std::make_shared< BFSAggregation >( coarseRatio, theta );
  }

  // Construtor: recebe a matriz fina, o tamanho desejado da malha grossa e o
  // threshold
  BFSAggregation(long coarseRatio, double theta = 0.25)
      : coarseRatio(coarseRatio), theta(theta) {}

  std::shared_ptr<Prolongator> getProlongator() override {
    if (!A)
      throw std::runtime_error("Agregador chamado sem matriz definida!");
    const long n = A->n;
    long coarseSize = (long)std::round((double)A->n / coarseRatio);

    if( coarse_Size != -1 )
      coarseSize = coarse_Size;
    
    
    
    std::vector<long> partition(n, -1);
    std::vector<bool> assigned(n, false);
    std::vector<std::vector<long>> strong_neighbors(n);

    for (long i = 0; i < n; ++i) {
      double max_val = 0.0;
      for (int k = A->ia[i]; k < A->ia[i + 1]; ++k) {
        if (A->ja[k] != i) {
          max_val = std::max(max_val, std::abs(A->vals[k]));
        }
      }
      for (int k = A->ia[i]; k < A->ia[i + 1]; ++k) {
        int j = A->ja[k];
        if (j != i && std::abs(A->vals[k]) >= theta * max_val) { // 
          strong_neighbors[i].push_back(j);
        }
      }
    }

    // long nx = 100, ny = 50, nz = 50;
    // long nsx = 10, nsy = 5, nsz = 5; // Número de sementes por eixo

    // // Forçamos o coarseSize exato para bater com as sementes (250)
    // coarseSize = nsx * nsy * nsz;
    // std::vector<std::queue<long>> queues(coarseSize);

    // // Espaçamento (tamanho do bloco de cada agregado)
    // long dx = nx / nsx; // 100 / 10 = 10
    // long dy = ny / nsy; // 50 / 5 = 10
    // long dz = nz / nsz; // 50 / 5 = 10

    // long aggregate_id = 0;

    // for (long sz = 0; sz < nsz; ++sz) {
    //     for (long sy = 0; sy < nsy; ++sy) {
    //         for (long sx = 0; sx < nsx; ++sx) {

    //             // Calculamos a coordenada (x, y, z) da semente.
    //             // O "+ dx/2" serve para colocar a semente no CENTRO do
    //             bloco,
    //             // ajudando a BFS a criar agregados mais redondinhos e bem
    //             comportados. long x = sx * dx + dx / 2; long y = sy * dy + dy
    //             / 2; long z = sz * dz + dz / 2;

    //             // Conversão 3D -> 1D (Assumindo ordenação Lexicográfica: X
    //             varia mais rápido) long seed_idx = x + y * nx + z * nx * ny;

    //             if (seed_idx < n) {
    //                 partition[seed_idx] = aggregate_id;
    //                 assigned[seed_idx] = true;
    //                 queues[aggregate_id].push(seed_idx);
    //             }
    //             aggregate_id++;
    //         }
    //     }
    // }

    long step = std::max<long>(1, n / coarseSize);
    std::vector<std::queue<long>> queues(coarseSize);

    for (long i = 0; i < coarseSize; ++i) {
      long seed_idx = i * step;
      if (seed_idx < n) {
        partition[seed_idx] = i;
        assigned[seed_idx] = true;
        queues[i].push(seed_idx);
      }
    }

    // 3. BFS Simultânea (Crescimento dos Agregados)
    bool haveQueues = true;
    while (haveQueues) {
      haveQueues = false;
      for (int i = 0; i < coarseSize; i++) {
        if (!queues[i].empty()) {
          haveQueues = true;
          long u = queues[i].front();
          queues[i].pop();

          for (long v : strong_neighbors[u]) {
            if (!assigned[v]) {
              partition[v] = i; // Atribui ao mesmo agregado da semente i
              assigned[v] = true;
              queues[i].push(v);
            }
          }
        }
      }
    }

    std::mt19937_64 rng(0x892631);
    std::uniform_int_distribution<long> dist(0, coarseSize - 1);
    
    for (long i = 0; i < n; ++i) {
      if (partition[i] == -1) {
        double best_val = -1.0;
        long best_group = -1;
        for (int k = A->ia[i]; k < A->ia[i + 1]; ++k) {
          int j = A->ja[k];
          if (partition[j] != -1 && std::abs(A->vals[k]) > best_val) {
            best_val = std::abs(A->vals[k]);
            best_group = partition[j];
          }
        }
        if (best_group != -1) {
          partition[i] = best_group;
        } else {
          partition[i] = dist(rng);
        }
      }
    }

    // return std::make_shared<OrtonormalProlongator>((int)n, (int)coarseSize,
    // partition);

    // save_partition( "partition.dat", partition, coarseSize, _nx, _ny, _nz );

    
    // exit( 0 );
    auto baseP =  std::make_shared<UnitaryProlongator>((int)n, (int)coarseSize,
                                                partition);
    // auto baseP = std::make_shared<OrtonormalProlongator>((int)n,
    // (int)coarseSize, partition); return
    //if( !smooth )
    return baseP;
    //else
    //  return std::make_shared<SmoothedProlongator>(baseP, A, 0.66667);
  }
};


class VanekAggregation : public Aggregation {
public:
    double eps_strong;

    // Construtor: não recebe mais coarseRatio, apenas o threshold de conexão
    VanekAggregation(double eps_strong = 0.08) : eps_strong(eps_strong) {}
    virtual std::shared_ptr<Coarsening> clone() override {
      throw std::runtime_error("not implemented");
    }
    std::shared_ptr<Prolongator> getProlongator() override {
        if (!A) throw std::runtime_error("Agregador chamado sem matriz definida!");
        
        const long n = A->n;
        std::vector<ptrdiff_t> id(n, -1); // -1: undefined, -2: removed (isolated)
        
        // 1. Pré-calculo da diagonal para o critério simétrico
        // |Aij|^2 / (Aii * Ajj) > eps^2
        std::vector<double> dia(n);
        for (long i = 0; i < n; ++i) {
            for (int k = A->ia[i]; k < A->ia[i + 1]; ++k) {
                if (A->ja[k] == i) {
                    dia[i] = A->vals[k];
                    break;
                }
            }
        }

        // 2. Identificar Conexões Fortes
        // Armazenamos como um vetor de flags paralelo aos valores da matriz (CSR)
        std::vector<bool> strong_connection(A->nnz, false);
        double eps_sq = eps_strong * eps_strong;

        for (long i = 0; i < n; ++i) {
            double eps_dia_i = eps_sq * std::abs(dia[i]);
            for (int k = A->ia[i]; k < A->ia[i + 1]; ++k) {
                long j = A->ja[k];
                if (i != j) {
                    // Critério simétrico de Vaněk
                    if (eps_dia_i * std::abs(dia[j]) < A->vals[k] * A->vals[k]) {
                        strong_connection[k] = true;
                    }
                }
            }
        }

        // 3. Filtrar nós isolados (Dirichlet ou sem conexões fortes)
        for (long i = 0; i < n; ++i) {
            bool has_strong = false;
            for (int k = A->ia[i]; k < A->ia[i + 1]; ++k) {
                if (strong_connection[k]) {
                    has_strong = true;
                    break;
                }
            }
            if (!has_strong) id[i] = -2; // Marcar como removido
        }

        // 4. Processo de Agregação (Greedy Pass)
        long count = 0;
        for (long i = 0; i < n; ++i) {
            if (id[i] != -1) continue; // Pula se já for semente, vizinho ou removido

            // Nó i torna-se uma semente (Seed)
            long cur_id = count++;
            id[i] = cur_id;

            // Fase 1: Agregar vizinhos fortes diretos
            for (int k = A->ia[i]; k < A->ia[i + 1]; ++k) {
                if (strong_connection[k]) {
                    long j = A->ja[k];
                    if (id[j] == -1) id[j] = cur_id;
                }
            }
        }

        // Fase 2: Lidar com nós que ficaram "undefined" (opcional, mas recomendado)
        // Anexar nós órfãos ao agregado vizinho com conexão mais forte
        for (long i = 0; i < n; ++i) {
            if (id[i] == -1) {
                double max_v = -1.0;
                long best_aggr = -1;
                for (int k = A->ia[i]; k < A->ia[i + 1]; ++k) {
                    long j = A->ja[k];
                    if (id[j] >= 0 && std::abs(A->vals[k]) > max_v) {
                        max_v = std::abs(A->vals[k]);
                        best_aggr = id[j];
                    }
                }
                id[i] = best_aggr;
            }
        }

        // Caso especial: se o nó ainda for -1 ou -2, joga no agregado 0 ou trata como erro
        for (long i = 0; i < n; i++) if (id[i] < 0) id[i] = 0;

        // Na sua infraestrutura, o Prolongator recebe int
        auto P = std::make_shared<UnitaryProlongator>((int)n, (int)count, id);
        return P;
        //return std::make_shared<SmoothedProlongator>( P, A, 0.6666667 );
    }
};

class Coarse : public Preconditioner {
private:
  std::shared_ptr<Solver> internalSolver;
  std::shared_ptr<Aggregation> aggregator;
  std::shared_ptr<Prolongator> P;
  std::shared_ptr<CSRMatrix> coarseA;

  // Workspaces: Alocados uma única vez no setup()
  mutable std::vector<double> y_coarse;
  mutable std::vector<double> x_coarse;

public:
  Coarse(const std::shared_ptr<Solver> &internalSolver,
         const std::shared_ptr<Aggregation> &aggregator)
      : internalSolver(internalSolver), aggregator(aggregator) {}

  void setup(const CSRMatrix &A) override {

    auto ptrA = std::make_shared<CSRMatrix>(A);
    aggregator->setMatrix(ptrA);
    P = aggregator->getProlongator();
    coarseA = P->PtAP(A);
    
    internalSolver->setOperator(coarseA);
    internalSolver->verbose = false;
    internalSolver->setup();
    y_coarse.resize(P->coarseSize);
    x_coarse.resize(P->coarseSize);

  }
  std::shared_ptr<Preconditioner> clone() const override {
    throw std::runtime_error("not implemented");
  }

  void apply(const std::vector<double> &y,
             std::vector<double> &z) const override {
    P->applyPt(y, y_coarse);
    
    std::fill(x_coarse.begin(), x_coarse.end(), 0.0);
    internalSolver->solve(y_coarse, x_coarse);
    
    P->applyP(x_coarse, z);

  }
};
// Constantes de estado para a agregação
constexpr int REMOVED = -2;
constexpr int UNDEFINED = -1;

class PlainAggregation : public Aggregation {

public:
    double eps_strong;
    // Construtor recebe os parâmetros do YAML (com valor padrão)
    PlainAggregation(double eps = 0.01) : eps_strong(eps) {}
    virtual std::shared_ptr<Coarsening> clone() override {
      return std::make_shared< PlainAggregation >( eps_strong );
    }
   std::shared_ptr<Prolongator> getProlongator() override {
        if (!A) {
            throw std::runtime_error("[PlainAggregation] A matriz 'A' não foi injetada antes de agregar.");
        }

        int n = A->n;
        std::vector<int> id(n, UNDEFINED);
        double eps_sq = eps_strong * eps_strong;

        // Pré-extrair as diagonais para acesso O(1)
        std::vector<double> diag(n, 0.0);
        for (int i = 0; i < n; i++) {
            for (int ptr = A->ia[i]; ptr < A->ia[i+1]; ptr++) {
                if (A->ja[ptr] == i) {
                    diag[i] = A->vals[ptr];
                    break;
                }
            }
        }

        // Função Lambda para verificar a Conexão Forte
        auto is_strong = [&](int i, int j, double a_ij) {
            if (i == j) return false;
            return (a_ij * a_ij) > (eps_sq * std::abs(diag[i] * diag[j])); 
        };

        // =====================================================================
        // PASSOS 1 e 2: Avaliar conexões fortes
        // =====================================================================
        for (int i = 0; i < n; i++) {
            bool has_strong_neighbor = false;
            for (int ptr = A->ia[i]; ptr < A->ia[i+1]; ptr++) {
                int j = A->ja[ptr];
                if (is_strong(i, j, A->vals[ptr])) {
                    has_strong_neighbor = true;
                    break;
                }
            }
            if (!has_strong_neighbor) {
                id[i] = REMOVED;
            }
        }

        // =====================================================================
        // PASSO 3: Processo de Agregação Gulosa
        // =====================================================================
        int C = 0; 
        for (int i = 0; i < n; i++) {
            if (id[i] != UNDEFINED) continue;

            id[i] = C; 

            std::vector<int> new_neighbors;

            // Agrupar vizinhos diretos
            for (int ptr = A->ia[i]; ptr < A->ia[i+1]; ptr++) {
                int j = A->ja[ptr];
                if (is_strong(i, j, A->vals[ptr])) {
                    if (id[j] == UNDEFINED) {
                        id[j] = C;
                        new_neighbors.push_back(j);
                    }
                }
            }

            // Captura temporária na fronteira
            for (int j : new_neighbors) {
                for (int ptr = A->ia[j]; ptr < A->ia[j+1]; ptr++) {
                    int k = A->ja[ptr];
                    if (is_strong(j, k, A->vals[ptr])) {
                        if (id[k] == UNDEFINED) {
                            id[k] = C;
                        }
                    }
                }
            }
            C++;
        }

        // =====================================================================
        // PASSO 4: Limpeza e Renumeração
        // =====================================================================
        int M = 0; // M será o tamanho exato da malha grossa (nCoarse)
        if (C > 0) {
            std::vector<int> cnt(C, 0);
            
            for (int i = 0; i < n; i++) {
                if (id[i] >= 0) cnt[id[i]] = 1;
            }

            for (int k = 1; k < C; k++) {
                cnt[k] = cnt[k] + cnt[k-1];
            }

            M = cnt[C-1]; // Total de agregados válidos

            if (C > M) {
                for (int i = 0; i < n; i++) {
                    if (id[i] >= 0) {
                        id[i] = cnt[id[i]] - 1;
                    }
                }
            }
        }

        // =====================================================================
        // PASSO 5: Instanciar e retornar o Prolongador (Adaptado para o seu código)
        // =====================================================================
        
        // Converte o vetor de 'int' para 'long' conforme exigido pela sua classe
        std::vector<long> partition_long(n);
        for (int i = 0; i < n; i++) {
            if (id[i] < 0) {
                partition_long[i] = -1; // Nó isolado/removido
            } else {
                partition_long[i] = static_cast<long>(id[i]);
            }
        }

        // Instancia passando: nFine (n), nCoarse (M), e o vetor long.
        return std::make_shared<UnitaryProlongator>(n, M, partition_long);
    }

};


class SmootherAggregation : public Aggregation {
public:
    PlainAggregation plain;
    double eps;
    SmootherAggregation(double eps = 0.08f) : eps( eps ), plain( eps ) {
        
    }
    virtual std::shared_ptr<Coarsening> clone() override {
      return std::make_shared<SmootherAggregation>( eps );
    }
    std::shared_ptr<Prolongator> getProlongator() override {
        plain.setMatrix( A );
        return std::make_shared< SmoothedProlongator>( plain.getProlongator(), this->A, 0.666666667 );
    }
};


class PlainAggregation2 : public Aggregation {
public:
    float eps_strong;

    PlainAggregation2(float eps = 0.08f) : eps_strong(eps) {}
    virtual std::shared_ptr<Coarsening> clone() override {
      throw std::runtime_error("not implemented");
    }
    std::shared_ptr<Prolongator> getProlongator() override {
        if (!A) throw std::runtime_error("PlainAgrregator: Matriz A NULL.");

        amgcl::backend::crs<double, int, int> A_amgcl;
        
        A_amgcl.nrows = A->n;
        A_amgcl.ncols = A->n;
        A_amgcl.nnz = A->nnz;
        A_amgcl.ptr = A->ia;
        A_amgcl.col = A->ja;
        A_amgcl.val = A->vals;
        A_amgcl.own_data = false; 

        amgcl::coarsening::plain_aggregates::params prm;
        prm.eps_strong = eps_strong;

        amgcl::coarsening::plain_aggregates aggr(A_amgcl, prm);

        const int n = A->n;
        std::vector<long> partition(n);
        for (int i = 0; i < n; ++i) {
            partition[i] = (aggr.id[i] < 0) ? -1 : static_cast<long>(aggr.id[i]);
        }

        auto P = std::make_shared<UnitaryProlongator>(n, (int)aggr.count, partition);
        return P; // std::make_shared<SmoothedProlongator>( P, A ); 
    }
};

enum class CycleType {
    V_CYCLE,
    W_CYCLE,
    F_CYCLE,
    K_CYCLE
};
#if 0
class MultilevelCoarse : public Preconditioner {
private:
  std::shared_ptr<CSRMatrix> A;
  std::shared_ptr<Prolongator> P;
  bool                            smooth_aggregator = false;
  int relax_sweeps;
  std::shared_ptr<Preconditioner> smoother = nullptr;
  std::shared_ptr<Coarsening>     coarsening;


  // Solvers
  std::shared_ptr<Solver> internalSolver;
  std::shared_ptr<MultilevelCoarse>
      nextLevelPrecond; 
  std::shared_ptr<Solver> bottomSolver;

  int currentLevel;
  int maxLevels;
  int bottomSolverDimension;


  int pre_relax_sweeps_l0;
  int pos_relax_sweeps_l0;

  mutable std::vector<double> r_fine, r_coarse, e_coarse, e_fine, smooth_corr;

public:
  MultilevelCoarse(std::shared_ptr<Coarsening> coarsening,
                   std::shared_ptr<Solver> bottom,
                   std::shared_ptr<Preconditioner> smoother,
                   int max_lvl, int bottom_dim, int relax_sweeps, int pre_relax_sweeps_l0, int pos_relax_sweeps_l0 )
      : coarsening(coarsening), bottomSolver(bottom), smoother(smoother),
       maxLevels(max_lvl),
        bottomSolverDimension(bottom_dim), currentLevel(0), relax_sweeps(relax_sweeps), 
        pre_relax_sweeps_l0(pre_relax_sweeps_l0), pos_relax_sweeps_l0(pos_relax_sweeps_l0) {}

void setup(std::shared_ptr<CSRMatrix> matrix_ptr, int current_level, int max_levels) {
    // Marca o início total deste nível
    auto t_start_level = std::chrono::high_resolution_clock::now();

    this->A = matrix_ptr; 
    this->currentLevel = current_level;
    this->maxLevels = max_levels;

    if (smoother)
        smoother->setup(*A);
        
    std::cout << "\n=== Nível " << currentLevel << " | INTERN: " << A->n << " ===" << std::endl;
    
    // Critério de parada (Fundo do V-Cycle)
    if (currentLevel >= maxLevels || A->n <= bottomSolverDimension) {
        this->P = nullptr;
        this->internalSolver = bottomSolver; 
        this->internalSolver->setOperator(A);
        this->internalSolver->setup();
        this->internalSolver->verbose = false;

        r_fine.assign(A->n, 0.0);
        e_fine.assign(A->n, 0.0);
        return;
    } 

    // ---------------------------------------------------------
    // 1. Profiling do Coarsening (Criação de P)
    // ---------------------------------------------------------
    auto t0 = std::chrono::high_resolution_clock::now();
    
    coarsening->setMatrix(A);
    P = coarsening->getProlongator();
    
    auto t1 = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> time_coarsening = t1 - t0;
    //std::cout << "  [Tempo] 1. Coarsening (P): " << time_coarsening.count() << " s\n";

    // ---------------------------------------------------------
    // 2. Profiling do Produto de Galerkin (PtAP)
    // ---------------------------------------------------------
    t0 = std::chrono::high_resolution_clock::now();
    
    auto coarseA = P->PtAP(*A);
    
    t1 = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> time_ptap = t1 - t0;
    //std::cout << "  [Tempo] 2. Galerkin (PtAP): " << time_ptap.count() << " s\n";

    // ---------------------------------------------------------
    // 3. Profiling das Alocações e Recursão
    // ---------------------------------------------------------
    t0 = std::chrono::high_resolution_clock::now();

    r_fine.assign(A->n, 0.0);
    e_fine.assign(A->n, 0.0);
    smooth_corr.assign(A->n, 0.0);
    r_coarse.assign(P->coarseSize, 0.0);
    e_coarse.assign(P->coarseSize, 0.0);

    auto l_coarsening = coarsening->clone();
    if (auto ptr = std::dynamic_pointer_cast<RugeStuben>(l_coarsening)) {
        ptr->theta = std::min(ptr->theta * 1.25, 0.7); 
    }

    this->nextLevelPrecond = std::make_shared<MultilevelCoarse>(
        l_coarsening, bottomSolver, smoother->clone(), maxLevels,
        bottomSolverDimension, relax_sweeps, pre_relax_sweeps_l0, pos_relax_sweeps_l0
    );

    // Recursão
    this->nextLevelPrecond->setup(coarseA, currentLevel + 1, maxLevels);
   
    this->internalSolver = nullptr;

    t1 = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> time_rest = t1 - t0;
    // O tempo de recursão vai incluir o setup completo dos próximos níveis.
    // O tempo "líquido" deste nível será time_rest - (Tempo Total do Nível + 1)
    //std::cout << "  [Tempo] 3. Alocações e Chamada Nível " << currentLevel+1 << ": " << time_rest.count() << " s\n";

    // ---------------------------------------------------------
    // Tempo Total do Nível
    // ---------------------------------------------------------
    auto t_end_level = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> time_total = t_end_level - t_start_level;
    //std::cout << "  [Tempo] TOTAL (Nível " << currentLevel << "): " << time_total.count() << " s\n";
}

void setup(const CSRMatrix &matrix) override {
    auto root_matrix = std::make_shared<CSRMatrix>(matrix);
    setup(root_matrix, 0, this->maxLevels);
}  

std::shared_ptr<Preconditioner> clone() const override {
    return nullptr;
}

void apply(const std::vector<double> &rhs, std::vector<double> &x) const override {
    if (!P) {
        internalSolver->solve(rhs, x);
        return;
    }

    std::fill(x.begin(), x.end(), 0.0);

 
    int num_pre_sweeps = (currentLevel == 0) ? pre_relax_sweeps_l0 : relax_sweeps;
    int num_pos_sweeps = (currentLevel == 0) ? pos_relax_sweeps_l0 : relax_sweeps;

    // =====================================
    // 1. Pré-Relaxamento
    // =====================================
    if (smoother && num_pre_sweeps > 0) {
        for (int iter = 0; iter < num_pre_sweeps; ++iter) {
            compute_residual(rhs, x, r_fine);
            smoother->apply(r_fine, smooth_corr);
            for (size_t i = 0; i < x.size(); ++i)
                x[i] += smooth_corr[i];
        }
        compute_residual(rhs, x, r_fine); 
    } else {
        r_fine = rhs;
    }
    
    // O resíduo DEVE ser calculado com o 'x' final do pré-relaxamento.
    // Isso garante que a malha grossa receba o resíduo correto.
    

    // =====================================
    // 2. Restrição
    // =====================================
    P->applyPt(r_fine, r_coarse);

    // =====================================
    // 3. Correção na malha grossa
    // =====================================
    std::fill(e_coarse.begin(), e_coarse.end(), 0.0);
    if (nextLevelPrecond)
        nextLevelPrecond->apply(r_coarse, e_coarse);

    // =====================================
    // 4. Prolongamento (Sua otimização applyPAdd está PERFEITA)
    // =====================================
    P->applyPAdd(e_coarse, x);

    // =====================================
    // 5. Pós-Relaxamento
    // =====================================
    if (smoother && num_pos_sweeps > 0) {
        for (int iter = 0; iter < num_pos_sweeps; ++iter) {
            compute_residual(rhs, x, r_fine);
            smoother->apply(r_fine, smooth_corr);
            for (size_t i = 0; i < x.size(); ++i)
                x[i] += smooth_corr[i];
        }
    }
}



  void compute_residual(const std::vector<double> &b,
                        const std::vector<double> &x_curr,
                        std::vector<double> &r) const {
    spmv_csr(A.get(), x_curr.data(), r.data());
    for (size_t i = 0; i < b.size(); ++i) {
      r[i] = b[i] - r[i];
    }
  }
};
#endif

class AMG : public Preconditioner {
private:
    std::shared_ptr<CSRMatrix> A;
    std::shared_ptr<Prolongator> P;
    bool                            smooth_aggregator = false;
    int pre_relax_sweeps;
    int pos_relax_sweeps;
    
    std::shared_ptr<Preconditioner> smoother = nullptr;
    std::shared_ptr<Coarsening>     coarsening;

    // Solvers
    std::shared_ptr<Solver> internalSolver;
    std::shared_ptr<AMG> nextLevelPrecond; 
    std::shared_ptr<Solver> bottomSolver;
    std::shared_ptr<BiCGStab> kCycleSolver = nullptr;

    int currentLevel;
    int maxLevels;
    int bottomSolverDimension;

    bool enforceMMatrix;

    int pre_relax_sweeps_l0;
    int pos_relax_sweeps_l0;
    CycleType cycleType; // Novo: Armazena o tipo de ciclo

    double level_factor;

    mutable std::vector<double> r_fine, r_coarse, e_coarse, e_fine, smooth_corr;

    // Novo: Método recursivo interno que lida com o tipo de ciclo e chutes iniciais não-nulos
    void apply_cycle(const std::vector<double> &rhs, std::vector<double> &x, CycleType type, bool is_x_zero) const {
        if (!P) {
            internalSolver->solve(rhs, x);
            return;
        }

        int num_pre_sweeps = (currentLevel == 0) ? pre_relax_sweeps_l0 : pre_relax_sweeps;
        int num_pos_sweeps = (currentLevel == 0) ? pos_relax_sweeps_l0 : pos_relax_sweeps;

        // =====================================
        // 1. Pré-Relaxamento
        // =====================================
        if (smoother && num_pre_sweeps > 0) {
            for (int iter = 0; iter < num_pre_sweeps; ++iter) {
                // Se for a primeira iteração e x é zero, economizamos um SpMV
                if (is_x_zero && iter == 0) {
                    r_fine = rhs; 
                } else {
                    compute_residual(rhs, x, r_fine);
                }
                
                smoother->apply(r_fine, smooth_corr);
                
                for (size_t i = 0; i < x.size(); ++i)
                    x[i] += smooth_corr[i];
            }
            compute_residual(rhs, x, r_fine); 
        } else {
            if (is_x_zero) {
                r_fine = rhs;
            } else {
                compute_residual(rhs, x, r_fine);
            }
        }

        // =====================================
        // 2. Restrição
        // =====================================
        P->applyPt(r_fine, r_coarse);

        // =====================================
        // 3. Correção na malha grossa
        // =====================================
        std::fill(e_coarse.begin(), e_coarse.end(), 0.0);
        
        if (nextLevelPrecond) {
            if (type == CycleType::V_CYCLE) {
                nextLevelPrecond->apply_cycle(r_coarse, e_coarse, CycleType::V_CYCLE, true);
            } 
            else if (type == CycleType::W_CYCLE) {
                // W-Cycle: Duas passagens completas de W
                nextLevelPrecond->apply_cycle(r_coarse, e_coarse, CycleType::W_CYCLE, true);
                nextLevelPrecond->apply_cycle(r_coarse, e_coarse, CycleType::W_CYCLE, false); // false = e_coarse tem dados!
            } 
            else if (type == CycleType::F_CYCLE) {
                // F-Cycle: Uma passagem de F descendo, seguida de um V subindo
                nextLevelPrecond->apply_cycle(r_coarse, e_coarse, CycleType::F_CYCLE, true);
                nextLevelPrecond->apply_cycle(r_coarse, e_coarse, CycleType::V_CYCLE, false); // false = e_coarse tem dados!
            } else if (type == CycleType::K_CYCLE) {
                if (kCycleSolver) {
                    kCycleSolver->setPreconditioner(this->nextLevelPrecond);
                    kCycleSolver->solve(r_coarse, e_coarse);
                }
            }
        }

        // =====================================
        // 4. Prolongamento
        // =====================================
        P->applyPAdd(e_coarse, x);

        // =====================================
        // 5. Pós-Relaxamento
        // =====================================
        if (smoother && num_pos_sweeps > 0) {
            for (int iter = 0; iter < num_pos_sweeps; ++iter) {
                compute_residual(rhs, x, r_fine);
                smoother->apply(r_fine, smooth_corr);
                for (size_t i = 0; i < x.size(); ++i)
                    x[i] += smooth_corr[i];
            }
        }
    }
    void enforce_m_matrix_inplace(std::shared_ptr<CSRMatrix> A) {
          if (!A) return;

          int n = A->n;
          int write_idx = 0;
          
          // Precisamos salvar o início da próxima linha antes de sobrescrever o A->ia
          int next_row_start = A->ia[0]; 
          A->ia[0] = 0;

          for (int i = 0; i < n; ++i) {
              int row_start = next_row_start;
              next_row_start = A->ia[i + 1]; // Salva o original para a próxima iteração
              
              double diag_addition = 0.0;
              int diag_loc = -1; // Guardará o índice de escrita onde a diagonal foi parar

              // Avaliação e cópia in-place
              for (int idx = row_start; idx < next_row_start; ++idx) {
                  int j = A->ja[idx];
                  double val = A->vals[idx];

                  if (i == j) {
                      // É a diagonal principal. Registramos onde ela vai ficar armazenada.
                      diag_loc = write_idx;
                      A->ja[write_idx] = j;
                      A->vals[write_idx] = val;
                      write_idx++;
                  } 
                  else if (val > 0.0) {
                      // É um valor positivo fora da diagonal (ofensor da M-Matrix).
                      // Fazemos o lumping (acumulamos) e pulamos o write_idx (compactação).
                      diag_addition += val;
                  } 
                  else {
                      // É um valor negativo fora da diagonal (conexão válida). Copiamos.
                      A->ja[write_idx] = j;
                      A->vals[write_idx] = val;
                      write_idx++;
                  }
              }

              // Aplica a massa dos elementos positivos removidos diretamente na diagonal
              if (diag_loc != -1) {
                  A->vals[diag_loc] += diag_addition;
              }

              // Atualiza o ponteiro de linha com o novo tamanho compactado
              A->ia[i + 1] = write_idx;
          }

          // Atualiza o número total de elementos não-nulos da matriz
          A->nnz = write_idx;
          
          // Obs: Os arrays A->ja e A->vals continuam com o tamanho original na memória, 
          // mas o lixo no final será ignorado pelo solver pois A->nnz e A->ia limitam a leitura.
      }
public:
    // Construtor atualizado para receber o tipo de ciclo
    AMG(std::shared_ptr<Coarsening> coarsening,
                     std::shared_ptr<Solver> bottom,
                     std::shared_ptr<Preconditioner> smoother,
                     int max_lvl, int bottom_dim, int pre_relax_sweeps,int pos_relax_sweeps, 
                     int pre_relax_sweeps_l0, int pos_relax_sweeps_l0, double level_factor,
                     CycleType cycle_type = CycleType::V_CYCLE, bool enforceMMatrix = false ) 
        : coarsening(coarsening), bottomSolver(bottom), smoother(smoother),
          maxLevels(max_lvl), bottomSolverDimension(bottom_dim), currentLevel(0), 
          pre_relax_sweeps(pre_relax_sweeps),pos_relax_sweeps(pos_relax_sweeps), pre_relax_sweeps_l0(pre_relax_sweeps_l0), 
          pos_relax_sweeps_l0(pos_relax_sweeps_l0), cycleType(cycle_type), level_factor(level_factor), enforceMMatrix(enforceMMatrix){}

    void setup(std::shared_ptr<CSRMatrix> matrix_ptr, int current_level, int max_levels) {
        auto t_start_level = std::chrono::high_resolution_clock::now();
        this->A = matrix_ptr; 
        this->currentLevel = current_level;
        this->maxLevels = max_levels;

        if (smoother)
            smoother->setup(*A);
            
        //std::cout << "\n=== Nível " << currentLevel << " | INTERN: " << A->n << " ===" << std::endl;
        
        if (currentLevel >= maxLevels || A->n <= bottomSolverDimension) {
            this->P = nullptr;
            this->internalSolver = bottomSolver; 
            this->internalSolver->setOperator(A);
            this->internalSolver->setup();
            this->internalSolver->verbose = false;

            r_fine.assign(A->n, 0.0);
            e_fine.assign(A->n, 0.0);
            return;
        } 

        auto t0 = std::chrono::high_resolution_clock::now();

        
        if( enforceMMatrix == false ) {

          coarsening->setMatrix(A);
          
        } else {
          auto A_M_Matrix = A->clone();
          enforce_m_matrix_inplace( A_M_Matrix );
          coarsening->setMatrix(A_M_Matrix);
        }     

        P = coarsening->getProlongator();   

        auto coarseA = P->PtAP(*A);
        
        r_fine.assign(A->n, 0.0);
        e_fine.assign(A->n, 0.0);
        smooth_corr.assign(A->n, 0.0);
        r_coarse.assign(P->coarseSize, 0.0);
        e_coarse.assign(P->coarseSize, 0.0);

        auto l_coarsening = coarsening->clone();
        if (auto ptr = std::dynamic_pointer_cast<RugeStuben>(l_coarsening)) {
            ptr->theta = std::min(ptr->theta * level_factor, 0.95); 
        }

        // Passando this->cycleType na recursão do setup!
        this->nextLevelPrecond = std::make_shared<AMG>(
            l_coarsening, bottomSolver, smoother->clone(), maxLevels,
            bottomSolverDimension, pre_relax_sweeps, pos_relax_sweeps, pre_relax_sweeps_l0, 
            pos_relax_sweeps_l0, level_factor, this->cycleType, enforceMMatrix
        );

        this->nextLevelPrecond->setup(coarseA, currentLevel + 1, maxLevels);
        this->internalSolver = nullptr;

        if (this->cycleType == CycleType::K_CYCLE) {
            
            this->kCycleSolver = std::make_shared<BiCGStab>();
            this->kCycleSolver->setOperator(coarseA );
           
            this->kCycleSolver->maxiter = 2; 
            this->kCycleSolver->setup();
        }
    }

    void setup(const CSRMatrix &matrix) override {
        auto root_matrix = std::make_shared<CSRMatrix>(matrix);
        setup(root_matrix, 0, this->maxLevels);
    }  

    std::shared_ptr<Preconditioner> clone() const override {
        return nullptr;
    }

    // A interface original se mantém idêntica, apenas aciona o gatilho inicial
    void apply(const std::vector<double> &rhs, std::vector<double> &x) const override {
        std::fill(x.begin(), x.end(), 0.0); // Preconditioners clássicos começam do zero
        apply_cycle(rhs, x, this->cycleType, true);
    }

    void compute_residual(const std::vector<double> &b,
                          const std::vector<double> &x_curr,
                          std::vector<double> &r) const {
        spmv_csr(A.get(), x_curr.data(), r.data());
        for (size_t i = 0; i < b.size(); ++i) {
            r[i] = b[i] - r[i];
        }
    }
};



class CLJPCoarsening : public CFSplitCoarsening {
public:
    double theta;
    double trunc_tol;
    bool nearNullSpace;

    CLJPCoarsening(double theta = 0.25, double trunc = 0.2, bool nearNullSpace = false ) 
        : theta(theta), trunc_tol(trunc), nearNullSpace(nearNullSpace) {}
    
    virtual std::shared_ptr<Coarsening> clone() override {
        return std::make_shared<CLJPCoarsening>(theta, trunc_tol);
    }

    std::shared_ptr<Prolongator> getProlongator() override {
        if (!A) throw std::runtime_error("CLJPCoarsening: Matriz A nula.");
        
        int n = A->n;
        node_tags.assign(n, NODE_UNDEFINED); // -1 = Indefinido, 0 = F, 1 = C
        
        std::vector<std::vector<int>> S(n);  // S[i]: nós que influenciam 'i' fortemente
        std::vector<std::vector<int>> ST(n); // ST[i]: nós influenciados por 'i' fortemente
        std::vector<double> weights(n, 0.0);

        // Random engine para quebrar empates sistematicamente
        std::mt19937 rng(1337); 
        std::uniform_real_distribution<double> dist(0.0, 1.0);

        // 1. Identificar conexões fortes
        for (int i = 0; i < n; ++i) {
            double max_offdiag = 0.0;
            for (int k = A->ia[i]; k < A->ia[i+1]; ++k) {
                if (A->ja[k] != i) max_offdiag = std::max(max_offdiag, -A->vals[k]);
            }

            for (int k = A->ia[i]; k < A->ia[i+1]; ++k) {
                int j = A->ja[k];
                if (i != j && -A->vals[k] >= theta * max_offdiag) {
                    S[i].push_back(j);
                    ST[j].push_back(i);
                }
            }
        }

        // 2. Inicializar os Pesos Iniciais (W_i = |ST_i| + aleatório)
        for (int i = 0; i < n; i++) {
            weights[i] = static_cast<double>(ST[i].size()) + dist(rng);
        }

        int unassigned_count = n;

        // 3. Loop Iterativo do CLJP
        while (unassigned_count > 0) {
            
            std::vector<int> new_C_nodes;
            std::vector<int> newly_assigned;

            // PASSO A: Encontrar o Conjunto Independente (Local Maxima)
            for (int i = 0; i < n; i++) {
                if (node_tags[i] != NODE_UNDEFINED) continue;

                bool is_local_max = true;
                
                // No CLJP, checamos o grafo não-direcionado S U ST para independência
                for (int j : S[i]) {
                    if (node_tags[j] == NODE_UNDEFINED && weights[j] > weights[i]) {
                        is_local_max = false; break;
                    }
                }
                if (is_local_max) {
                    for (int j : ST[i]) {
                        if (node_tags[j] == NODE_UNDEFINED && weights[j] > weights[i]) {
                            is_local_max = false; break;
                        }
                    }
                }

                if (is_local_max) {
                    new_C_nodes.push_back(i);
                }
            }

            // Tratamento de segurança: se sobrou nó desconectado
            if (new_C_nodes.empty()) {
                for (int i = 0; i < n; i++) {
                    if (node_tags[i] == NODE_UNDEFINED) {
                        node_tags[i] = NODE_C;
                        unassigned_count--;
                    }
                }
                break;
            }

            // PASSO B: Designar os nós C e seus dependentes F
            for (int c_node : new_C_nodes) {
                if (node_tags[c_node] == NODE_UNDEFINED) {
                    node_tags[c_node] = NODE_C;
                    newly_assigned.push_back(c_node);
                    unassigned_count--;
                }

                // Todos que dependem fortemente do novo nó C viram F
                for (int f_node : ST[c_node]) {
                    if (node_tags[f_node] == NODE_UNDEFINED) {
                        node_tags[f_node] = NODE_F;
                        newly_assigned.push_back(f_node);
                        unassigned_count--;
                    }
                }
            }

            // PASSO C: O CORAÇÃO DO CLJP - Atualização Dinâmica de Pesos
            // Se um nó X (C ou F) acabou de ser designado, ele não precisa mais
            // ser "coberto". Portanto, quem influenciava X perde 1 ponto de peso.
            for (int assigned_node : newly_assigned) {
                for (int k : S[assigned_node]) {
                    if (node_tags[k] == NODE_UNDEFINED) {
                        weights[k] -= 1.0; 
                    }
                }
            }
        }
        if( nearNullSpace == false )
          return std::make_shared<RS_InterpolationMatrix>(A, node_tags, nullptr, theta, true, trunc_tol);
        else {
          int num_pos_sweeps = 50;  // Aumentado
          std::vector<double> x_proto(n);
          std::vector<double> r_fine(n, 0.0);
          std::vector<double> smooth_corr(n, 0.0);

          // Chute inicial aleatório
          for (int i = 0; i < n; i++) {
              x_proto[i] = dist(rng);
          }

          // Normalizar chute inicial
          double norm = 0.0;
          for (int i = 0; i < n; i++) norm += x_proto[i] * x_proto[i];
          norm = sqrt(norm);
          for (int i = 0; i < n; i++) x_proto[i] /= norm;

          JacobiPreconditioner jacobi(0.8);  // Damping mais conservador
          jacobi.setup(*A);

          for (int iter = 0; iter < num_pos_sweeps; ++iter) {
              // Calcular resíduo
              for(int i = 0; i < n; ++i) {
                  double ax_i = 0.0;
                  for(int idx = A->ia[i]; idx < A->ia[i+1]; ++idx) {
                      ax_i += A->vals[idx] * x_proto[A->ja[idx]];
                  }
                  r_fine[i] = -ax_i;
              }

              // Remover componente constante (para problemas com null space constante)
              double mean = 0.0;
              for(int i = 0; i < n; ++i) mean += r_fine[i];
              mean /= n;
              for(int i = 0; i < n; ++i) r_fine[i] -= mean;

              jacobi.apply(r_fine, smooth_corr);
              
              for (size_t i = 0; i < n; ++i) {
                  x_proto[i] += smooth_corr[i];
              }

              // Normalizar periodicamente
              if (iter % 10 == 0) {
                  norm = 0.0;
                  for (int i = 0; i < n; i++) norm += x_proto[i] * x_proto[i];
                  norm = sqrt(norm);
                  if (norm > 1e-15) {
                      for (int i = 0; i < n; i++) x_proto[i] /= norm;
                  }
              }
          }

          // Normalização final
          norm = 0.0;
          for (int i = 0; i < n; i++) norm += x_proto[i] * x_proto[i];
          norm = sqrt(norm);
          if (norm > 1e-15) {
              for (int i = 0; i < n; i++) x_proto[i] /= norm;
          }

          return std::make_shared<RS_InterpolationMatrix>(A, node_tags, &x_proto, theta, true, trunc_tol);

        }
    }
};


class PMISCoarsening : public CFSplitCoarsening {
public:
    double theta;
    double trunc_tol;

    PMISCoarsening(double theta = 0.25, double trunc = 0.2) 
        : theta(theta), trunc_tol(trunc) {}
    
    virtual std::shared_ptr<Coarsening> clone() override {
        return std::make_shared<PMISCoarsening>(theta, trunc_tol);
    }

    std::shared_ptr<Prolongator> getProlongator() override {
        if (!A) throw std::runtime_error("PMISCoarsening: Matriz A nula.");
        
        int n = A->n;
        node_tags.assign(n, NODE_UNDEFINED); // -1 = Indefinido, 0 = F, 1 = C
        
        std::vector<std::vector<int>> S(n);  // Vizinhança forte (i depende de j)
        std::vector<std::vector<int>> ST(n); // Vizinhança forte transposta (j depende de i)
        std::vector<double> weights(n, 0.0);

        // Gerador de números aleatórios para quebra de empate (Essencial no PMIS)
        std::mt19937 rng(42); // Semente fixa para reprodutibilidade no debug
        std::uniform_real_distribution<double> dist(0.0, 1.0);

        // 1. Identificar conexões fortes
        for (int i = 0; i < n; ++i) {
            double max_offdiag = 0.0;
            for (int k = A->ia[i]; k < A->ia[i+1]; ++k) {
                if (A->ja[k] != i) max_offdiag = std::max(max_offdiag, -A->vals[k]);
            }

            for (int k = A->ia[i]; k < A->ia[i+1]; ++k) {
                int j = A->ja[k];
                if (i != j && -A->vals[k] >= theta * max_offdiag) {
                    S[i].push_back(j);
                    ST[j].push_back(i);
                }
            }
        }

        // 2. Inicializar os pesos topológicos + fator aleatório (A Mágica do PMIS)
        for (int i = 0; i < n; i++) {
            // O peso principal é o número de nós que dependem fortemente de mim
            // O valor aleatório garante que não haverá empates absolutos
            weights[i] = static_cast<double>(ST[i].size()) + dist(rng);
        }

        int unassigned_count = n;

        // 3. Loop principal de Máximos Locais (Completamente paralelizável via OpenMP)
        while (unassigned_count > 0) {
            
            std::vector<int> new_C_nodes;

            // PASSO A: Encontrar os Máximos Locais Independentes
            // (Com OpenMP, coloque um #pragma omp parallel for aqui)
            for (int i = 0; i < n; i++) {
                if (node_tags[i] != NODE_UNDEFINED) continue;

                bool is_local_max = true;
                
                // Checa todos os vizinhos não-designados em S e ST
                // Se algum vizinho tiver peso maior, 'i' não pode ser C nesta rodada
                for (int j : S[i]) {
                    if (node_tags[j] == NODE_UNDEFINED && weights[j] > weights[i]) {
                        is_local_max = false; break;
                    }
                }
                if (is_local_max) {
                    for (int j : ST[i]) {
                        if (node_tags[j] == NODE_UNDEFINED && weights[j] > weights[i]) {
                            is_local_max = false; break;
                        }
                    }
                }

                if (is_local_max) {
                    new_C_nodes.push_back(i);
                }
            }

            // Se não encontrou nada (grafo totalmente desconectado e restam isolados)
            if (new_C_nodes.empty()) {
                for (int i = 0; i < n; i++) {
                    if (node_tags[i] == NODE_UNDEFINED) {
                        node_tags[i] = NODE_C;
                        unassigned_count--;
                    }
                }
                break;
            }

            // PASSO B: Designar os nós C e rebaixar os vizinhos para F
            for (int c_node : new_C_nodes) {
                if (node_tags[c_node] == NODE_UNDEFINED) {
                    node_tags[c_node] = NODE_C;
                    unassigned_count--;
                }

                // Todos que dependem do novo nó C viram F
                for (int f_node : ST[c_node]) {
                    if (node_tags[f_node] == NODE_UNDEFINED) {
                        node_tags[f_node] = NODE_F;
                        unassigned_count--;
                    }
                }
                
                // (Opcional, mas comum no PMIS rigoroso) Quem o nó C depende fortemente também vira F
                for (int f_node : S[c_node]) {
                    if (node_tags[f_node] == NODE_UNDEFINED) {
                        node_tags[f_node] = NODE_F;
                        unassigned_count--;
                    }
                }
            }
        }

        // Limpeza final de segurança
        for (int i = 0; i < n; i++) {
            if (node_tags[i] == NODE_UNDEFINED) node_tags[i] = NODE_F;
        }

        // Reutilizamos a matriz de interpolação clássica
        return std::make_shared<RS_InterpolationMatrix>(A, node_tags, nullptr, theta, true, trunc_tol);
    }
};