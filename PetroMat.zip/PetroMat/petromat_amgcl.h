#pragma once
#include <amgcl/amg.hpp>
#include <amgcl/make_solver.hpp>
#include <amgcl/solver/cg.hpp>
#include <amgcl/solver/bicgstab.hpp>
#include <amgcl/coarsening/runtime.hpp>
#include <amgcl/relaxation/runtime.hpp>
#include <iostream>
#include <memory>
#include <vector>
#include <tuple>

class AMGcl : public Solver {
private:
    // Configuração do AMGCL para usar os parâmetros em tempo de execução
    typedef amgcl::make_solver<
        amgcl::amg<
            amgcl::backend::builtin<double>,
            amgcl::runtime::coarsening::wrapper,
            amgcl::runtime::relaxation::wrapper
        >,
        amgcl::solver::bicgstab<amgcl::backend::builtin<double>>
    > AMG_Solver;

    std::unique_ptr<AMG_Solver> solver_ptr;
    
    // Armazenando as opções escolhidas no construtor
    amgcl::runtime::coarsening::type c_type;
    amgcl::runtime::relaxation::type r_type;

public:
    // Construtor atualizado
    AMGcl(std::shared_ptr<const CSRMatrix> A, 
          double tol, 
          int maxiter,
          amgcl::runtime::coarsening::type coarsening = amgcl::runtime::coarsening::ruge_stuben,
          amgcl::runtime::relaxation::type relaxation = amgcl::runtime::relaxation::damped_jacobi) 
        : Solver(A, tol, maxiter), c_type(coarsening), r_type(relaxation) {}

    // Construtor vazio
    AMGcl() : Solver(), 
              c_type(amgcl::runtime::coarsening::ruge_stuben), 
              r_type(amgcl::runtime::relaxation::gauss_seidel) {}

    void setup() override {
        if (!A) { 
            std::cerr << "Error on setup AMGCL: Matrix A is null" << std::endl; 
            return; 
        }

        auto ptr_range = amgcl::make_iterator_range(A->ia, A->ia + A->n + 1);
        auto col_range = amgcl::make_iterator_range(A->ja, A->ja + A->ia[A->n]);
        auto val_range = amgcl::make_iterator_range(A->vals, A->vals + A->ia[A->n]);

        auto matrix_handle = std::tie(A->n, ptr_range, col_range, val_range);

        AMG_Solver::params prm;
        prm.solver.maxiter = this->maxiter;
        prm.solver.tol     = this->tol;
        
        // CORREÇÃO: Usando a interface Boost Property Tree e o nome correto 'relax'
        prm.precond.coarsening.put("type", c_type);
        prm.precond.relax.put("type", r_type);

        solver_ptr = std::make_unique<AMG_Solver>(matrix_handle, prm);
    }

    void solve(const std::vector<double>& b, std::vector<double>& x) override {
        if (!solver_ptr) { 
            std::cerr << "Error on solver AMGCL: Not initialized (Call setup first)" << std::endl;  
            return; 
        }

        size_t iters;
        double error;

        std::tie(iters, error) = (*solver_ptr)(b, x);

        this->stats.final_iter = iters;
        this->stats.add(static_cast<int>(iters), error);
    }
};