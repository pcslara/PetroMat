#include <complex>
#include <vector>
#include <cmath>
#include <algorithm>

#include "petromat_fft.h"


// Inversão de bits para organizar os dados antes da FFT
void bit_reverse(std::vector<Complex>& a, int n) {
    for (int i = 1, j = 0; i < n; i++) {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(a[i], a[j]);
    }
}

void fft(std::vector<Complex>& a, bool invert) {
    int n = a.size();
    bit_reverse(a, n);

    for (int len = 2; len <= n; len <<= 1) {
        double ang = 2 * PI / len * (invert ? -1 : 1);
        Complex wlen(std::cos(ang), std::sin(ang));
        for (int i = 0; i < n; i += len) {
            Complex w(1);
            for (int j = 0; j < len / 2; j++) {
                Complex u = a[i + j], v = a[i + j + len / 2] * w;
                a[i + j] = u + v;
                a[i + j + len / 2] = u - v;
                w *= wlen;
            }
        }
    }

    if (invert) {
        for (Complex& x : a) x /= n;
    }
}

void fft2d(std::vector<Complex>& data, int nx, int ny, bool invert) {
    // 1. FFT nas linhas
    for (int i = 0; i < nx; i++) {
        std::vector<Complex> row(ny);
        for (int j = 0; j < ny; j++) row[j] = data[i * ny + j];
        fft(row, invert);
        for (int j = 0; j < ny; j++) data[i * ny + j] = row[j];
    }
    // 2. FFT nas colunas
    for (int j = 0; j < ny; j++) {
        std::vector<Complex> col(nx);
        for (int i = 0; i < nx; i++) col[i] = data[i * ny + j];
        fft(col, invert);
        for (int i = 0; i < nx; i++) data[i * ny + j] = col[i];
    }
}

void fft3d(std::vector<Complex>& data, int nx, int ny, int nz, bool invert) {
    // 1. FFT em cada plano XY (isso já resolve as dimensões X e Y)
    // Tratamos o volume como nz fatias horizontais
    for (int k = 0; k < nz; k++) {
        // Offset para o início da fatia k
        int offset = k * (nx * ny);
        
        // Criamos uma visão (ou cópia) do plano 2D atual
        std::vector<Complex> plane(nx * ny);
        for (int i = 0; i < nx * ny; i++) {
            plane[i] = data[offset + i];
        }

        // Aplicamos a FFT 2D que você já tem
        fft2d(plane, nx, ny, invert);

        // Devolvemos os dados para o volume original
        for (int i = 0; i < nx * ny; i++) {
            data[offset + i] = plane[i];
        }
    }

    // 2. FFT na direção Z (as "hastes" verticais)
    // Agora fixamos (i, j) e percorremos todos os k
    for (int j = 0; j < ny; j++) {
        for (int i = 0; i < nx; i++) {
            std::vector<Complex> column_z(nz);
            
            // Coleta a haste vertical na posição (i, j)
            for (int k = 0; k < nz; k++) {
                // Indexação: k varia por último (conforme seu padrão)
                // idx = i + j*nx + k*nx*ny
                column_z[k] = data[i + j * nx + k * (nx * ny)];
            }

            // Aplica FFT 1D na haste vertical
            fft(column_z, invert);

            // Devolve os dados para o volume
            for (int k = 0; k < nz; k++) {
                data[i + j * nx + k * (nx * ny)] = column_z[k];
            }
        }
    }
}