#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "petromat_types.h"


#define IDX(i,j,nx) ((i) + (j)*(nx))


CSRMatrix csr_alloc(int n, int nnz) {
    CSRMatrix A;
    A.n = n;
    A.nnz = nnz;
    A.ia = (int *)calloc(n + 1, sizeof(int));
    A.ja = (int *)calloc(nnz, sizeof(int));
    A.vals = (double *)calloc(nnz, sizeof(double));
    return A;
}


void lap1d(int n, double coef, double *diag, double *off) {
    for (int i = 0; i < n; i++) {
        diag[i] = -2.0 * coef;
        if (i < n - 1)
            off[i] = coef;
    }
}

CSRMatrix sparse_laplacian_without_K(
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double cx, double cy, double cz
) {
    int N = nx * ny * nz;
    int max_nnz = N * 7; 
    CSRMatrix A = csr_alloc(N, max_nnz);

    int nnz = 0;
    A.ia[0] = 0;

    // Pre-calculamos os pesos para evitar divisões repetidas
    double wx = cx / (dx * dx);
    double wy = cy / (dy * dy);
    double wz = (nz > 1) ? (cz / (dz * dz)) : 0.0;

    // No MATLAB, a diagonal é SEMPRE -2 * peso em cada dimensão ativa
    double diag_fixa = -2.0 * wx - 2.0 * wy;
    if (nz > 1) diag_fixa -= 2.0 * wz;

    for (int k = 0; k < nz; k++) {
        for (int j = 0; j < ny; j++) {
            for (int i = 0; i < nx; i++) {
                int row = i + j*nx + k*nx*ny;

                // 1. Vizinho Z-
                if (nz > 1 && k > 0) {
                    A.ja[nnz] = row - nx*ny;
                    A.vals[nnz++] = wz;
                }
                // 2. Vizinho Y-
                if (j > 0) {
                    A.ja[nnz] = row - nx;
                    A.vals[nnz++] = wy;
                }
                // 3. Vizinho X-
                if (i > 0) {
                    A.ja[nnz] = row - 1;
                    A.vals[nnz++] = wx;
                }

                // 4. DIAGONAL PRINCIPAL (Sempre fixa!)
                A.ja[nnz] = row;
                A.vals[nnz++] = diag_fixa;

                // 5. Vizinho X+
                if (i < nx - 1) {
                    A.ja[nnz] = row + 1;
                    A.vals[nnz++] = wx;
                }
                // 6. Vizinho Y+
                if (j < ny - 1) {
                    A.ja[nnz] = row + nx;
                    A.vals[nnz++] = wy;
                }
                // 7. Vizinho Z+
                if (nz > 1 && k < nz - 1) {
                    A.ja[nnz] = row + nx*ny;
                    A.vals[nnz++] = wz;
                }

                A.ia[row + 1] = nnz;
            }
        }
    }
    A.nnz = nnz;
    return A;
}

CSRMatrix sparse_laplacian_without_K2(
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double cx, double cy, double cz
) {
    int N = nx * ny * nz;
    int max_nnz = N * 7; // stencil 7 pontos (3D)
    CSRMatrix A = csr_alloc(N, max_nnz);

    int nnz = 0;
    A.ia[0] = 0;

    for (int k = 0; k < nz; k++) {
        for (int j = 0; j < ny; j++) {
            for (int i = 0; i < nx; i++) {

                int row = i + j*nx + k*nx*ny;
                double diag = 0.0;

                // x-
                if (i > 0) {
                    A.ja[nnz] = row - 1;
                    A.vals[nnz++] = cx / (dx*dx);
                    diag -= cx / (dx*dx);
                }
                // x+
                if (i < nx - 1) {
                    A.ja[nnz] = row + 1;
                    A.vals[nnz++] = cx / (dx*dx);
                    diag -= cx / (dx*dx);
                }

                // y-
                if (j > 0) {
                    A.ja[nnz] = row - nx;
                    A.vals[nnz++] = cy / (dy*dy);
                    diag -= cy / (dy*dy);
                }
                // y+
                if (j < ny - 1) {
                    A.ja[nnz] = row + nx;
                    A.vals[nnz++] = cy / (dy*dy);
                    diag -= cy / (dy*dy);
                }

                // z
                if (nz > 1) {
                    if (k > 0) {
                        A.ja[nnz] = row - nx*ny;
                        A.vals[nnz++] = cz / (dz*dz);
                        diag -= cz / (dz*dz);
                    }
                    if (k < nz - 1) {
                        A.ja[nnz] = row + nx*ny;
                        A.vals[nnz++] = cz / (dz*dz);
                        diag -= cz / (dz*dz);
                    }
                }

                // diagonal
                A.ja[nnz] = row;
                A.vals[nnz++] = diag;

                A.ia[row + 1] = nnz;
            }
        }
    }

    A.nnz = nnz;
    return A;
}


CSRMatrix sparse_laplacian_with_K_Neumman(
    double *K,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double cx, double cy, double cz
) {
    int N = nx * ny * nz;
    int max_nnz = N * 7;
    CSRMatrix A = csr_alloc(N, max_nnz);

    int nnz = 0;
    A.ia[0] = 0;

    for (int k = 0; k < nz; k++) {
        for (int j = 0; j < ny; j++) {
            for (int i = 0; i < nx; i++) {

                int row = i + j*nx + k*nx*ny;
                double diag = 0.0;
                double Kc = K[IDX(i,j,nx)];

                // x-
                if (i > 0) {
                    double Km = K[IDX(i-1,j,nx)];
                    double Ke = 2*Kc*Km/(Kc+Km);
                    double v = cx * Ke / (dx*dx);
                    A.ja[nnz] = row - 1;
                    A.vals[nnz++] = -v;
                    diag += v;
                }

                // x+
                if (i < nx - 1) {
                    double Kp = K[IDX(i+1,j,nx)];
                    double Ke = 2*Kc*Kp/(Kc+Kp);
                    double v = cx * Ke / (dx*dx);
                    A.ja[nnz] = row + 1;
                    A.vals[nnz++] = -v;
                    diag += v;
                }

                // y-
                if (j > 0) {
                    double Km = K[IDX(i,j-1,nx)];
                    double Ke = 2*Kc*Km/(Kc+Km);
                    double v = cy * Ke / (dy*dy);
                    A.ja[nnz] = row - nx;
                    A.vals[nnz++] = -v;
                    diag += v;
                }

                // y+
                if (j < ny - 1) {
                    double Kp = K[IDX(i,j+1,nx)];
                    double Ke = 2*Kc*Kp/(Kc+Kp);
                    double v = cy * Ke / (dy*dy);
                    A.ja[nnz] = row + nx;
                    A.vals[nnz++] = -v;
                    diag += v;
                }

                // z
                if (nz > 1) {
                    double v = cz * Kc / (dz*dz);
                    if (k > 0) {
                        A.ja[nnz] = row - nx*ny;
                        A.vals[nnz++] = -v;
                        diag += v;
                    }
                    if (k < nz - 1) {
                        A.ja[nnz] = row + nx*ny;
                        A.vals[nnz++] = -v;
                        diag += v;
                    }
                }

                A.ja[nnz] = row;
                A.vals[nnz++] = diag;
                A.ia[row + 1] = nnz;
            }
        }
    }

    A.nnz = nnz;
    return A;
}

inline double harm(double k1, double k2) {
    if (k1 + k2 <= 1e-15) return 0.0;
    return 2.0 * k1 * k2 / (k1 + k2);
}
static inline int idx(int i,int j,int k,int nx,int ny){
    return i + j*nx + k*nx*ny;
}
// Função para média harmônica conforme o script: 2*K1*K2/(K1+K2)
static inline double harmonic(double k1, double k2) {
    if (k1 + k2 == 0) return 0;
    return (2.0 * k1 * k2) / (k1 + k2);
}

CSRMatrix sparse_laplacian_with_K(
    double *K, int nx, int ny, int nz,
    double dx, double dy, double dz,
    double cx, double cy, double cz
) {
    int nxy = nx * ny;
    int N = nxy * nz;
    CSRMatrix A;
    A.n = N;

    // Estimativa de NNZ (máximo 7 por linha para 3D)
    int max_nnz = N * 7; 
    A.ia = (int*)malloc((N + 1) * sizeof(int));
    A.ja = (int*)malloc(max_nnz * sizeof(int));
    A.vals = (double*)malloc(max_nnz * sizeof(double));

    double fac_x = cx / (dx * dx);
    double fac_y = cy / (dy * dy);
    double fac_z = cz / (dz * dz);

    int curr_nnz = 0;

    for (int k = 0; k < nz; k++) {
        for (int j = 0; j < ny; j++) {
            for (int i = 0; i < nx; i++) {
                int row_local = i + j * nx;    // Índice no plano XY (0 a nxy-1)
                int row_global = row_local + k * nxy; // Índice total (0 a N-1)
                A.ia[row_global] = curr_nnz;

                // --- Cálculo de Kx (X-interfaces) ---
                // MATLAB: Kx = fac_x * 2 * [K(1,:);K] .* [K;K(end,:)] ./ sum
                double k_this = K[i + j * nx];
                double k_prev_x = (i == 0) ? K[0 + j * nx] : K[(i - 1) + j * nx];
                double k_next_x = (i == nx - 1) ? K[(nx - 1) + j * nx] : K[(i + 1) + j * nx];

                double Kx_i   = fac_x * harmonic(k_prev_x, k_this);   // Kx(i, j)
                double Kx_i1  = fac_x * harmonic(k_this, k_next_x);  // Kx(i+1, j)

                // --- Cálculo de Ky (Y-interfaces) ---
                double k_prev_y = (j == 0) ? K[i + 0 * nx] : K[i + (j - 1) * nx];
                double k_next_y = (j == ny - 1) ? K[i + (ny - 1) * nx] : K[i + (j + 1) * nx];

                double Ky_j   = fac_y * harmonic(k_prev_y, k_this);   // Ky(i, j)
                double Ky_j1  = fac_y * harmonic(k_this, k_next_y);  // Ky(i, j+1)

                // --- Termos da Diagonal ---
                // d = -(Kx(i,j) + Kx(i+1,j)) - (Ky(i,j) + Ky(i,j+1))
                double diag = -(Kx_i + Kx_i1) - (Ky_j + Ky_j1);
                
                if (nz > 1) {
                    // O termo do kron(spdiags([1 -2 1]), spdiags(Kz))
                    // Isso adiciona -2*Kz na diagonal e 1*Kz nas vizinhanças Z
                    diag += fac_z * k_this * (-2.0);
                }

                // --- Inserção dos vizinhos (Ordenado por coluna para CSR válido) ---
                
                // Vizinho Z- (Z anterior)
                if (nz > 1 && k > 0) {
                    A.ja[curr_nnz] = row_global - nxy;
                    A.vals[curr_nnz] = -fac_z * k_this;
                    curr_nnz++;
                }

                // Vizinho Y- (j anterior)
                if (j > 0) {
                    A.ja[curr_nnz] = row_global - nx;
                    A.vals[curr_nnz] = -Ky_j; // Equivalente ao v no kron/sparse do MATLAB
                    curr_nnz++;
                }

                // Vizinho X- (i anterior)
                if (i > 0) {
                    A.ja[curr_nnz] = row_global - 1;
                    A.vals[curr_nnz] = -Kx_i;
                    curr_nnz++;
                }

                // DIAGONAL
                A.ja[curr_nnz] = row_global;
                A.vals[curr_nnz] = -diag;
                curr_nnz++;




                // Vizinho X+ (i próximo)
                if (i < nx - 1) {
                    A.ja[curr_nnz] = row_global + 1;
                    A.vals[curr_nnz] = -Kx_i1;
                    curr_nnz++;
                }

                // Vizinho Y+ (j próximo)
                if (j < ny - 1) {
                    A.ja[curr_nnz] = row_global + nx;
                    A.vals[curr_nnz] = -Ky_j1;
                    curr_nnz++;
                }

                // Vizinho Z+ (Z próximo)
                if (nz > 1 && k < nz - 1) {
                    A.ja[curr_nnz] = row_global + nxy;
                    A.vals[curr_nnz] = -fac_z * k_this;
                    curr_nnz++;
                }
            }
        }
    }
    A.ia[N] = curr_nnz;
    A.nnz = curr_nnz;
    return A;
}



CSRMatrix sparse_laplacian_with_K3d(
    double *K, int nx, int ny, int nz,
    double dx, double dy, double dz,
    double cx, double cy, double cz,
    const BoundaryConditions& bc, double *b
) {
    int nxy = nx * ny;
    int N = nxy * nz;
    CSRMatrix A;
    A.n = N;

    // Máximo de 7 vizinhos por linha para 3D
    int max_nnz = N * 7; 
    A.ia = (int*)malloc((N + 1) * sizeof(int));
    A.ja = (int*)malloc(max_nnz * sizeof(int));
    A.vals = (double*)malloc(max_nnz * sizeof(double));

    double fac_x = cx / (dx * dx);
    double fac_y = cy / (dy * dy);
    double fac_z = cz / (dz * dz);

    int curr_nnz = 0;

    for (int k = 0; k < nz; k++) {
        for (int j = 0; j < ny; j++) {
            for (int i = 0; i < nx; i++) {
                int row_global = i + j * nx + k * nxy;
                A.ia[row_global] = curr_nnz;

                double k_this = K[row_global];
                double diag_val = 0.0;

                // --- Cálculo de Transmissibilidades Internas ---
                // Para as bordas, usamos k_this como aproximação da face
                double Kx_left  = (i > 0) ? fac_x * harmonic(K[row_global - 1], k_this) : fac_x * k_this;
                double Kx_right = (i < nx - 1) ? fac_x * harmonic(k_this, K[row_global + 1]) : fac_x * k_this;
                
                double Ky_back  = (j > 0) ? fac_y * harmonic(K[row_global - nx], k_this) : fac_y * k_this;
                double Ky_front = (j < ny - 1) ? fac_y * harmonic(k_this, K[row_global + nx]) : fac_y * k_this;
                
                double Kz_down  = (nz > 1 && k > 0) ? fac_z * harmonic(K[row_global - nxy], k_this) : fac_z * k_this;
                double Kz_up    = (nz > 1 && k < nz - 1) ? fac_z * harmonic(k_this, K[row_global + nxy]) : fac_z * k_this;

                // --- Processamento Direção X ---
                if (i == 0) {
                    if (bc.xmin.type == BoundaryType::Dirichlet) {
                        diag_val += Kx_left;
                        b[row_global] += Kx_left * bc.xmin.value;
                    } else { // Neumann
                        b[row_global] -= (cx / dx) * bc.xmin.value; // Fluxo imposto
                    }
                } else { diag_val += Kx_left; }

                if (i == nx - 1) {
                    if (bc.xmax.type == BoundaryType::Dirichlet) {
                        diag_val += Kx_right;
                        b[row_global] += Kx_right * bc.xmax.value;
                    } else { // Neumann
                        b[row_global] += (cx / dx) * bc.xmax.value;
                    }
                } else { diag_val += Kx_right; }

                // --- Processamento Direção Y ---
                if (j == 0) {
                    if (bc.ymin.type == BoundaryType::Dirichlet) {
                        diag_val += Ky_back;
                        b[row_global] += Ky_back * bc.ymin.value;
                    } else {
                        b[row_global] -= (cy / dy) * bc.ymin.value;
                    }
                } else { diag_val += Ky_back; }

                if (j == ny - 1) {
                    if (bc.ymax.type == BoundaryType::Dirichlet) {
                        diag_val += Ky_front;
                        b[row_global] += Ky_front * bc.ymax.value;
                    } else {
                        b[row_global] += (cy / dy) * bc.ymax.value;
                    }
                } else { diag_val += Ky_front; }

              // --- Direção Z (Ajustada para compatibilidade com o legado) ---
                if (nz > 1) {
                    // Calculamos as transmissibilidades (Up/Down)
                    double Kz_down = (k > 0) ? fac_z * harmonic(K[row_global - nxy], k_this) : fac_z * k_this;
                    double Kz_up   = (k < nz - 1) ? fac_z * harmonic(k_this, K[row_global + nxy]) : fac_z * k_this;

                    // Diferente de X e Y, em Z o código original SEMPRE conta as duas faces na diagonal
                    diag_val += Kz_down;
                    diag_val += Kz_up;

                    // Aplicamos as condições de contorno no vetor b apenas nas faces reais
                    if (k == 0) {
                        if (bc.zmin.type == BoundaryType::Dirichlet) {
                            b[row_global] += Kz_down * bc.zmin.value;
                        } else {
                            b[row_global] -= (cz / dz) * bc.zmin.value;
                        }
                    }
                    if (k == nz - 1) {
                        if (bc.zmax.type == BoundaryType::Dirichlet) {
                            b[row_global] += Kz_up * bc.zmax.value;
                        } else {
                            b[row_global] += (cz / dz) * bc.zmax.value;
                        }
                    }
                }
                                // Vizinho Z-
                if (nz > 1 && k > 0) {
                    A.ja[curr_nnz] = row_global - nxy;
                    A.vals[curr_nnz++] = -Kz_down;
                }
                // Vizinho Y-
                if (j > 0) {
                    A.ja[curr_nnz] = row_global - nx;
                    A.vals[curr_nnz++] = -Ky_back;
                }
                // Vizinho X-
                if (i > 0) {
                    A.ja[curr_nnz] = row_global - 1;
                    A.vals[curr_nnz++] = -Kx_left;
                }

                // DIAGONAL
                A.ja[curr_nnz] = row_global;
                A.vals[curr_nnz++] = diag_val;

                // Vizinho X+
                if (i < nx - 1) {
                    A.ja[curr_nnz] = row_global + 1;
                    A.vals[curr_nnz++] = -Kx_right;
                }
                // Vizinho Y+
                if (j < ny - 1) {
                    A.ja[curr_nnz] = row_global + nx;
                    A.vals[curr_nnz++] = -Ky_front;
                }
                // Vizinho Z+
                if (nz > 1 && k < nz - 1) {
                    A.ja[curr_nnz] = row_global + nxy;
                    A.vals[curr_nnz++] = -Kz_up;
                }
            }
        }
    }
    A.ia[N] = curr_nnz;
    A.nnz = curr_nnz;
    return A;
}

CSRMatrix sparse_laplacian_with_K(
    double *K2D, int nx, int ny, int nz,
    double dx, double dy, double dz,
    double cx, double cy, double cz,
    const BoundaryConditions& bc, double *b
) {
    int nxy = nx * ny;
    int N = nxy * nz;
    CSRMatrix A;
    A.n = N;
    A.ia = (int*)malloc((N + 1) * sizeof(int));
    A.ja = (int*)malloc(N * 7 * sizeof(int));
    A.vals = (double*)malloc(N * 7 * sizeof(double));

    double fac_x = cx / (dx * dx);
    double fac_y = cy / (dy * dy);
    double fac_z = cz / (dz * dz);
    int curr_nnz = 0;

    for (int k = 0; k < nz; k++) {
        for (int j = 0; j < ny; j++) {
            for (int i = 0; i < nx; i++) {
                int row_2d = i + j * nx;
                int row_global = row_2d + k * nxy;
                A.ia[row_global] = curr_nnz;

                double k_this = K2D[row_2d];
                double diag_val = 0.0;

                // --- DIREÇÕES X e Y (Média Harmônica no Plano) ---
                double Kx_l = (i > 0) ? fac_x * harmonic(K2D[row_2d - 1], k_this) : fac_x * k_this;
                double Kx_r = (i < nx-1) ? fac_x * harmonic(k_this, K2D[row_2d + 1]) : fac_x * k_this;
                double Ky_b = (j > 0) ? fac_y * harmonic(K2D[row_2d - nx], k_this) : fac_y * k_this;
                double Ky_f = (j < ny-1) ? fac_y * harmonic(k_this, K2D[row_2d + nx]) : fac_y * k_this;

                // Processamento de bordas X/Y e Diagonal (conforme fizemos antes)
                if (i == 0) { 
                    diag_val += Kx_l; 
                    if (bc.xmin.type == BoundaryType::Dirichlet) b[row_global] += Kx_l * bc.xmin.value;
                    else b[row_global] -= (cx/dx) * bc.xmin.value;
                } else diag_val += Kx_l;

                if (i == nx-1) {
                    diag_val += Kx_r;
                    if (bc.xmax.type == BoundaryType::Dirichlet) b[row_global] += Kx_r * bc.xmax.value;
                    else b[row_global] += (cx/dx) * bc.xmax.value;
                } else diag_val += Kx_r;

                if (j == 0) {
                    diag_val += Ky_b;
                    if (bc.ymin.type == BoundaryType::Dirichlet) b[row_global] += Ky_b * bc.ymin.value;
                    else b[row_global] -= (cy/dy) * bc.ymin.value;
                } else diag_val += Ky_b;

                if (j == ny-1) {
                    diag_val += Ky_f;
                    if (bc.ymax.type == BoundaryType::Dirichlet) b[row_global] += Ky_f * bc.ymax.value;
                    else b[row_global] += (cy/dy) * bc.ymax.value;
                } else diag_val += Ky_f;

                // --- DIREÇÃO Z (Lógica MATLAB: Kz = fac_z * K) ---
                if (nz > 1) {
                    double Kz_val = fac_z * k_this;
                    diag_val += 2.0 * Kz_val; // spdiags de -2

                    if (k == 0) {
                        if (bc.zmin.type == BoundaryType::Dirichlet) b[row_global] += Kz_val * bc.zmin.value;
                        else b[row_global] -= (cz/dz) * bc.zmin.value;
                    }
                    if (k == nz-1) {
                        if (bc.zmax.type == BoundaryType::Dirichlet) b[row_global] += Kz_val * bc.zmax.value;
                        else b[row_global] += (cz/dz) * bc.zmax.value;
                    }
                }

                // --- Inserção CSR (Vizinhos) ---
                if (nz > 1 && k > 0) { A.ja[curr_nnz] = row_global - nxy; A.vals[curr_nnz++] = -fac_z * k_this; }
                if (j > 0) { A.ja[curr_nnz] = row_global - nx; A.vals[curr_nnz++] = -Ky_b; }
                if (i > 0) { A.ja[curr_nnz] = row_global - 1; A.vals[curr_nnz++] = -Kx_l; }
                
                A.ja[curr_nnz] = row_global; A.vals[curr_nnz++] = diag_val;

                if (i < nx - 1) { A.ja[curr_nnz] = row_global + 1; A.vals[curr_nnz++] = -Kx_r; }
                if (j < ny - 1) { A.ja[curr_nnz] = row_global + nx; A.vals[curr_nnz++] = -Ky_f; }
                if (nz > 1 && k < nz - 1) { A.ja[curr_nnz] = row_global + nxy; A.vals[curr_nnz++] = -fac_z * k_this; }
            }
        }
    }
    A.ia[N] = curr_nnz;
    A.nnz   = curr_nnz;
    return A;
}

CSRMatrix sparse_laplacian_with_K3D(
    double *K3D, int nx, int ny, int nz,
    double dx, double dy, double dz,
    double cx, double cy, double cz, // cx=kx, cy=ky, cz=kz
    const BoundaryConditions& bc, double *b
) {
    int nxy = nx * ny;
    int N = nxy * nz;
    CSRMatrix A;
    A.n = N;
    A.ia = (int*)malloc((N + 1) * sizeof(int));
    A.ja = (int*)malloc(N * 7 * sizeof(int));
    A.vals = (double*)malloc(N * 7 * sizeof(double));

    double geom_x = 1.0 / (dx * dx);
    double geom_y = 1.0 / (dy * dy);
    double geom_z = 1.0 / (dz * dz);
    
    int curr_nnz = 0;

    for (int k = 0; k < nz; k++) {
        for (int j = 0; j < ny; j++) {
            for (int i = 0; i < nx; i++) {
                int row_global = i + j * nx + k * nxy;
                A.ia[row_global] = curr_nnz;

                double m_this = K3D[row_global];
                double diag_val = 0.0;

                // --- CÁLCULO DAS TRANSMISSIBILIDADES ---
                double k_this_x = cx * m_this;
                double Kx_l = (i > 0) ? geom_x * harmonic(cx * K3D[row_global - 1], k_this_x) : geom_x * k_this_x;
                double Kx_r = (i < nx - 1) ? geom_x * harmonic(k_this_x, cx * K3D[row_global + 1]) : geom_x * k_this_x;

                double k_this_y = cy * m_this;
                double Ky_b = (j > 0) ? geom_y * harmonic(cy * K3D[row_global - nx], k_this_y) : geom_y * k_this_y;
                double Ky_f = (j < ny - 1) ? geom_y * harmonic(k_this_y, cy * K3D[row_global + nx]) : geom_y * k_this_y;

                double Kz_down = 0.0, Kz_up = 0.0;
                if (nz > 1) {
                    double k_this_z = cz * m_this;
                    Kz_down = (k > 0) ? geom_z * harmonic(cz * K3D[row_global - nxy], k_this_z) : geom_z * k_this_z;
                    Kz_up   = (k < nz - 1) ? geom_z * harmonic(k_this_z, cz * K3D[row_global + nxy]) : geom_z * k_this_z;
                }

                // --- MONTAGEM DA DIAGONAL E VETOR B (LÓGICA DE BORDA) ---
                
                // Direção X
                if (i > 0) diag_val += Kx_l; 
                else { // Borda i == 0
                    if (bc.xmin.type == BoundaryType::Dirichlet) {
                        diag_val += Kx_l; b[row_global] += Kx_l * bc.xmin.value;
                    } else b[row_global] -= (cx * m_this / dx) * bc.xmin.value;
                }
                if (i < nx - 1) diag_val += Kx_r;
                else { // Borda i == nx - 1
                    if (bc.xmax.type == BoundaryType::Dirichlet) {
                        diag_val += Kx_r; b[row_global] += Kx_r * bc.xmax.value;
                    } else b[row_global] += (cx * m_this / dx) * bc.xmax.value;
                }

                // Direção Y
                if (j > 0) diag_val += Ky_b;
                else { // Borda j == 0
                    if (bc.ymin.type == BoundaryType::Dirichlet) {
                        diag_val += Ky_b; b[row_global] += Ky_b * bc.ymin.value;
                    } else b[row_global] -= (cy * m_this / dy) * bc.ymin.value;
                }
                if (j < ny - 1) diag_val += Ky_f;
                else { // Borda j == ny - 1
                    if (bc.ymax.type == BoundaryType::Dirichlet) {
                        diag_val += Ky_f; b[row_global] += Ky_f * bc.ymax.value;
                    } else b[row_global] += (cy * m_this / dy) * bc.ymax.value;
                }

                // Direção Z
                if (nz > 1) {
                    if (k > 0) diag_val += Kz_down;
                    else { // Borda k == 0
                        if (bc.zmin.type == BoundaryType::Dirichlet) {
                            diag_val += Kz_down; b[row_global] += Kz_down * bc.zmin.value;
                        } else b[row_global] -= (cz * m_this / dz) * bc.zmin.value;
                    }
                    if (k < nz - 1) diag_val += Kz_up;
                    else { // Borda k == nz - 1
                        if (bc.zmax.type == BoundaryType::Dirichlet) {
                            diag_val += Kz_up; b[row_global] += Kz_up * bc.zmax.value;
                        } else b[row_global] += (cz * m_this / dz) * bc.zmax.value;
                    }
                }

                // --- INSERÇÃO NO FORMATO CSR (ORDEM CRESCENTE DE COLUNAS) ---
                if (nz > 1 && k > 0) { A.ja[curr_nnz] = row_global - nxy; A.vals[curr_nnz++] = -Kz_down; }
                if (j > 0) { A.ja[curr_nnz] = row_global - nx; A.vals[curr_nnz++] = -Ky_b; }
                if (i > 0) { A.ja[curr_nnz] = row_global - 1; A.vals[curr_nnz++] = -Kx_l; }
                
                A.ja[curr_nnz] = row_global; A.vals[curr_nnz++] = diag_val; // Diagonal Principal

                if (i < nx - 1) { A.ja[curr_nnz] = row_global + 1; A.vals[curr_nnz++] = -Kx_r; }
                if (j < ny - 1) { A.ja[curr_nnz] = row_global + nx; A.vals[curr_nnz++] = -Ky_f; }
                if (nz > 1 && k < nz - 1) { A.ja[curr_nnz] = row_global + nxy; A.vals[curr_nnz++] = -Kz_up; }
            }
        }
    }
    A.ia[N] = curr_nnz;
    A.nnz = curr_nnz;
    return A;
}

#if 0
/**
 * Adds a Peaceman Well to the system: A[idx][idx] += WI and b[idx] += WI * BHP
 * @param A The CSR matrix (must be already assembled)
 * @param b The RHS vector (size n)
 * @param well The well structure containing index and properties
 */
void add_well_to_matrix(CSRMatrix *A, double *b, Well well) {
    int row = well.cell_idx;
    
    // 1. Find the diagonal element in the CSR row
    int found = 0;
    for (int k = A->ia[row]; k < A->ia[row + 1]; k++) {
        if (A->ja[k] == row) {
            // Found the diagonal!
            A->vals[k] += well.WI;
            found = 1;
            break;
        }
    }

    // 2. Update the Right-Hand Side (RHS)
    if (found) {
        b[row] += well.WI * well.BHP;
    } else {
        fprintf(stderr, "[ERROR] Diagonal not found for cell %d. Well not added.\n", row);
    }
}

#endif