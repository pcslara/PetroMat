#pragma once

#include <complex>
#include <vector>
#include <cmath>
#include <algorithm>

const double PI = std::acos(-1.0);
typedef std::complex<double> Complex;


// Inversão de bits para organizar os dados antes da FFT
void bit_reverse(std::vector<Complex>& a, int n) ;

void fft(std::vector<Complex>& a, bool invert);
void fft2d(std::vector<Complex>& data, int nx, int ny, bool invert);
void fft3d(std::vector<Complex>& data, int nx, int ny, int nz, bool invert);