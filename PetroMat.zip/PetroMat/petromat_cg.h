#ifndef PETROMAT_CG_H
#define PETROMAT_CG_H
#include <math.h>
#include <vector>
#include <iostream>

#include "petromat_solver.h"
#include "petromat_types.h"

void spmv_csr(const CSRMatrix *A, const double *x, double *y);
void solve_cg_basic(const CSRMatrix *A, const double *b, double *x, double tol, int max_iter);
void solve_pcg_ilu0(const CSRMatrix *A, const double *b, double *x, double tol, int max_iter);
void solve_pcg_ic0(const CSRMatrix *A, const double *b, double *x, double tol, int max_iter);


class CG : public Solver {

public:
    using Solver::Solver;
    

    virtual void setup()  override {
        C->setup( *A );
    }
   void solve(const std::vector<double> &b, std::vector<double> &x) override {
    const int n = A->n;
    stats.clear();

    // Pré-alocação de vetores (idealmente feita no setup(), mas mantida aqui para clareza)
    std::vector<double> r(n), Ap(n), z(n), p(n);

    // 1. Cálculo da norma inicial de b (para resíduo relativo)
    double b_norm_sq = 0.0;
    for (int i = 0; i < n; i++) b_norm_sq += b[i] * b[i];
    double b_norm = (b_norm_sq > 0) ? sqrt(b_norm_sq) : 1.0;

    // 2. r = b - A * x
    double r_sq_norm = 0.0;
    spmv_csr(A.get(), x.data(), Ap.data());
    for (int i = 0; i < n; i++){ 
        r[i] = b[i] - Ap[i];
        r_sq_norm += r[i] * r[i];
    }
    double rsold = 0.0;
    //printf("TOL %.4g\n", tol );
    
    /*for (int i = 0; i < r.size(); i++) {
        if (!std::isfinite(r[i])) {
            std::cout << "[FATAL] r[" << i << "] = NaN antes do precond\n";
            break;
        }
    }*/
    const double rel_res = sqrt(r_sq_norm) / b_norm;
    stats.add(0, rel_res);
    if (C) {
        C->apply(r, z);
        for (int i = 0; i < n; i++) {
            rsold += r[i] * z[i];
            p[i] = z[i];
        }
    } else {
        for (int i = 0; i < n; i++) {
            rsold += r[i] * r[i];
            p[i] = r[i];
        }
    }

    for (int iter = 0; iter < maxiter; iter++) {

        


        // 4. Ap = A * p
        spmv_csr(A.get(), p.data(), Ap.data());

        // 5. pAp = p' * Ap
        double pAp = 0.0;
        for (int i = 0; i < n; i++) pAp += p[i] * Ap[i];
        
        const double alpha = rsold / pAp;

        // 6. Atualização de x e r (Loop Fusion)
        double r_sq_norm = 0.0; 
        for (int i = 0; i < n; i++) {
            x[i] += alpha * p[i];
            r[i] -= alpha * Ap[i];
            r_sq_norm += r[i] * r[i];
        }

        if( x_ref ) {
            if( iter < 3 || iter % stats.inter_error_freq == 0 )
                stats.addIterError(x, *x_ref, iter );
        }


        const double rel_res = sqrt(r_sq_norm) / b_norm;
        stats.add(iter+1, rel_res);
        

        if (rel_res < tol) {
            if( verbose )
                printf("Convergência: Iter %d | Res: %e\n", iter, rel_res);
            if( x_ref )
                stats.addIterError(x, *x_ref, iter );
            break;
        }

        // 7. Pré-condicionador e novo rs (rsnew)
        double rsnew = 0.0;
       
        /*for (int i = 0; i < r.size(); i++) {
            if (!std::isfinite(r[i])) {
                std::cout << "[FATAL] r[" << i << "] = NaN antes do precond\n";
                break;
            }
        }*/

   
        
        if (C) {
            C->apply(r, z);
            for (int i = 0; i < n; i++) rsnew += r[i] * z[i];
        } else {
            rsnew = r_sq_norm;
        }

        const double beta = rsnew / rsold;
        
        if (C) {
            for (int i = 0; i < n; i++) p[i] = z[i] + beta * p[i];
        } else {
            for (int i = 0; i < n; i++) p[i] = r[i] + beta * p[i];
        }

        rsold = rsnew;

    }
}

};

class BiCGStab : public Solver {

public:
    using Solver::Solver;

    virtual void setup() override {
        if (C) {
            C->setup(*A);
        }
    }

    void solve(const std::vector<double> &b, std::vector<double> &x) override {
        const int n = A->n;
        stats.clear();

        // Pré-alocação de vetores do BiCGStab
        std::vector<double> r(n), r_tld(n), p(n), p_hat(n), v(n), s(n), s_hat(n), t(n);

        // 1. Cálculo da norma inicial de b (para resíduo relativo)
        double b_norm_sq = 0.0;
        for (int i = 0; i < n; i++) b_norm_sq += b[i] * b[i];
        double b_norm = (b_norm_sq > 0) ? sqrt(b_norm_sq) : 1.0;

        // 2. r = b - A * x
        double r_sq_norm = 0.0;
        spmv_csr(A.get(), x.data(), t.data()); // Usa 't' temporariamente como 'Ax'
        for (int i = 0; i < n; i++) {
            r[i] = b[i] - t[i];
            r_tld[i] = r[i]; // r_tld (r estrela) é escolhido como o r_0
            r_sq_norm += r[i] * r[i];
        }

        double rel_res = sqrt(r_sq_norm) / b_norm;
        stats.add(0, rel_res);

        if (rel_res < tol) {
            stats.final_iter = 1;
            stats.status = CONVERGED;
            if (verbose) printf("Convergência inicial atingida.\n");
            return;
        }

        // Variáveis escalares do algoritmo
        double rho = 1.0, rho_1 = 1.0;
        double alpha = 1.0, beta = 0.0, omega = 1.0;

        for (int iter = 0; iter < maxiter; iter++) {
            
            // 3. rho = (r_tld, r)
            rho = 0.0;
            for (int i = 0; i < n; i++) rho += r_tld[i] * r[i];

            if (rho == 0.0) {
                if (verbose) printf("Breakdown: rho = 0 na iteração %d\n", iter);
                break;
            }

            // 4. Cálculo da direção p
            if (iter == 0) {
                for (int i = 0; i < n; i++) p[i] = r[i];
            } else {
                beta = (rho / rho_1) * (alpha / omega);
                for (int i = 0; i < n; i++) {
                    p[i] = r[i] + beta * (p[i] - omega * v[i]);
                }
            }

            // 5. Pré-condicionador em p -> p_hat
            if (C) {
                C->apply(p, p_hat);
            } else {
                for (int i = 0; i < n; i++) p_hat[i] = p[i];
            }

            // 6. v = A * p_hat
            spmv_csr(A.get(), p_hat.data(), v.data());

            // 7. alpha = rho / (r_tld, v)
            double rtld_v = 0.0;
            for (int i = 0; i < n; i++) rtld_v += r_tld[i] * v[i];
            alpha = rho / rtld_v;

            // 8. s = r - alpha * v
            for (int i = 0; i < n; i++) s[i] = r[i] - alpha * v[i];

            // 9. Pré-condicionador em s -> s_hat
            if (C) {
                C->apply(s, s_hat);
            } else {
                for (int i = 0; i < n; i++) s_hat[i] = s[i];
            }

            // 10. t = A * s_hat
            spmv_csr(A.get(), s_hat.data(), t.data());

            // 11. omega = (t, s) / (t, t)
            double ts = 0.0, tt = 0.0;
            for (int i = 0; i < n; i++) {
                ts += t[i] * s[i];
                tt += t[i] * t[i];
            }
            omega = (tt != 0.0) ? (ts / tt) : 0.0;

            if (omega == 0.0) {
                if (verbose) printf("Breakdown: omega = 0 na iteração %d\n", iter);
                break;
            }

            // 12. Atualização de x e r (Loop Fusion)
            r_sq_norm = 0.0;
            for (int i = 0; i < n; i++) {
                x[i] += alpha * p_hat[i] + omega * s_hat[i];
                r[i] = s[i] - omega * t[i];
                r_sq_norm += r[i] * r[i];
            }

            // 13. Verificação de convergência e estatísticas
            rho_1 = rho;
            rel_res = sqrt(r_sq_norm) / b_norm;
            stats.add(iter + 1, rel_res);

            if (x_ref) {
                if (iter < 3 || iter % stats.inter_error_freq == 0)
                    stats.addIterError(x, *x_ref, iter);
            }

            if (rel_res < tol) {
                stats.final_iter = iter + 1;
                stats.status = CONVERGED;
                if (verbose)
                    printf("Convergência: Iter %d | Res: %e\n", iter + 1, rel_res);
                if (x_ref)
                    stats.addIterError(x, *x_ref, iter + 1);
                break;
            }

            if( iter - 1 == maxiter ) {
                stats.final_iter = iter + 1;
                stats.status = MAXITERREACH;
            }
        }
    }
};
#endif