#include <stdio.h>
#include <stdlib.h>
#include <math.h>


#include "petromat_types.h"
#include "petromat_ilu.h"
#include "petromat_ic.h"
#include "petromat_utils.h"


// 1. Multiplicação Matriz-Vetor para CSR
void spmv_csr(const CSRMatrix *A, const double *x, double *y) {
    #pragma omp parallel for
    for (int i = 0; i < A->n; i++) {
        double sum = 0.0;
        for (int k = A->ia[i]; k < A->ia[i+1]; k++) {
            sum += A->vals[k] * x[A->ja[k]];
        }
        y[i] = sum;
    }
}
// 2. Solver Conjugate Gradient
void solve_cg_basic(const CSRMatrix *A, const double *b, double *x, double tol, int max_iter) {
    int n = A->n;
    double *r = (double *)malloc(n * sizeof(double));
    double *p = (double *)malloc(n * sizeof(double));
    double *Ap = (double *)malloc(n * sizeof(double));
    
    printf("System %dx%d NNZ = %d\n", A->n, A->n, A->nnz );
    double rsold, alpha, rsnew;
    FILE * fileStat = fopen("solverstat_cg.dat", "w");

    // r = b - A * x
    spmv_csr(A, x, Ap);
    for (int i = 0; i < n; i++) {
        r[i] = b[i] - Ap[i];
        p[i] = r[i];
    }

    // rsold = r' * r
    rsold = 0.0;
    for (int i = 0; i < n; i++) rsold += r[i] * r[i];

    for (int iter = 0; iter < max_iter; iter++) {
        // Ap = A * p
        spmv_csr(A, p, Ap);

        // alpha = rsold / (p' * Ap)
        double pAp = 0.0;
        for (int i = 0; i < n; i++) pAp += p[i] * Ap[i];
        
        alpha = rsold / pAp;

        // x = x + alpha * p
        // r = r - alpha * Ap
        rsnew = 0.0;
        for (int i = 0; i < n; i++) {
            x[i] += alpha * p[i];
            r[i] -= alpha * Ap[i];
            rsnew += r[i] * r[i];
        }

        if (sqrt(rsnew) < tol) {
            printf("CG convergindo em %d iteracoes. Residuo: %e\n", iter, sqrt(rsnew));
            break;
        }

        // p = r + (rsnew / rsold) * p
        double beta = rsnew / rsold;
        for (int i = 0; i < n; i++) {
            p[i] = r[i] + beta * p[i];
        }
        rsold = rsnew;

        if (iter % 10 == 0) printf("Iter %d, Residuo: %e\n", iter, sqrt(rsold));
        fprintf(fileStat, "%d %e\n",  iter, sqrt(rsold));
    }

    free(r); free(p); free(Ap);
}


void solve_pcg_ic0(const CSRMatrix *A, const double *b, double *x, double tol, int max_iter) {
    int n = A->n;
    double *r =(double *) malloc(n * sizeof(double));
    double *z = (double *)malloc(n * sizeof(double)); // Vetor do precondicionador
    double *p = (double *)malloc(n * sizeof(double));
    double *Ap =(double *) malloc(n * sizeof(double));
    double *y_tmp =(double *) malloc(n * sizeof(double)); // Auxiliar para subs. triangular
    
    double *l_vals =(double *) malloc(A->nnz * sizeof(double));

    ic0_decomposition(A, l_vals);

    FILE * fileStat = fopen("solverstat_pcg.dat", "w");

    double alpha, beta, rho_old, rho_new;

    // r = b - A * x
    spmv_csr(A, x, Ap);
    for (int i = 0; i < n; i++) r[i] = b[i] - Ap[i];

    for (int iter = 0; iter < max_iter; iter++) {

        // 2. Aplicar Precondicionador: Mz = r (L U z = r)
        ic0_forward_substitution(A, l_vals, r, y_tmp);  // Ly = r
        ic0_backward_substitution(A, l_vals, y_tmp, z); // Uz = y

        // rho = r' * z
        rho_new = 0.0;
        for (int i = 0; i < n; i++) rho_new += r[i] * z[i];

        if (iter == 0) {
            for (int i = 0; i < n; i++) p[i] = z[i];
        } else {
            beta = rho_new / rho_old;
            for (int i = 0; i < n; i++) p[i] = z[i] + beta * p[i];
        }

        // Ap = A * p
        spmv_csr(A, p, Ap);

        // alpha = rho_new / (p' * Ap)
        double pAp = 0.0;
        #pragma omp parallel for reduction(+:pAp)
        for (int i = 0; i < n; i++) pAp += p[i] * Ap[i];
        alpha = rho_new / pAp;

        // x = x + alpha * p
        // r = r - alpha * Ap
        double residual_norm = 0.0;
        #pragma omp parallel for reduction(+:residual_norm)
        for (int i = 0; i < n; i++) {
            x[i] += alpha * p[i];
            r[i] -= alpha * Ap[i];
            residual_norm += r[i] * r[i];
        }

        residual_norm = sqrt(residual_norm);
        
        
        if (residual_norm < tol  ) {
            printf("PCG convergido em %d iterações. Resíduo: %e\n", iter, residual_norm);
            break;
        }

        rho_old = rho_new;
        if( iter % 10 == 0 )
            printf("Iter %d, Resíduo: %e\n", iter, residual_norm);
        fprintf(fileStat, "%d %e\n",  iter, residual_norm);
    }
    fclose(fileStat );
    free(r); free(z); free(p); free(Ap); free(y_tmp); free(l_vals);
}



