#pragma once

#include <cstdio>
#include <vector>
#include <string>
#include <memory>
#include <fstream>
#include <stdexcept>
#include <iostream>
#include "fkYAML/node.hpp"

// Incluímos a configuração completa. Nenhuma struct é redefinida aqui!
#include "petromat_coarse.h"
#include "petromat_config.h"
#include "petromat_jacobi.h"

// Protótipos necessários para recursão mútua do parser
inline void from_node(const fkyaml::node& node, std::shared_ptr<PrecondConfig>& pconf);
inline void from_node(const fkyaml::node& node, SolverConfig& sconf);

inline void from_node(const fkyaml::node& node, BoundaryCondition& bc) {
    std::string type = node["type"].get_value<std::string>();
    bc.type = (type == "dirichlet") ? BoundaryType::Dirichlet : BoundaryType::Neumann;
    bc.value = node["value"].get_value<double>();
}

inline void from_node(const fkyaml::node& node, BoundaryConditions& bcs) {
    from_node(node["xmin"], bcs.xmin);
    from_node(node["xmax"], bcs.xmax);
    from_node(node["ymin"], bcs.ymin);
    from_node(node["ymax"], bcs.ymax);
    from_node(node["zmin"], bcs.zmin);
    from_node(node["zmax"], bcs.zmax);
}

inline void from_node(const fkyaml::node& node, std::shared_ptr<CoarseningConfig>& pconf) {
    if (node.is_null()) { pconf = nullptr; return; }
    std::string type = node["type"].get_value<std::string>();
   
    if (type == "rs") {
        auto agg = std::make_shared<RSCoaseninConfig>();
        agg->theta = node["theta"].get_value_or<double>(0.25);
        agg->truncFactor = node["trunc"].get_value_or<double>(0.25);
        pconf = agg;
    } else if (type == "clpj") {
        auto agg = std::make_shared<CLPJCoaseninConfig>();
        agg->theta = node["theta"].get_value_or<double>(0.25);
        agg->truncFactor = node["trunc"].get_value_or<double>(0.25);
        pconf = agg;
    } else if (type == "bfs") {
        auto agg = std::make_shared<BFSAggregationConfig>();
        agg->coarse_ratio = node["coarse_ratio"].get_value_or<int>(32);
        agg->theta = node["theta"].get_value_or<double>(0.25);
        agg->smooth = node["smooth"].get_value_or<bool>(false);
        pconf = agg;
    } else if (type == "vanek") {
        auto agg = std::make_shared<VanekConfig>();
        agg->eps = node["eps"].get_value_or<double>(0.02);
        agg->smooth = node["smooth"].get_value_or<bool>(false);
        pconf = agg;
    } else if (type == "plain") {
        auto agg = std::make_shared<PlainAggregationConfig>();
        agg->eps = node["eps"].get_value_or<double>(0.02);
        agg->smooth = node["smooth"].get_value_or<bool>(false);
        pconf = agg;
    } else if (type == "sa") {
        auto agg = std::make_shared<SmootherAggregationConfig>();
        agg->eps = node["eps"].get_value_or<double>(0.02);
        pconf = agg;
    }
}

inline void from_node(const fkyaml::node& node, std::shared_ptr<PrecondConfig>& pconf) {
    if (node.is_null()) { pconf = nullptr; return; }
    std::string type = node["type"].get_value<std::string>();

    if (type == "IC") {
        auto ic = std::make_shared<ICConfig>();
        ic->level = node["level"].get_value_or<int>(0);
        pconf = ic;
    } else if (type == "coarse") {
        auto coarse = std::make_shared<CoarseConfig>();
        coarse->coarseRatio = node["coarse_ratio"].get_value_or<int>(10);
        coarse->coarseSize = node["coarse_size"].get_value_or<int>(-1);
        if (node.contains("internal_solver")) {
            coarse->internalSolver = std::make_shared<SolverConfig>();
            from_node(node["internal_solver"], *(coarse->internalSolver));
        }
        pconf = coarse;
    } else if (type == "multilevel_coarse") {
        auto ml_conf = std::make_shared<MultilevelCoarseConfig>();
        ml_conf->max_levels = node["max_levels"].get_value_or<int>(3);
        ml_conf->pre_relax_sweeps = node["pre_relax_sweeps"].get_value_or<int>(2);
        ml_conf->pos_relax_sweeps = node["pos_relax_sweeps"].get_value_or<int>(2);
        
        ml_conf->pre_relax_sweeps_l0 = node["pre_relax_sweeps_l0"].get_value_or<int>(2);
        ml_conf->pos_relax_sweeps_l0 = node["pos_relax_sweeps_l0"].get_value_or<int>(2);
        ml_conf->bottom_solver_dimension = node["bottom_solver_dimension"].get_value_or<int>(1000);
        auto cycleStr = node["cycle"].get_value_or<std::string>("V");
        ml_conf->levelFactor = node["level_factor"].get_value_or<double>( 1.25 );

        if( cycleStr == "F" ) {
            ml_conf->cycleType = CycleType::F_CYCLE;
        } else if( cycleStr == "V" ) {
            ml_conf->cycleType = CycleType::V_CYCLE;
        } else if( cycleStr == "W" ) {
            ml_conf->cycleType = CycleType::W_CYCLE;
        } else if( cycleStr == "K" ) {
            ml_conf->cycleType = CycleType::K_CYCLE;
        } else {
            throw std::runtime_error("AMG cycle error: type:" + cycleStr );
        }
        
        if (node.contains("bottom_solver")) {
            ml_conf->bottom_solver = std::make_shared<SolverConfig>();
            from_node(node["bottom_solver"], *(ml_conf->bottom_solver));
        } else {
            throw std::runtime_error("Parser: 'multilevel_coarse' requer a definicao de um 'bottom_solver'.");
        }

        if (node.contains("smoother")) from_node(node["smoother"], ml_conf->smoother);
        if (node.contains("coarsening")) from_node(node["coarsening"], ml_conf->coarsening);

        pconf = ml_conf;
    } else if (type == "jacobi") {
        auto jacobi = std::make_shared<JacobiConfig>();
        jacobi->omega = node["omega"].get_value_or<double>(1.0);
        pconf = jacobi;
    } else if (type == "l1jacobi") {
        auto jacobi = std::make_shared<L1JacobiConfig>();
        pconf = jacobi;
    } else if (type == "cheb") {
        auto cheb = std::make_shared<ChebyshevConfig>();
        pconf = cheb;
    } else if (type == "gs") {
        auto gs = std::make_shared<GSConfig>();
        gs->omega = node["omega"].get_value_or<double>(1.0);
        pconf = gs;
    }   else if (type == "spai0") {
        auto spai = std::make_shared<SPAIConfig>();
        spai->omega = node["omega"].get_value_or<double>(1.0);
        spai->level = 0;
        pconf = spai;
    }  else if (type == "spai1") {
        auto spai = std::make_shared<SPAIConfig>();
        spai->level = 1;
        pconf = spai;
    } else if (type == "composite") {
        auto comp = std::make_shared<CompositeConfig>();
        if (node.contains("components") && node["components"].is_sequence()) {
            for (const auto& item : node["components"]) {
                std::shared_ptr<PrecondConfig> child;
                from_node(item, child);
                comp->components.push_back(child);
            }
        }
        pconf = comp;
    } else {
        throw std::runtime_error("Precond error: type:" + type );
    }
}

inline void from_node(const fkyaml::node& node, SolverConfig& sconf) {
    if (!node.is_mapping()) {
        throw std::runtime_error("Parser: O solver deve ser um mapa de chaves/valores.");
    }
    if (!node.contains("type")) {
        throw std::runtime_error("Parser: A chave 'type' é obrigatória na configuração do solver.");
    }
    static int solver_anon_counter = 0;
    sconf.id = node.contains("id") ? node["id"].get_value<std::string>() : "solver_anon_" + std::to_string(++solver_anon_counter);
    sconf.type = node["type"].get_value<std::string>();
    sconf.tol = node.contains("tol") ? node["tol"].get_value<double>() : 1e-6;
    sconf.maxiter = node.contains("maxiter") ? node["maxiter"].get_value<int>() : 1000;
    
    if (node.contains("precond") && !node["precond"].is_null()) {
        from_node(node["precond"], sconf.precond);
    }
}

inline void from_node(const fkyaml::node& node, ReservoirModel& model) {
    if (node.contains("input_matrix")) {
        model.input_matrix = node["input_matrix"].get_value<std::string>();
    }

    if (node.contains("input_rhs")) {
        model.input_rhs = node["input_rhs"].get_value<std::string>();
    }
    if (node.contains("nthreads")) {
        model.nThreads = node["nthreads"].get_value<int>();
    }
    if (node.contains("grid")) {
        model.grid.nx = node["grid"]["nx"].get_value<int>();
        model.grid.ny = node["grid"]["ny"].get_value<int>();
        model.grid.nz = node["grid"]["nz"].get_value<int>();
    }
    if (node.contains("domain")) {
        model.domain.lx = node["domain"]["lx"].get_value<double>();
        model.domain.ly = node["domain"]["ly"].get_value<double>();
        model.domain.lz = node["domain"]["lz"].get_value<double>();
    }

    auto& p_node = node.contains("permeability") ? node["permeability"] : node["Permeability"];
    if (!p_node.is_null()) {
        model.permeability.kx = p_node["kx"].get_value_or<double>(1.0);
        model.permeability.ky = p_node["ky"].get_value_or<double>(1.0);
        model.permeability.kz = p_node["kz"].get_value_or<double>(1.0);
        model.permeability.kmin = p_node["kmin"].get_value_or<double>(0.0);
        model.permeability.kmax = p_node["kmax"].get_value_or<double>(1.0);
        model.permeability.range = p_node["range"].get_value_or<double>(1.0);
        model.permeability.smoothness = p_node["smoothness"].get_value_or<double>(0.5);
        model.permeability.perm_field = p_node["perm_field"].get_value_or<std::string>("");
        
        for (int i = 0; i < 3; ++i) model.permeability.sigma[i] = p_node["sigma"][i].get_value<double>();
        for (int i = 0; i < 3; ++i) 
            for (int j = 0; j < 3; ++j)
                model.permeability.R[i][j] = p_node["R"][i][j].get_value<double>();
    }

    if (node.contains("boundary_conditions")) {
        from_node(node["boundary_conditions"], model.boundary_conditions);
    }

    model.solvers.clear(); 
    if (node.contains("solvers") && node["solvers"].is_sequence()) {
        for (const auto& s_node : node["solvers"]) {
            auto sconf = std::make_shared<SolverConfig>();
            from_node(s_node, *sconf);
            model.solvers.push_back(sconf);
        }
    }

    if (node.contains("reference_solution")) {
        model.reference_solver = std::make_shared<SolverConfig>();
        from_node(node["reference_solution"], *model.reference_solver);
    }
}

inline ReservoirModel load_reservoir_config(const std::string& filename) {
    std::ifstream ifs(filename);
    if (!ifs.is_open()) throw std::runtime_error("Não foi possível abrir o arquivo YAML");
    auto root = fkyaml::node::deserialize(ifs);
    ReservoirModel model;
    from_node(root, model);
    return model;
}