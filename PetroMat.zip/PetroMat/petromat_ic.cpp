#include "petromat_ic.h"


// Solve L * y = r (forward substitution)
void ic0_forward_substitution(const CSRMatrix *A, const double *l_vals, const double *r, double *y) {
    int n = A->n;
    for (int i = 0; i < n; i++) {
        double sum = 0.0;
        double diag = 1.0;
        
        for (int k = A->ia[i]; k < A->ia[i + 1]; k++) {
            int j = A->ja[k];
            if (j < i) {
                sum += l_vals[k] * y[j];
            } else if (j == i) {
                diag = l_vals[k];
            }
        }
        y[i] = (r[i] - sum) / diag;
    }
}
void ic0_backward_substitution(const CSRMatrix *A, const double *l_vals, const double *y, double *z) {
    int n = A->n;
    
    for (int i = 0; i < n; i++) z[i] = y[i];
    
    for (int i = n - 1; i >= 0; i--) {
        double diag = 1.0;
        // Encontra a diagonal
        for (int k = A->ia[i]; k < A->ia[i + 1]; k++) {
            if (A->ja[k] == i) {
                diag = l_vals[k];
                break;
            }
        }
        
        z[i] /= diag;
        
        // Subtrai contribuições. l_vals[k] já é L(i,j)!
        for (int k = A->ia[i]; k < A->ia[i + 1]; k++) {
            int j = A->ja[k];
            if (j < i) {  
                z[j] -= l_vals[k] * z[i];
            }
        }
    }
}

void ic0_decomposition(const CSRMatrix *A, double *l_vals) {
    int n = A->n;
    
    // Copy original matrix values
    for (int i = 0; i < A->nnz; i++) {
        l_vals[i] = A->vals[i];
    }

    for (int k = 0; k < n; k++) {
        // Find diagonal of current row
        int diag_idx_k = -1;
        for (int idx = A->ia[k]; idx < A->ia[k + 1]; idx++) {
            if (A->ja[idx] == k) {
                diag_idx_k = idx;
                break;
            }
        }
        
        if (diag_idx_k == -1 || l_vals[diag_idx_k] <= 0) {
            fprintf(stderr, "Error: Matrix not positive definite at row %d\n", k);
            return;
        }

        // Compute diagonal: sqrt(a_kk - sum_{t<k} l_kt^2)
        double diag_sum = 0.0;
        for (int idx = A->ia[k]; idx < A->ia[k + 1]; idx++) {
            int j = A->ja[idx];
            if (j < k) {
                diag_sum += l_vals[idx] * l_vals[idx];
            }
        }
        l_vals[diag_idx_k] = sqrt(l_vals[diag_idx_k] - diag_sum);

   // Update remaining entries in row k
        for (int idx = A->ia[k]; idx < A->ia[k + 1]; idx++) {
            int j = A->ja[idx];
            if (j > k) {
                double sum = 0.0;
                int jdx = A->ia[j];
                int kdx = A->ia[k];

                // Percorre as linhas j e k simultaneamente (Two Pointers)
                while (jdx < A->ia[j + 1] && kdx < A->ia[k + 1]) {
                    int col_j = A->ja[jdx];
                    int col_k = A->ja[kdx];
                    
                    if (col_j >= k || col_k >= k) break; // Só nos importam índices < k
                    
                    if (col_j == col_k) {
                        sum += l_vals[jdx] * l_vals[kdx];
                        jdx++;
                        kdx++;
                    } else if (col_j < col_k) {
                        jdx++;
                    } else {
                        kdx++;
                    }
                }
                
                // IMPORTANTE: Atualiza o valor de L(j,k) (trecho que estava faltando)
                for (int m = A->ia[j]; m < A->ia[j + 1]; m++) {
                    if (A->ja[m] == k) {
                        l_vals[m] = (l_vals[m] - sum) / l_vals[diag_idx_k];
                        break;
                    }
                }
            }
        }
    }
}
