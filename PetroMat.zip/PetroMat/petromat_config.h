#pragma once

#include <memory>
#include <vector>
#include <string>
#include <stdexcept>

// Includes das suas classes matemáticas e solvers
#include "petromat_types.h"
#include "petromat_solver.h"
#include "petromat_aggregation.h"
#include "petromat_coarse.h"
#include "petromat_composite.h"
#include "petromat_ic.h"
#include "petromat_cg.h" 
#include "petromat_jacobi.h"
#include "petromat_skyline.h"
#include "petromat_amgcl.h"
#include "petromat_hypre.h"



struct PrecondConfig {
    virtual ~PrecondConfig() = default;
    virtual std::string type() const = 0;
    virtual std::shared_ptr<Preconditioner> build() const = 0;
};

struct CoarseningConfig {
    virtual ~CoarseningConfig() = default;
    virtual std::string type() const = 0;
    virtual std::shared_ptr<Coarsening> build() const = 0;
};

struct  AggregationConfig : public CoarseningConfig {
    bool smooth;
};

struct SolverConfig {
    std::string id;            
    std::string type;          
    double tol = 1e-6;
    int maxiter = 1000;
    std::shared_ptr<PrecondConfig> precond = nullptr;
    
    virtual std::shared_ptr<Solver> build(std::shared_ptr<const CSRMatrix> A = nullptr) const;
};

struct ICConfig : public PrecondConfig {
    int level = 0;
    std::string type() const override { return "IC"; }
    virtual std::shared_ptr<Preconditioner> build() const override {
        return std::make_shared<ICKPreconditioner>(level);
    }
};

struct JacobiConfig : public PrecondConfig {
    double omega;
    std::string type() const override { return "jacobi"; }
    virtual std::shared_ptr<Preconditioner> build() const override {
        return std::make_shared<JacobiPreconditioner>(omega);
    }
};


struct ChebyshevConfig : public PrecondConfig {
    std::string type() const override { return "jacobi"; }
    virtual std::shared_ptr<Preconditioner> build() const override {
        return std::make_shared<ChebyshevSmoother>();
    }
};


struct L1JacobiConfig : public PrecondConfig {
    std::string type() const override { return "l1jacobi"; }
    virtual std::shared_ptr<Preconditioner> build() const override {
        return std::make_shared<L1JacobiPreconditioner>();
    }
};

struct GSConfig : public PrecondConfig {
    double omega;
    std::string type() const override { return "gs"; }
    virtual std::shared_ptr<Preconditioner> build() const override {
        return std::make_shared<GaussSeidelSmoother>(omega);
    }
};


struct SPAIConfig : public PrecondConfig {
    std::string type() const override { return "spai0"; }
    int level = 0;
    double omega = 1.0;
    virtual std::shared_ptr<Preconditioner> build() const override {
    
        if( level == 0)    return std::make_shared<SPAI0Preconditioner>(omega);
        else if( level == 1) return std::make_shared<SPAI1Preconditioner>();
        else return nullptr;
    }
};
struct CoarseConfig : public PrecondConfig {
    int coarseRatio = 10;
    int coarseSize = -1;
    std::shared_ptr<SolverConfig> internalSolver = nullptr;
    std::string type() const override { return "coarse"; }
    
    virtual std::shared_ptr<Preconditioner> build() const override {
        auto internal = internalSolver->build(nullptr);
        auto aggregator = std::make_shared<BFSAggregation>( coarseRatio );
        aggregator->setCoarseSize( coarseSize );
        return std::make_shared<Coarse>(internal, aggregator);
    }
};
struct RSCoaseninConfig : public CoarseningConfig {
    double theta = 0.25;
    double truncFactor = 0.2;

    std::string type() const override { return "bfs"; }
    virtual std::shared_ptr<Coarsening> build() const override {
        auto r = std::make_shared<RugeStuben>( theta, truncFactor );
        return r;
    }
};


struct CLPJCoaseninConfig : public CoarseningConfig {
    double theta = 0.25;
    double truncFactor = 0.2;

    std::string type() const override { return "clpj"; }
    virtual std::shared_ptr<Coarsening> build() const override {
        auto r = std::make_shared<CLJPCoarsening>( theta, truncFactor );
        return r;
    }
};



struct BFSAggregationConfig : public AggregationConfig {
    int coarse_ratio = 32;
    double theta = 0.25;
    std::string type() const override { return "bfs"; }
    virtual std::shared_ptr<Coarsening> build() const override {
        auto r = std::make_shared<BFSAggregation>(coarse_ratio, theta);
        r->smooth = this->smooth;
        return r;
    }
};

struct VanekConfig : public AggregationConfig {
    double eps = 0.2;
    std::string type() const override { return "vanek"; }
    virtual std::shared_ptr<Coarsening> build() const override {
        auto r = std::make_shared<VanekAggregation>(eps);
        r->smooth = this->smooth;
        return r;
    }
};

struct PlainAggregationConfig : public AggregationConfig {
    double eps = 0.2;
    std::string type() const override { return "plain"; }
    virtual std::shared_ptr<Coarsening> build() const override {
        auto r = std::make_shared<SmootherAggregation>(eps);
        r->smooth = this->smooth;
        return r;
    }
};


struct SmootherAggregationConfig : public AggregationConfig {
    double eps = 0.2;
    std::string type() const override { return "sa"; }
    virtual std::shared_ptr<Coarsening> build() const override {
        auto r = std::make_shared<SmootherAggregation>(eps);
        return r;
    }
};

struct CompositeConfig : public PrecondConfig {
    std::vector<std::shared_ptr<PrecondConfig>> components;
    std::string type() const override { return "composite"; }
    virtual std::shared_ptr<Preconditioner> build() const override {
        if (components.size() < 2) throw std::runtime_error("Composite precisa de 2 preconds.");
        auto m1 = components[0]->build();
        auto m2 = components[1]->build();
        return std::make_shared<MultiplicativeComposite>(m1, m2);
    }
};

struct MultilevelCoarseConfig : public PrecondConfig {
    int max_levels = 3;
    int bottom_solver_dimension = 1000;
    int pre_relax_sweeps = 2;
    int pos_relax_sweeps = 2;

    int pre_relax_sweeps_l0 = 2;
    int pos_relax_sweeps_l0 = 2;

    double levelFactor = 1.25;
    
    std::shared_ptr<SolverConfig> bottom_solver;
    std::shared_ptr<PrecondConfig> smoother; 
    std::shared_ptr<CoarseningConfig> coarsening; 

    CycleType cycleType = CycleType::V_CYCLE;

    std::string type() const override { return "multilevel_coarse"; }

    virtual std::shared_ptr<Preconditioner> build() const override {
        if (!bottom_solver) {
            throw std::runtime_error("MultilevelCoarseConfig: bottom_solver não definido.");
        }
        
        auto bottom = bottom_solver->build(nullptr);

        std::shared_ptr<Preconditioner> presmoother_ptr = nullptr;
        
        if (smoother) presmoother_ptr = smoother->build();
        
        auto agg = coarsening->build();

        return std::make_shared<AMG>(
            agg, bottom, presmoother_ptr, max_levels, bottom_solver_dimension, 
            pre_relax_sweeps,  pos_relax_sweeps, pre_relax_sweeps_l0, pos_relax_sweeps_l0, levelFactor, cycleType
        );
    }
};

// Implementação das fábricas de Solvers
inline std::shared_ptr<Solver> SolverConfig::build(std::shared_ptr<const CSRMatrix> A) const {
    std::shared_ptr<Solver> solver;
    
    if (type == "CG") {
        solver = std::make_shared<CG>(A, tol, maxiter);
    } else if( type == "BiCGStab") {
        solver = std::make_shared<BiCGStab>(A, tol, maxiter);
    } else if (type == "AMGHYPRE") {
        solver = std::make_shared<AMGHypre>(A, tol, maxiter);
    } else if (type == "AMGCL") {
        solver = std::make_shared<AMGcl>(A, tol, maxiter);
    } else if (type == "SKYLINE") { 
        solver = std::make_shared<SkylineLUSolver>( A );
    } else {
        throw std::runtime_error("Solver desconhecido: " + type);
    }

    if (precond) {
        solver->setPreconditioner(precond->build());
    }
    
    return solver;
}

inline std::shared_ptr<Solver> SolverFactory(const SolverConfig& config, std::shared_ptr<const CSRMatrix> A = nullptr) {
    return config.build(A);
}